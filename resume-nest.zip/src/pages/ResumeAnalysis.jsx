import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useResume } from '../hooks/useResume.js';
import ATSScore from '../components/ATSScore.jsx';
import ScoreBreakdown from '../components/ScoreBreakdown.jsx';
import SkillGapCard from '../components/SkillGapCard.jsx';
import CourseCard from '../components/CourseCard.jsx';
import LoadingState from '../components/LoadingState.jsx';
import ErrorState from '../components/ErrorState.jsx';
import {
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  ArrowRight,
  BookOpen,
  FileEdit,
  RefreshCw,
  Cpu,
} from 'lucide-react';

export default function ResumeAnalysis() {
  const { resumeId } = useParams();
  const {
    getResume,
    runAnalysis,
    fetchAnalysis,
    fetchRecommendedCourses,
    recommendedCourses,
    loading: hookLoading,
  } = useResume();

  const [resume, setResume] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadData() {
      if (!resumeId) return;
      setError(null);
      try {
        const res = await getResume(resumeId);
        setResume(res);

        // Check if analysis already exists
        const existing = await fetchAnalysis(resumeId);
        if (existing) {
          setAnalysis(existing);
          await fetchRecommendedCourses(resumeId);
        } else {
          // Trigger first analysis automatically
          handleRunAnalysis(res.targetRole);
        }
      } catch (err) {
        setError(err.message || 'Failed to load resume analysis.');
      }
    }

    loadData();
  }, [resumeId]);

  const handleRunAnalysis = async (targetRole) => {
    setAnalyzing(true);
    setError(null);
    try {
      const result = await runAnalysis(resumeId, targetRole || resume?.targetRole);
      setAnalysis(result);
      await fetchRecommendedCourses(resumeId);
    } catch (err) {
      setError(err.message || 'AI analysis is temporarily unavailable. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  };

  if (analyzing) {
    return (
      <LoadingState
        title="Analyzing Resume with Gemini 3.8 Flash..."
        message="Evaluating ATS parseability, keywords, experience metrics, and calculating 10-factor weighted readiness score."
        isAnalyzing
      />
    );
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <ErrorState
          title="Analysis Unavailable"
          message={error}
          onRetry={() => handleRunAnalysis()}
        />
      </div>
    );
  }

  if (!analysis) {
    return <LoadingState message="Loading diagnostic report..." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2 mb-1">
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center space-x-1">
              <Cpu className="w-3 h-3" />
              <span>Server-Side Gemini 3.8 Flash Audit</span>
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            ATS Readiness Diagnostic
          </h1>
          <p className="text-xs text-slate-400">
            Resume: <span className="text-slate-200 font-semibold">{resume?.title}</span> • Target Role:{' '}
            <span className="text-indigo-400 font-semibold">{analysis.targetRole}</span>
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <Link
            to={`/builder?id=${resumeId}`}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition-colors"
          >
            <FileEdit className="w-4 h-4" />
            <span>Edit Resume</span>
          </Link>

          <button
            onClick={() => handleRunAnalysis()}
            disabled={analyzing}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition-all active:scale-95 disabled:opacity-50"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Re-run Analysis</span>
          </button>
        </div>
      </div>

      {/* Primary ATS Score Gauge */}
      <ATSScore
        score={analysis.atsScore}
        targetRole={analysis.targetRole}
        analyzedAt={analysis.analyzedAt}
      />

      {/* 10-Factor Score Breakdown */}
      <ScoreBreakdown sectionScores={analysis.sectionScores} />

      {/* Strengths & Weaknesses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Strengths */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm">
            <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
            <span>Resume Strengths</span>
          </div>

          <ul className="space-y-3">
            {analysis.strengths && analysis.strengths.map((s, idx) => (
              <li key={idx} className="flex items-start space-x-2.5 text-xs text-slate-300 leading-relaxed">
                <span className="text-emerald-400 font-bold mt-0.5">•</span>
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Weaknesses / Flaws */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center space-x-2 text-rose-400 font-bold text-sm">
            <AlertTriangle className="w-5 h-5 flex-shrink-0" />
            <span>Areas for Immediate Improvement</span>
          </div>

          <ul className="space-y-3">
            {analysis.weaknesses && analysis.weaknesses.map((w, idx) => (
              <li key={idx} className="flex items-start space-x-2.5 text-xs text-slate-300 leading-relaxed">
                <span className="text-rose-400 font-bold mt-0.5">•</span>
                <span>{w}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Actionable Recommendations */}
      {analysis.recommendations && analysis.recommendations.length > 0 && (
        <div className="rounded-2xl bg-slate-900 border border-indigo-500/20 p-6 sm:p-8 shadow-xl space-y-4">
          <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm">
            <Lightbulb className="w-5 h-5 flex-shrink-0 text-amber-400" />
            <span>Actionable ATS Optimizations (Google X-Y-Z Formula)</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {analysis.recommendations.map((rec, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300 leading-relaxed space-y-1"
              >
                <span className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-wider block">
                  Action #{idx + 1}
                </span>
                <p>{rec}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skill Gap & Keyword Card */}
      <SkillGapCard
        detectedSkills={analysis.detectedSkills}
        missingSkills={analysis.missingSkills}
        missingKeywords={analysis.missingKeywords}
        resumeId={resumeId}
      />

      {/* Matched Free Courses */}
      <div className="space-y-4 pt-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-indigo-400" />
              <h3 className="text-lg font-bold text-white">Recommended Free Courses for Skill Gaps</h3>
            </div>
            <p className="text-xs text-slate-400">
              Verified 100% free courses directly matched against your detected skill deficiencies.
            </p>
          </div>
          <Link
            to={`/courses?resumeId=${resumeId}`}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center space-x-1"
          >
            <span>Browse Full Free Directory</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {recommendedCourses && recommendedCourses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendedCourses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                highlightedSkills={analysis.missingSkills}
              />
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-500 italic">
            No specific course recommendations found. Explore our full course catalog.
          </p>
        )}
      </div>
    </div>
  );
}
