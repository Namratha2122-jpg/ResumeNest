import React, { useEffect, useState } from 'react';
import api from '../../services/api.js';
import LoadingState from '../../components/LoadingState.jsx';
import ErrorState from '../../components/ErrorState.jsx';
import { Users, GraduationCap, Calendar, Target, ShieldCheck, Search } from 'lucide-react';

export default function Students() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');

  const fetchStudents = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.get('/admin/students');
      setStudents(data.students || []);
    } catch (err) {
      setError(err.message || 'Failed to fetch student records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  const filtered = students.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.email.toLowerCase().includes(search.toLowerCase()) ||
      s.college.toLowerCase().includes(search.toLowerCase()) ||
      s.major.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return <LoadingState message="Loading student records from database..." />;
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <ErrorState title="Student Directory Error" message={error} onRetry={fetchStudents} />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Users className="w-6 h-6 text-indigo-400" />
            <span>Registered Student Directory</span>
          </h1>
          <p className="text-xs text-slate-400">
            Directory of verified students. Account credentials and resume contents remain confidential.
          </p>
        </div>

        {/* Search */}
        <div className="w-full sm:w-64">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search students, universities..."
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {students.length === 0 ? (
        <div className="p-12 text-center bg-slate-900/40 rounded-2xl border border-dashed border-slate-800 space-y-2">
          <Users className="w-8 h-8 text-slate-500 mx-auto" />
          <h3 className="text-sm font-bold text-white">No student data available yet</h3>
          <p className="text-xs text-slate-400">
            Student records will automatically appear when users authenticate with approved college emails.
          </p>
        </div>
      ) : (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-[11px] text-slate-400 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="px-5 py-3.5">Student Name & Email</th>
                  <th className="px-5 py-3.5">College / University</th>
                  <th className="px-5 py-3.5">Degree & Major</th>
                  <th className="px-5 py-3.5">Grad Year</th>
                  <th className="px-5 py-3.5">Target Role</th>
                  <th className="px-5 py-3.5">Resumes</th>
                  <th className="px-5 py-3.5">Account Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {filtered.map((s) => (
                  <tr key={s.uid} className="hover:bg-slate-800/40 transition-colors">
                    <td className="px-5 py-3.5">
                      <p className="font-bold text-white">{s.name}</p>
                      <p className="text-[11px] text-slate-400 font-mono">{s.email}</p>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="font-medium text-slate-200">🎓 {s.college}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <p className="text-slate-200">{s.degree}</p>
                      <p className="text-[11px] text-slate-400">{s.major}</p>
                    </td>
                    <td className="px-5 py-3.5 font-mono text-slate-300">{s.graduationYear}</td>
                    <td className="px-5 py-3.5">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                        {s.targetRole}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 font-bold text-slate-200">{s.resumeCount}</td>
                    <td className="px-5 py-3.5 text-slate-500 text-[11px] font-mono">
                      {s.createdAt ? new Date(s.createdAt).toLocaleDateString() : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
