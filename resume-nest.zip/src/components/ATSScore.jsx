import React from 'react';
import { getScoreColor, getScoreBadge } from '../utils/formatting.js';
import { ShieldCheck, Target, Sparkles } from 'lucide-react';

export default function ATSScore({
  score = 0,
  targetRole = 'Software Engineer',
  analyzedAt = null,
  compact = false,
}) {
  const badge = getScoreBadge(score);
  const colorClass = getScoreColor(score);

  // SVG circular gauge calculation
  const radius = compact ? 36 : 56;
  const strokeWidth = compact ? 7 : 10;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className={`rounded-2xl bg-slate-900 border border-slate-800 shadow-xl ${
      compact ? 'p-4' : 'p-6 sm:p-8'
    }`}>
      <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-6">
        {/* Left: Score Gauge */}
        <div className="flex items-center space-x-6">
          <div className="relative flex items-center justify-center flex-shrink-0">
            <svg
              className={`transform -rotate-90 ${compact ? 'w-24 h-24' : 'w-36 h-36'}`}
            >
              {/* Background circle */}
              <circle
                cx={compact ? '48' : '72'}
                cy={compact ? '48' : '72'}
                r={radius}
                className="stroke-slate-800"
                strokeWidth={strokeWidth}
                fill="transparent"
              />
              {/* Progress circle */}
              <circle
                cx={compact ? '48' : '72'}
                cy={compact ? '48' : '72'}
                r={radius}
                className={`transition-all duration-1000 ease-out ${
                  score >= 85 ? 'stroke-emerald-500' : score >= 70 ? 'stroke-blue-500' : score >= 55 ? 'stroke-amber-500' : 'stroke-rose-500'
                }`}
                strokeWidth={strokeWidth}
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>

            {/* Score in Center */}
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className={`font-black tracking-tight ${colorClass} ${compact ? 'text-2xl' : 'text-4xl'}`}>
                {score}
              </span>
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                out of 100
              </span>
            </div>
          </div>

          <div>
            <div className="flex items-center space-x-2 mb-1">
              <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
                ATS Readiness
              </span>
              <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                <Target className="w-3 h-3" />
                <span>{targetRole}</span>
              </span>
            </div>

            <div className="mb-2">
              <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold border ${badge.badgeClass}`}>
                {badge.text}
              </span>
            </div>

            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              {badge.description}
            </p>

            {analyzedAt && (
              <p className="text-[10px] text-slate-500 mt-2 font-mono">
                Authoritatively calculated: {new Date(analyzedAt).toLocaleDateString()} at {new Date(analyzedAt).toLocaleTimeString()}
              </p>
            )}
          </div>
        </div>

        {/* Right Info Box */}
        {!compact && (
          <div className="bg-slate-950/60 rounded-xl p-4 border border-slate-800/80 text-xs text-slate-400 space-y-2 w-full sm:w-64 flex-shrink-0">
            <div className="flex items-center space-x-2 text-indigo-300 font-semibold">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>Backend Scoring Engine</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Calculated using strict backend weighting constants across 10 recruiting criteria.
            </p>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
              <span>Recruiter Pass Threshold</span>
              <span className="font-semibold text-slate-300">75+ Score</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
