import * as db from './db.service.js';

/**
 * Admin Dashboard Service
 * Calculates real counts directly from database collections.
 * Never fabricates numbers.
 */
export async function getDashboardMetrics() {
  const students = await db.getAllStudents();
  const resumes = await db.getAllResumes();
  const analyses = await db.getAllAnalyses();
  const activeCourses = await db.getActiveCourses();
  const allCourses = await db.getAllCourses();

  const totalStudents = students.length;
  const totalResumes = resumes.length;
  const totalAnalyses = analyses.length;
  const totalActiveCourses = activeCourses.length;
  const totalCourses = allCourses.length;

  return {
    totalStudents,
    totalResumes,
    totalAnalyses,
    totalActiveCourses,
    totalCourses,
    isEmpty: totalStudents === 0 && totalResumes === 0,
    recentResumes: resumes.slice(0, 5).map((r) => ({
      id: r.id,
      title: r.title,
      targetRole: r.targetRole,
      updatedAt: r.updatedAt,
    })),
  };
}

/**
 * Admin Student Management Service
 * Returns student metadata without exposing sensitive credentials or private secrets.
 */
export async function getStudentsList() {
  const students = await db.getAllStudents();
  return students.map((s) => ({
    uid: s.uid,
    name: s.name || 'Anonymous Student',
    email: s.email,
    college: s.college || 'Unspecified University',
    degree: s.degree || 'Bachelor of Science',
    major: s.major || 'Computer Science',
    graduationYear: s.graduationYear || '2026',
    targetRole: s.targetRole || 'Software Engineer',
    createdAt: s.createdAt,
    resumeCount: s.resumeCount || 0,
  }));
}

/**
 * Admin Course Management Service
 */
export async function getAllCourses() {
  return await db.getAllCourses();
}

export async function createCourse(data) {
  if (!data.title || !data.provider || !data.url) {
    throw new Error('Title, provider, and a valid URL are required to create a course.');
  }
  return await db.addCourse(data);
}

export async function updateCourse(id, data) {
  return await db.updateCourse(id, data);
}

export async function deleteCourse(id) {
  return await db.deleteCourse(id);
}

export async function toggleCourseActive(id, active) {
  return await db.updateCourse(id, { active });
}

/**
 * Admin Analytics Service
 * Real calculation of ATS readiness scores, skill gaps, and target roles.
 * Returns informative metrics or indicates insufficient data if collection is empty.
 */
export async function getAnalytics() {
  const students = await db.getAllStudents();
  const resumes = await db.getAllResumes();
  const analyses = await db.getAllAnalyses();

  if (analyses.length === 0 && resumes.length === 0) {
    return {
      hasEnoughData: false,
      message: 'Not enough data to calculate this metric.',
      totalStudents: students.length,
      totalResumes: resumes.length,
      totalAnalyses: 0,
    };
  }

  // Calculate Average ATS score
  let totalScore = 0;
  let scoreCount = 0;
  const skillGapFrequency = {};
  const targetRoleFrequency = {};

  for (const anl of analyses) {
    if (typeof anl.atsScore === 'number') {
      totalScore += anl.atsScore;
      scoreCount++;
    }

    if (Array.isArray(anl.missingSkills)) {
      anl.missingSkills.forEach((skill) => {
        const key = skill.trim();
        skillGapFrequency[key] = (skillGapFrequency[key] || 0) + 1;
      });
    }

    if (anl.targetRole) {
      targetRoleFrequency[anl.targetRole] = (targetRoleFrequency[anl.targetRole] || 0) + 1;
    }
  }

  // Also count target roles from resumes
  for (const r of resumes) {
    if (r.targetRole && !targetRoleFrequency[r.targetRole]) {
      targetRoleFrequency[r.targetRole] = (targetRoleFrequency[r.targetRole] || 0) + 1;
    }
  }

  const averageAtsScore = scoreCount > 0 ? Math.round(totalScore / scoreCount) : null;

  // Sort top skill gaps
  const topSkillGaps = Object.entries(skillGapFrequency)
    .map(([skill, count]) => ({ skill, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  // Sort top target roles
  const topTargetRoles = Object.entries(targetRoleFrequency)
    .map(([role, count]) => ({ role, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  return {
    hasEnoughData: true,
    totalStudents: students.length,
    totalResumes: resumes.length,
    totalAnalyses: analyses.length,
    averageAtsScore,
    topSkillGaps,
    topTargetRoles,
  };
}

/**
 * Admin Settings Service (approvedCollegeDomains management)
 */
export async function getSettings() {
  const domains = await db.getApprovedCollegeDomains();
  return { approvedCollegeDomains: domains };
}

export async function addDomain(data) {
  if (!data.domain) {
    throw new Error('College domain is required.');
  }
  return await db.addApprovedDomain(data);
}

export async function updateDomain(id, data) {
  return await db.updateApprovedDomain(id, data);
}

export async function deleteDomain(id) {
  return await db.deleteApprovedDomain(id);
}
