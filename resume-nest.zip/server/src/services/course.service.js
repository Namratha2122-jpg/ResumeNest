import { COURSE_CATALOG, matchCoursesToSkillGaps } from '../utils/courseMatcher.js';
import { getResumeById, getAnalysisResult } from './resume.service.js';
import { runResumeAnalysis } from './analysis.service.js';

/**
 * Returns all active free courses in the catalog
 */
export async function getActiveFreeCourses(category = null) {
  let courses = COURSE_CATALOG.filter(c => c.isFree && c.isActive);
  if (category) {
    courses = courses.filter(c => c.category?.toLowerCase() === category.toLowerCase());
  }
  return courses;
}

/**
 * Returns recommended courses for a student's resume by matching detected skill gaps.
 * Strictly checks student resume ownership.
 * Course URLs must come strictly from courseCatalog (Gemini never invents URLs).
 */
export async function getRecommendedCoursesForResume(resumeId, userId) {
  // 1. Authoritative check that the student owns this resume
  const resume = await getResumeById(resumeId, userId);

  // 2. Fetch or trigger analysis to determine missing skills
  let analysis = await getAnalysisResult(resumeId, userId);
  if (!analysis) {
    // Run analysis if not yet generated
    analysis = await runResumeAnalysis(resumeId, userId, resume.targetRole);
  }

  const missingSkills = analysis.missingSkills || [];

  // 3. Match against course catalog (FREE + ACTIVE only)
  const matchedCourses = matchCoursesToSkillGaps(missingSkills);

  return {
    resumeId,
    targetRole: analysis.targetRole,
    missingSkills,
    recommendedCourses: matchedCourses,
  };
}
