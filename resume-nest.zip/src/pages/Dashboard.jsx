import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';
import { useResume } from '../hooks/useResume.js';
import api from '../services/api.js';
import ATSScore from '../components/ATSScore.jsx';
import CourseCard from '../components/CourseCard.jsx';
import EmptyState from '../components/EmptyState.jsx';
import LoadingState from '../components/LoadingState.jsx';
import {
  FileText,
  Plus,
  Sparkles,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  BarChart2,
  FolderOpen,
  TrendingUp,
} from 'lucide-react';

export default function Dashboard() {
  const { user } = useAuth();
  const { resumes, fetchResumes, loading: resumesLoading } = useResume();
  const [profile, setProfile] = useState(null);
  const [latestAnalysis, setLatestAnalysis] = useState(null);
  const [topCourses, setTopCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadDashboardData() {
      setLoading(true);
      try {
        // Fetch resumes
        const loadedResumes = await fetchResumes();

        // Fetch profile
        try {
          const profRes = await api.get('/profile');
          setProfile(profRes.profile);
        } catch (e) {
          console.warn('Profile fetch error:', e);
        }

        // Fetch latest analysis if a resume exists
        if (loadedResumes && loadedResumes.length > 0) {
          try {
            const anl = await api.get(`/analysis/${loadedResumes[0].id}`);
            setLatestAnalysis(anl);
          } catch (e) {
            // Not analyzed yet
          }
        }

        // Fetch popular free courses
        try {
          const courseRes = await api.get('/courses');
          setTopCourses((courseRes.courses || []).slice(0, 3));
        } catch (e) {
          console.warn('Course fetch error:', e);
        }
      } catch (err) {
        console.error('Dashboard load error:', err);
      } finally {
        setLoading(false);
      }
    }

    loadDashboardData();
  }, [fetchResumes]);

  if (loading || resumesLoading) {
    return <LoadingState message="Loading your student career dashboard..." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center space-x-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Verified Campus Student</span>
            </span>
            <span className="text-xs text-slate-400">
              🎓 {user?.collegeName || profile?.college || 'University'}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Welcome back, {user?.name || 'Student'}!
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
            Targeting <strong className="text-indigo-300 font-semibold">{profile?.targetRole || 'Software Engineering'}</strong> roles. Your resumes are automatically audited against recruitment screening algorithms with server-side Gemini 3.8 Flash.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 flex-shrink-0">
          <Link
            to="/templates"
            className="btn-3d-gradient inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl text-white font-bold text-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
            <span>Community Templates</span>
            <span className="flex h-1.5 w-1.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-300 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-white"></span>
            </span>
          </Link>

          <Link
            to="/resume/new"
            className="btn-3d-indigo inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl text-white font-semibold text-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Create Resume</span>
          </Link>
        </div>
      </div>

      {/* Quick Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">My Resumes</span>
            <FolderOpen className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-white">{resumes.length}</span>
            <span className="text-xs text-slate-500">documents</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Latest ATS Score</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-emerald-400">
              {latestAnalysis ? latestAnalysis.atsScore : '—'}
            </span>
            <span className="text-xs text-slate-500">/ 100</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Identified Skill Gaps</span>
            <Sparkles className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-amber-300">
              {latestAnalysis?.missingSkills ? latestAnalysis.missingSkills.length : '0'}
            </span>
            <span className="text-xs text-slate-500">skills</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Verified Free Courses</span>
            <BookOpen className="w-4 h-4 text-blue-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-blue-400">100% Free</span>
            <span className="text-xs text-slate-500">catalog</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Left = Latest ATS Diagnostic, Right = Recent Resumes */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: ATS Diagnostic Preview (2 cols on lg) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BarChart2 className="w-5 h-5 text-indigo-400" />
              <h2 className="text-lg font-bold text-white">Latest ATS Readiness Diagnostic</h2>
            </div>
            {latestAnalysis && (
              <Link
                to={`/analyze/${latestAnalysis.resumeId || resumes[0]?.id}`}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center space-x-1"
              >
                <span>Full Diagnostic Report</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            )}
          </div>

          {latestAnalysis ? (
            <ATSScore
              score={latestAnalysis.atsScore}
              targetRole={latestAnalysis.targetRole}
              analyzedAt={latestAnalysis.analyzedAt}
            />
          ) : (
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-8 text-center space-y-3">
              <Sparkles className="w-8 h-8 text-indigo-400 mx-auto" />
              <h3 className="text-sm font-bold text-white">No ATS Diagnostic Run Yet</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Select one of your resumes below and click "Analyze with Gemini" to calculate your ATS score and get personalized course recommendations.
              </p>
              {resumes.length > 0 && (
                <Link
                  to={`/analyze/${resumes[0].id}`}
                  className="inline-flex items-center space-x-2 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
                >
                  <span>Run Analysis on "{resumes[0].title}"</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              )}
            </div>
          )}

          {/* Recommended Free Courses preview */}
          <div className="space-y-4 pt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <BookOpen className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-bold text-white">Recommended Free Courses</h3>
              </div>
              <Link
                to="/courses"
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center space-x-1"
              >
                <span>View Full Catalog</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {topCourses.map((course) => (
                <CourseCard
                  key={course.id}
                  course={course}
                  highlightedSkills={latestAnalysis?.missingSkills || []}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Resumes List */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">My Resumes</h2>
            <Link
              to="/my-resumes"
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
            >
              View All ({resumes.length})
            </Link>
          </div>

          {resumes.length === 0 ? (
            <EmptyState
              title="No resumes created"
              description="Create an ATS-friendly student resume to prepare for internships and jobs."
              actionText="Create Resume"
              actionLink="/resume/new"
            />
          ) : (
            <div className="space-y-3">
              {resumes.slice(0, 5).map((resume) => (
                <div
                  key={resume.id}
                  className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-sm font-bold text-white truncate max-w-[200px]">
                        {resume.title}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        Target: <span className="text-slate-300">{resume.targetRole || 'Software Engineer'}</span>
                      </p>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(resume.updatedAt).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="flex items-center space-x-2 pt-1 border-t border-slate-800/80">
                    <Link
                      to={`/resume/${resume.id}`}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
                    >
                      Edit
                    </Link>
                    <Link
                      to={`/analyze/${resume.id}`}
                      className="flex items-center space-x-1 px-2.5 py-1 rounded bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-medium transition-colors"
                    >
                      <Sparkles className="w-3 h-3 text-amber-400" />
                      <span>ATS Diagnostic</span>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
