import React from 'react';
import { useAuth } from '../hooks/useAuth.jsx';
import PublicNavbar from './PublicNavbar.jsx';
import StudentNavbar from './StudentNavbar.jsx';
import AdminNavbar from './AdminNavbar.jsx';
import { Loader2 } from 'lucide-react';

export default function Navbar() {
  const { userType, loading } = useAuth();

  // 1. Loading Authentication State (Small subtle loading bar, no flashes)
  if (loading) {
    return (
      <header className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-900 text-white h-16 flex items-center justify-between px-6 max-w-7xl mx-auto">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 animate-pulse" />
          <div className="w-24 h-4 bg-slate-800 rounded animate-pulse" />
        </div>
        <div className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
          <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-400" />
          <span>Verifying session...</span>
        </div>
      </header>
    );
  }

  // 2. Authenticated Admin
  if (userType === 'admin') {
    return <AdminNavbar />;
  }

  // 3. Authenticated Student
  if (userType === 'student') {
    return <StudentNavbar />;
  }

  // 4. Unauthenticated Public Visitor
  return <PublicNavbar />;
}
