import { isDomainApproved, getAdminByUidOrEmail, getStudentProfile, saveStudentProfile } from '../services/db.service.js';
import { getCollegeName } from '../services/collegeDomain.service.js';

/**
 * Verifies student authentication and authoritative college-domain check
 * POST /api/auth/verify-student
 */
export async function verifyStudentSession(req, res) {
  const user = req.user;

  if (!user || !user.domain) {
    return res.status(401).json({
      error: 'Please sign in to continue.',
      code: 'UNAUTHORIZED',
    });
  }

  const isApproved = await isDomainApproved(user.domain);

  if (!isApproved) {
    return res.status(403).json({
      error: 'Resume Nest is currently available only to students using an approved college email address.',
      code: 'FORBIDDEN_DOMAIN',
      domain: user.domain,
      email: user.email,
    });
  }

  // Authoritative student record
  const collegeName = getCollegeName(user.domain);
  let profile = await getStudentProfile(user.uid);
  if (!profile) {
    profile = await saveStudentProfile(user.uid, {
      uid: user.uid,
      email: user.email,
      name: user.name || user.email.split('@')[0],
      college: collegeName,
      degree: 'Bachelor of Science',
      major: 'Computer Science',
      graduationYear: '2026',
      targetRole: 'Software Engineer',
      resumeCount: 0,
    });
  }

  return res.json({
    success: true,
    userType: 'student',
    user: {
      uid: user.uid,
      email: user.email,
      name: user.name,
      domain: user.domain,
      collegeName: collegeName,
      userType: 'student',
      isAuthorized: true,
    },
  });
}

/**
 * Verifies administrator credentials against admins collection
 * POST /api/auth/verify-admin
 */
export async function verifyAdminSession(req, res) {
  const user = req.user;

  if (!user || !user.uid) {
    return res.status(401).json({
      error: 'Please sign in to continue.',
      code: 'UNAUTHORIZED',
    });
  }

  const admin = await getAdminByUidOrEmail(user.uid, user.email);

  if (!admin || admin.active !== true) {
    return res.status(403).json({
      error: 'Access denied: Only the two designated administrators (Naga Surya Dinesh and Namratha Siri) are authorized to access the admin portal.',
      code: 'FORBIDDEN_NOT_ADMIN',
    });
  }

  return res.json({
    success: true,
    userType: 'admin',
    user: {
      uid: admin.uid,
      email: admin.email,
      name: admin.name || 'System Administrator',
      userType: 'admin',
      permissions: admin.permissions || [],
      isAdmin: true,
    },
  });
}

/**
 * Universal session restoration endpoint
 * GET /api/auth/session
 * The backend authoritatively determines if the user is an admin or student.
 */
export async function getSession(req, res) {
  const user = req.user;

  if (!user || !user.uid) {
    return res.status(401).json({
      error: 'Please sign in to continue.',
    });
  }

  // 1. Check if user is an authorized admin
  const admin = await getAdminByUidOrEmail(user.uid, user.email);
  if (admin && admin.active === true) {
    return res.json({
      userType: 'admin',
      user: {
        uid: admin.uid,
        email: admin.email,
        name: admin.name || 'System Administrator',
        userType: 'admin',
        permissions: admin.permissions || [],
        isAdmin: true,
      },
    });
  }

  // 2. Check if user is an approved student
  if (user.domain) {
    const isApproved = await isDomainApproved(user.domain);
    if (isApproved) {
      const collegeName = getCollegeName(user.domain);
      return res.json({
        userType: 'student',
        user: {
          uid: user.uid,
          email: user.email,
          name: user.name,
          domain: user.domain,
          collegeName: collegeName,
          userType: 'student',
          isAuthorized: true,
        },
      });
    }
  }

  // User is authenticated but neither approved student nor admin
  return res.status(403).json({
    error: 'Access denied: account is not authorized.',
    userType: null,
  });
}
