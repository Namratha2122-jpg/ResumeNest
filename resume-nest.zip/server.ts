import express from 'express';
import http from 'http';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { createApiApp } from './server/src/server.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = createApiApp();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist'), {
      maxAge: '1h',
      etag: true,
    }));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  // Create Native HTTP Server with High-Concurrency Socket Tuning
  const httpServer = http.createServer(app);

  // Scalability Tuning for 10,000 - 50,000 Concurrent Requests
  httpServer.keepAliveTimeout = 65000; // 65s (exceeds reverse-proxy timeouts)
  httpServer.headersTimeout = 66000;   // 66s
  httpServer.maxHeadersCount = 4000;

  // Listen with backlogged queue capacity for massive bursts
  httpServer.listen(PORT, '0.0.0.0', 10000, () => {
    console.log(`[ResumeNest] High-concurrency server (10k-50k capacity) active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
