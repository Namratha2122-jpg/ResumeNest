import { GoogleGenAI, Type } from '@google/genai';
import { config } from '../config/environment.js';
import { calculateATSScore } from '../utils/atsScore.js';

let aiInstance = null;

function getAiClient() {
  if (!aiInstance) {
    const apiKey = config.geminiApiKey || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('[GeminiService] GEMINI_API_KEY is not set in environment.');
    }
    aiInstance = new GoogleGenAI({
      apiKey: apiKey || '',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiInstance;
}

/**
 * Analyzes a student's resume against a target role using Gemini 3.8 Flash.
 * Validates the AI response, evaluates section scores, detects skill gaps,
 * and attaches authoritative ATS Readiness Score.
 */
export async function analyzeResumeWithGemini(resumeData, targetRole = 'Software Engineer') {
  const ai = getAiClient();

  const prompt = `
You are an expert Executive ATS (Applicant Tracking System) Recruiter and College Career Counselor.
Analyze the following student resume for the target role: "${targetRole}".

RESUME CONTENT:
${JSON.stringify(resumeData, null, 2)}

Provide a strict, professional ATS screening diagnostic in JSON format matching the schema:
1. Target Role: Confirm or refine target role.
2. Strengths: 3-5 specific strengths of this resume for this role.
3. Weaknesses: 3-5 specific weaknesses, vague bullet points, or missing elements.
4. Missing Keywords: 5-10 specific industry/technical keywords the candidate should include to pass ATS algorithms.
5. Detected Skills: All technical and professional skills successfully extracted from the text.
6. Missing Skills: 4-8 high-demand skills for the target role that are missing or weak in this resume.
7. Recommendations: 4-6 actionable, step-by-step improvements (e.g. using the Google X-Y-Z formula: Accomplished [X] as measured by [Y] by doing [Z]).
8. Section Scores (integers 0-100 for each of the following 10 exact keys):
   - contact: completeness and professional format of contact details (no header/footer traps)
   - summary: punchiness, career focus, and value proposition
   - education: university prestige, degree, graduation date, GPA, relevant courses
   - skills: skill density, modern tools, technical categorization
   - experience: action verbs, quantified outcomes, technical depth
   - projects: complexity of projects, tools used, GitHub/live links, results
   - certifications: verified credentials, hackathons, continuous learning
   - keywords: frequency and placement of high-value industry terminology
   - formatting: clean ATS parseability, chronological order, bullet point hygiene
   - roleRelevance: overall alignment with the target role "${targetRole}"
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            targetRole: { type: Type.STRING },
            strengths: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            weaknesses: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            missingKeywords: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            detectedSkills: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            missingSkills: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            sectionScores: {
              type: Type.OBJECT,
              properties: {
                contact: { type: Type.INTEGER },
                summary: { type: Type.INTEGER },
                education: { type: Type.INTEGER },
                skills: { type: Type.INTEGER },
                experience: { type: Type.INTEGER },
                projects: { type: Type.INTEGER },
                certifications: { type: Type.INTEGER },
                keywords: { type: Type.INTEGER },
                formatting: { type: Type.INTEGER },
                roleRelevance: { type: Type.INTEGER },
              },
              required: [
                'contact',
                'summary',
                'education',
                'skills',
                'experience',
                'projects',
                'certifications',
                'keywords',
                'formatting',
                'roleRelevance',
              ],
            },
          },
          required: [
            'targetRole',
            'strengths',
            'weaknesses',
            'missingKeywords',
            'detectedSkills',
            'missingSkills',
            'recommendations',
            'sectionScores',
          ],
        },
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error('Empty response received from Gemini');
    }

    const parsed = JSON.parse(text);

    // Calculate authoritative backend ATS score using strictly weighted constants
    const atsCalculation = calculateATSScore(parsed.sectionScores);

    return {
      atsScore: atsCalculation.atsScore,
      targetRole: parsed.targetRole || targetRole,
      strengths: Array.isArray(parsed.strengths) ? parsed.strengths : [],
      weaknesses: Array.isArray(parsed.weaknesses) ? parsed.weaknesses : [],
      missingKeywords: Array.isArray(parsed.missingKeywords) ? parsed.missingKeywords : [],
      detectedSkills: Array.isArray(parsed.detectedSkills) ? parsed.detectedSkills : [],
      missingSkills: Array.isArray(parsed.missingSkills) ? parsed.missingSkills : [],
      recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations : [],
      sectionScores: atsCalculation.sectionScores,
      tier: atsCalculation.tier,
      statusBadge: atsCalculation.statusBadge,
      summary: atsCalculation.summary,
      analyzedAt: new Date().toISOString(),
    };
  } catch (error) {
    console.error('[GeminiService] Resume analysis error:', error);
    const err = new Error('AI analysis is temporarily unavailable. Please try again.');
    err.status = 503;
    err.details = error.message;
    throw err;
  }
}

/**
 * Improves a specific resume section (summary, bullet points, experience) using Gemini 3.8 Flash.
 */
export async function improveSectionWithGemini({ section, content, targetRole = 'Software Engineer', instruction = '' }) {
  const ai = getAiClient();

  const prompt = `
You are a senior technical career coach.
Improve the following resume section: "${section}".
Target Job Role: "${targetRole}"
Candidate's Content:
"${content}"

Custom Instruction:
"${instruction || 'Make it punchy, quantifiable using Google X-Y-Z formula, action-verb led, and optimized for ATS keyword scanners.'}"

Return JSON with:
1. improvedContent: The upgraded text or bullet points ready to copy-paste.
2. keyChanges: Array of specific enhancements made (e.g. "Replaced passive verbs with orchestrated and spearheaded").
3. addedKeywords: Array of high-value industry terms inserted.
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            improvedContent: { type: Type.STRING },
            keyChanges: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            addedKeywords: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ['improvedContent', 'keyChanges', 'addedKeywords'],
        },
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error('Empty response received from Gemini');
    }

    return JSON.parse(text);
  } catch (error) {
    console.error('[GeminiService] Section improvement error:', error);
    const err = new Error('AI section improvement is temporarily unavailable. Please try again.');
    err.status = 503;
    throw err;
  }
}
