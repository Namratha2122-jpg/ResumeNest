import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';
import LoadingState from './LoadingState.jsx';

/**
 * Route protection for Student or Admin routes.
 * @param {Object} props
 * @param {'student' | 'admin'} [props.requiredRole='student']
 * @param {React.ReactNode} props.children
 */
export default function ProtectedRoute({ children, requiredRole = 'student' }) {
  const { user, userType, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingState message="Verifying security credentials with server..." />;
  }

  // ==========================================
  // ADMIN ROUTE PROTECTION
  // ==========================================
  if (requiredRole === 'admin') {
    // 1. Not authenticated at all -> redirect to /admin/login
    if (!user) {
      return <Navigate to="/admin/login" state={{ from: location }} replace />;
    }

    // 2. Authenticated as student trying to access admin -> Access Denied (403)
    if (userType !== 'admin') {
      return (
        <Navigate
          to="/access-denied"
          state={{
            reason: 'You do not have administrator access.',
            attemptedPath: location.pathname,
          }}
          replace
        />
      );
    }

    return children;
  }

  // ==========================================
  // STUDENT ROUTE PROTECTION
  // ==========================================
  // 1. Not authenticated at all -> redirect to /login
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // 2. Admin trying to access student route -> redirect to admin dashboard
  if (userType === 'admin') {
    return <Navigate to="/admin/dashboard" replace />;
  }

  // 3. Authenticated student with unapproved domain -> redirect to /access-denied
  if (userType !== 'student' || user.isAuthorized === false) {
    return (
      <Navigate
        to="/access-denied"
        state={{
          reason: 'Resume Nest is currently available only to students using an approved college email address.',
          domain: user.domain,
        }}
        replace
      />
    );
  }

  return children;
}
