import express from 'express';
import { authenticate } from '../middleware/authenticate.js';
import {
  verifyStudentSession,
  verifyAdminSession,
  getSession,
} from '../controllers/auth.controller.js';
import { getSampleApprovedInstitutions } from '../services/collegeDomain.service.js';

const router = express.Router();

// Student verification
router.post('/verify-student', authenticate, verifyStudentSession);

// Admin verification
router.post('/verify-admin', authenticate, verifyAdminSession);

// Backward-compatible alias for existing student verification
router.post('/verify', authenticate, verifyStudentSession);

// Universal session check (returns authoritative userType)
router.get('/session', authenticate, getSession);

// Public approved institutions discovery
router.get('/institutions', (req, res) => {
  res.json({ institutions: getSampleApprovedInstitutions() });
});

export default router;
