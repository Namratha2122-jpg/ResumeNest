import * as resumeService from '../services/resume.service.js';
import { validateResumeInput } from '../validators/resume.validator.js';

/**
 * Get all resumes for authenticated student
 * GET /api/resumes
 */
export async function getResumes(req, res, next) {
  try {
    const resumes = await resumeService.getStudentResumes(req.user.uid);
    return res.json({ resumes });
  } catch (error) {
    next(error);
  }
}

/**
 * Create a new resume
 * POST /api/resumes
 */
export async function createResume(req, res, next) {
  try {
    validateResumeInput(req.body);
    // Never trust req.body.userId - always use req.user.uid
    const resume = await resumeService.createResume(req.body, req.user.uid);
    return res.status(201).json({ resume });
  } catch (error) {
    next(error);
  }
}

/**
 * Get single resume by ID
 * GET /api/resumes/:resumeId
 */
export async function getResumeById(req, res, next) {
  try {
    const { resumeId } = req.params;
    const resume = await resumeService.getResumeById(resumeId, req.user.uid);
    return res.json({ resume });
  } catch (error) {
    next(error);
  }
}

/**
 * Update resume
 * PUT /api/resumes/:resumeId
 */
export async function updateResume(req, res, next) {
  try {
    const { resumeId } = req.params;
    validateResumeInput(req.body);
    const updated = await resumeService.updateResume(resumeId, req.body, req.user.uid);
    return res.json({ resume: updated });
  } catch (error) {
    next(error);
  }
}

/**
 * Delete resume
 * DELETE /api/resumes/:resumeId
 */
export async function deleteResume(req, res, next) {
  try {
    const { resumeId } = req.params;
    const result = await resumeService.deleteResume(resumeId, req.user.uid);
    return res.json(result);
  } catch (error) {
    next(error);
  }
}
