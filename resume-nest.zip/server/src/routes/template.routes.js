import express from 'express';
import * as templateService from '../services/template.service.js';
import { authenticate } from '../middleware/authenticate.js';

const router = express.Router();

/**
 * GET /api/templates
 * Public listing with caching and optional filters
 */
router.get('/', async (req, res, next) => {
  try {
    const { role, query } = req.query;
    const templates = await templateService.getAllTemplates({ role, query });
    return res.json({ success: true, count: templates.length, templates });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/templates/:id
 */
router.get('/:id', async (req, res, next) => {
  try {
    const template = await templateService.getTemplateById(req.params.id);
    if (!template) {
      return res.status(404).json({ error: 'Template not found' });
    }
    return res.json({ success: true, template });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/templates
 * Upload a new resume template for fellow students
 */
router.post('/', authenticate, async (req, res, next) => {
  try {
    const { title, targetRole, category, description, tags, skills, sampleBullet, rawTemplateData } = req.body;

    if (!title || !title.trim()) {
      return res.status(400).json({ error: 'Template title is required.' });
    }

    const newTemplate = await templateService.createCommunityTemplate(req.user, {
      title,
      targetRole,
      category,
      description,
      tags,
      skills,
      sampleBullet,
      rawTemplateData,
    });

    return res.status(201).json({
      success: true,
      message: 'Template published to student community and synced across live network.',
      template: newTemplate,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/templates/:id/upvote
 * Real-time upvote template
 */
router.post('/:id/upvote', async (req, res, next) => {
  try {
    const template = await templateService.upvoteTemplate(req.params.id);
    if (!template) {
      return res.status(404).json({ error: 'Template not found' });
    }
    return res.json({ success: true, upvotes: template.upvotes });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/templates/:id/use
 * Increment usage counter
 */
router.post('/:id/use', async (req, res, next) => {
  try {
    const template = await templateService.incrementUseCount(req.params.id);
    return res.json({ success: true, usesCount: template?.usesCount || 1 });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/templates/:id/download
 * Record download and trigger real-time broadcast
 */
router.post('/:id/download', async (req, res, next) => {
  try {
    const template = await templateService.recordDownload(req.params.id);
    if (!template) {
      return res.status(404).json({ error: 'Template not found' });
    }
    return res.json({
      success: true,
      downloadCount: template.downloadCount,
      template,
    });
  } catch (error) {
    next(error);
  }
});

export default router;
