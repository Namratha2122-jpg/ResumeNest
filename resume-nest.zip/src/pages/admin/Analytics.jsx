import React, { useEffect, useState } from 'react';
import api from '../../services/api.js';
import LoadingState from '../../components/LoadingState.jsx';
import ErrorState from '../../components/ErrorState.jsx';
import {
  BarChart3,
  TrendingUp,
  Target,
  Sparkles,
  AlertCircle,
  Users,
  FileText,
} from 'lucide-react';

export default function Analytics() {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchAnalytics = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.get('/admin/analytics');
      setAnalytics(data);
    } catch (err) {
      setError(err.message || 'Failed to calculate analytics metrics.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  if (loading) {
    return <LoadingState message="Calculating real-time database metrics..." />;
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <ErrorState title="Analytics Error" message={error} onRetry={fetchAnalytics} />
      </div>
    );
  }

  const hasData = analytics?.hasEnoughData;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800">
        <h1 className="text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
          <BarChart3 className="w-6 h-6 text-indigo-400" />
          <span>Real-Time Database Analytics</span>
        </h1>
        <p className="text-xs text-slate-400">
          Strictly derived from live Firestore records. No fabricated or simulated statistics.
        </p>
      </div>

      {/* Primary KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Registered Students</span>
            <Users className="w-4 h-4 text-indigo-400" />
          </div>
          <p className="text-3xl font-black text-white">{analytics?.totalStudents ?? 0}</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Resumes Stored</span>
            <FileText className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-3xl font-black text-white">{analytics?.totalResumes ?? 0}</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Gemini Analyses Executed</span>
            <Sparkles className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-3xl font-black text-white">{analytics?.totalAnalyses ?? 0}</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Avg AI ATS Score</span>
            <TrendingUp className="w-4 h-4 text-blue-400" />
          </div>
          <p className="text-3xl font-black text-blue-400">
            {analytics?.averageAtsScore !== null ? `${analytics.averageAtsScore} / 100` : '—'}
          </p>
        </div>
      </div>

      {!hasData ? (
        <div className="p-12 text-center bg-slate-900/40 rounded-2xl border border-dashed border-slate-800 space-y-2 max-w-lg mx-auto">
          <AlertCircle className="w-8 h-8 text-slate-500 mx-auto" />
          <h3 className="text-sm font-bold text-white">Not enough data to calculate this metric</h3>
          <p className="text-xs text-slate-400">
            Skill gap distributions and average ATS scores will automatically populate once students run resume diagnostics.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Top Identified Skill Gaps */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Most Common Identified Skill Gaps</span>
              </h3>
            </div>

            {analytics?.topSkillGaps?.length > 0 ? (
              <div className="space-y-3">
                {analytics.topSkillGaps.map((item, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200">{item.skill}</span>
                      <span className="text-slate-400 font-mono">{item.count} resumes</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-amber-400 rounded-full"
                        style={{
                          width: `${Math.min(100, Math.max(10, (item.count / (analytics.totalAnalyses || 1)) * 100))}%`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic">Not enough data to calculate this metric.</p>
            )}
          </div>

          {/* Most Selected Target Roles */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <Target className="w-4 h-4 text-indigo-400" />
                <span>Target Career Role Distribution</span>
              </h3>
            </div>

            {analytics?.topTargetRoles?.length > 0 ? (
              <div className="space-y-3">
                {analytics.topTargetRoles.map((item, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200">{item.role}</span>
                      <span className="text-slate-400 font-mono">{item.count} students</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-indigo-500 rounded-full"
                        style={{
                          width: `${Math.min(100, Math.max(10, (item.count / (analytics.totalResumes || 1)) * 100))}%`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic">Not enough data to calculate this metric.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
