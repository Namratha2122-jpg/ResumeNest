import crypto from 'crypto';
import { firestoreDb } from '../config/firebaseAdmin.js';

// In-memory persistent database store (used when Firestore Admin SDK credentials are not mounted)
const memoryStore = {
  resumes: new Map(),
  profiles: new Map(),
  analyses: new Map(),
};

/**
 * Validates ownership of a resume
 * Throws 403 error if resume does not belong to the user
 */
function verifyOwnership(resume, userId) {
  if (!resume) {
    const error = new Error('Resume not found.');
    error.status = 404;
    throw error;
  }
  if (resume.userId !== userId) {
    const error = new Error('You do not have permission to access this resume.');
    error.status = 403;
    throw error;
  }
}

/**
 * Get all resumes belonging to the authenticated student
 */
export async function getStudentResumes(userId) {
  if (firestoreDb) {
    const snapshot = await firestoreDb.collection('resumes').where('userId', '==', userId).get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }

  // Fallback to local store
  const userResumes = [];
  for (const [id, item] of memoryStore.resumes.entries()) {
    if (item.userId === userId) {
      userResumes.push({ id, ...item });
    }
  }
  return userResumes.sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));
}

/**
 * Get a single resume by ID, strictly enforcing student ownership
 */
export async function getResumeById(resumeId, userId) {
  let resume = null;

  if (firestoreDb) {
    const doc = await firestoreDb.collection('resumes').doc(resumeId).get();
    if (doc.exists) {
      resume = { id: doc.id, ...doc.data() };
    }
  } else {
    const raw = memoryStore.resumes.get(resumeId);
    if (raw) {
      resume = { id: resumeId, ...raw };
    }
  }

  verifyOwnership(resume, userId);
  return resume;
}

/**
 * Create a new resume for authenticated student
 */
export async function createResume(resumeData, userId) {
  const resumeId = 'res_' + crypto.randomBytes(8).toString('hex');
  const now = new Date().toISOString();

  // Enforce userId assignment from authenticated context
  const newResume = {
    ...resumeData,
    id: resumeId,
    userId: userId,
    createdAt: now,
    updatedAt: now,
  };

  if (firestoreDb) {
    await firestoreDb.collection('resumes').doc(resumeId).set(newResume);
  } else {
    memoryStore.resumes.set(resumeId, newResume);
  }

  return newResume;
}

/**
 * Update an existing resume, strictly enforcing student ownership
 */
export async function updateResume(resumeId, updateData, userId) {
  // 1. Fetch and verify ownership
  const existing = await getResumeById(resumeId, userId);

  // 2. Prevent changing userId or id
  const { id: _id, userId: _userId, createdAt: _createdAt, ...allowedUpdates } = updateData;

  const updatedResume = {
    ...existing,
    ...allowedUpdates,
    id: resumeId,
    userId: userId,
    updatedAt: new Date().toISOString(),
  };

  if (firestoreDb) {
    await firestoreDb.collection('resumes').doc(resumeId).set(updatedResume, { merge: true });
  } else {
    memoryStore.resumes.set(resumeId, updatedResume);
  }

  return updatedResume;
}

/**
 * Delete a resume, strictly enforcing student ownership
 */
export async function deleteResume(resumeId, userId) {
  // Fetch and verify ownership
  await getResumeById(resumeId, userId);

  if (firestoreDb) {
    await firestoreDb.collection('resumes').doc(resumeId).delete();
  } else {
    memoryStore.resumes.delete(resumeId);
  }

  return { success: true, message: 'Resume deleted successfully.' };
}

/**
 * Save analysis results for a resume
 */
export async function saveAnalysisResult(resumeId, userId, analysisData) {
  const analysisId = 'anl_' + resumeId;
  const record = {
    id: analysisId,
    resumeId,
    userId,
    ...analysisData,
    savedAt: new Date().toISOString(),
  };

  if (firestoreDb) {
    await firestoreDb.collection('analysisResults').doc(analysisId).set(record);
  } else {
    memoryStore.analyses.set(analysisId, record);
  }

  return record;
}

/**
 * Get analysis result for a resume, strictly enforcing student ownership
 */
export async function getAnalysisResult(resumeId, userId) {
  // Verify user owns the resume first
  await getResumeById(resumeId, userId);

  const analysisId = 'anl_' + resumeId;
  if (firestoreDb) {
    const doc = await firestoreDb.collection('analysisResults').doc(analysisId).get();
    return doc.exists ? doc.data() : null;
  }
  return memoryStore.analyses.get(analysisId) || null;
}
