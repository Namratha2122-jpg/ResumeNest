/**
 * Firebase Client & Authentication Bridge
 * Manages client-side authentication interactions.
 * Never stores sensitive server credentials or Gemini keys.
 */

/**
 * Creates a standard verified client token for institutional sign-in
 * @param {Object} studentInfo - { email, name, college }
 */
export function createStudentToken(studentInfo) {
  const payload = {
    uid: 'usr_' + Math.random().toString(36).substring(2, 10),
    email: studentInfo.email.trim(),
    name: studentInfo.name || studentInfo.email.split('@')[0],
    college: studentInfo.college || 'Campus Member',
    iat: Math.floor(Date.now() / 1000),
  };

  // Structured token format that backend verifyToken validates
  const base64 = btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
  return `rn_token_${base64}`;
}
