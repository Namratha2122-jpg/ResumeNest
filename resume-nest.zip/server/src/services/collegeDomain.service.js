/**
 * College Domain Service
 * Authoritative backend check for approved university and college email domains.
 * The frontend MUST NEVER decide whether a domain is authorized.
 */

// List of recognized institution domains and human-friendly college names
const INSTITUTION_CATALOG = {
  'mit.edu': 'Massachusetts Institute of Technology',
  'stanford.edu': 'Stanford University',
  'berkeley.edu': 'University of California, Berkeley',
  'harvard.edu': 'Harvard University',
  'cmu.edu': 'Carnegie Mellon University',
  'cornell.edu': 'Cornell University',
  'columbia.edu': 'Columbia University',
  'princeton.edu': 'Princeton University',
  'gatech.edu': 'Georgia Institute of Technology',
  'ucla.edu': 'University of California, Los Angeles',
  'utexas.edu': 'University of Texas at Austin',
  'illinois.edu': 'University of Illinois Urbana-Champaign',
  'umich.edu': 'University of Michigan',
  'washington.edu': 'University of Washington',
  'purdue.edu': 'Purdue University',
  'nyu.edu': 'New York University',
  'caltech.edu': 'California Institute of Technology',
  'yale.edu': 'Yale University',
  'upenn.edu': 'University of Pennsylvania',
  'usc.edu': 'University of Southern California',
  'ucsd.edu': 'University of California, San Diego',
  'wisc.edu': 'University of Wisconsin-Madison',
  'osu.edu': 'Ohio State University',
  'asu.edu': 'Arizona State University',
  'ox.ac.uk': 'University of Oxford',
  'cam.ac.uk': 'University of Cambridge',
  'utoronto.ca': 'University of Toronto',
  'uwaterloo.ca': 'University of Waterloo',
  'iitb.ac.in': 'Indian Institute of Technology Bombay',
  'iitd.ac.in': 'Indian Institute of Technology Delhi',
  'iitk.ac.in': 'Indian Institute of Technology Kanpur',
  'iitm.ac.in': 'Indian Institute of Technology Madras',
  'bits-pilani.ac.in': 'BITS Pilani',
  'nus.edu.sg': 'National University of Singapore',
  'tum.de': 'Technical University of Munich',
  'ethz.ch': 'ETH Zurich',
};

// Explicitly blocked consumer webmail providers
const BLOCKED_DOMAINS = new Set([
  'gmail.com',
  'yahoo.com',
  'hotmail.com',
  'outlook.com',
  'icloud.com',
  'aol.com',
  'mail.com',
  'zoho.com',
  'protonmail.com',
  'proton.me',
  'yandex.com',
  'gmx.com',
]);

/**
 * Checks whether an email domain is authorized as an approved college domain.
 * @param {string} domain - Domain extracted from email (e.g. "stanford.edu")
 * @returns {boolean}
 */
export function isDomainAuthorized(domain) {
  if (!domain || typeof domain !== 'string') return false;
  const cleanDomain = domain.toLowerCase().trim();

  // Explicitly reject consumer webmail
  if (BLOCKED_DOMAINS.has(cleanDomain)) {
    return false;
  }

  // 1. Direct match in institution catalog
  if (INSTITUTION_CATALOG[cleanDomain]) {
    return true;
  }

  // 2. Academic Top-Level and Second-Level Domains
  // e.g. .edu, .edu.*, .ac.*, .uni-*
  if (
    cleanDomain.endsWith('.edu') ||
    cleanDomain.endsWith('.edu.in') ||
    cleanDomain.endsWith('.edu.au') ||
    cleanDomain.endsWith('.edu.sg') ||
    cleanDomain.endsWith('.edu.cn') ||
    cleanDomain.endsWith('.edu.ph') ||
    cleanDomain.endsWith('.ac.in') ||
    cleanDomain.endsWith('.ac.uk') ||
    cleanDomain.endsWith('.ac.nz') ||
    cleanDomain.endsWith('.ac.za') ||
    cleanDomain.endsWith('.ac.jp') ||
    cleanDomain.endsWith('.ac.kr') ||
    cleanDomain.endsWith('.edu.pk') ||
    cleanDomain.endsWith('.edu.ng')
  ) {
    return true;
  }

  return false;
}

/**
 * Returns the college/university name for a domain, or a formatted name based on domain.
 * @param {string} domain 
 * @returns {string}
 */
export function getCollegeName(domain) {
  if (!domain) return 'University';
  const cleanDomain = domain.toLowerCase().trim();
  if (INSTITUTION_CATALOG[cleanDomain]) {
    return INSTITUTION_CATALOG[cleanDomain];
  }
  const parts = cleanDomain.split('.');
  if (parts.length >= 2) {
    const main = parts[0];
    return main.charAt(0).toUpperCase() + main.slice(1) + ' University';
  }
  return 'College';
}

/**
 * Returns a list of sample approved institutions for demo / guidance.
 */
export function getSampleApprovedInstitutions() {
  return Object.entries(INSTITUTION_CATALOG).map(([domain, name]) => ({
    domain,
    name,
    sampleEmail: `student@${domain}`,
  }));
}
