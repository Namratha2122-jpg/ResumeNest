import express from 'express';
import { realtimeHub } from '../services/realtime.service.js';
import { globalCache } from '../services/cache.service.js';

const router = express.Router();

/**
 * GET /api/realtime/stream
 * Server-Sent Events (SSE) connection stream
 */
router.get('/stream', (req, res) => {
  // Set SSE Headers
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no', // Disable proxy buffering for nginx / Google Cloud Run
  });

  res.flushHeaders?.();

  const clientId = realtimeHub.registerClient(res, {
    ip: req.ip,
    userAgent: req.headers['user-agent'] || '',
  });

  req.on('close', () => {
    // Handled in realtimeHub registerClient
  });
});

/**
 * GET /api/realtime/metrics
 * Returns real-time health, server scalability, and throughput metrics
 */
router.get('/metrics', (req, res) => {
  const realtimeMetrics = realtimeHub.getMetrics();
  const cacheMetrics = globalCache.getStats();

  const memoryUsage = process.memoryUsage();

  return res.json({
    status: 'healthy',
    scaleReachTarget: '10,000 - 50,000+ Concurrent Requests',
    realtime: realtimeMetrics,
    cache: cacheMetrics,
    system: {
      uptimeSeconds: Math.floor(process.uptime()),
      memoryHeapUsedMB: (memoryUsage.heapUsed / 1024 / 1024).toFixed(2),
      memoryHeapTotalMB: (memoryUsage.heapTotal / 1024 / 1024).toFixed(2),
      memoryRssMB: (memoryUsage.rss / 1024 / 1024).toFixed(2),
      nodeVersion: process.version,
    },
    timestamp: new Date().toISOString(),
  });
});

export default router;
