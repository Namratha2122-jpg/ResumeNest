import express from 'express';
import { authenticate } from '../middleware/authenticate.js';
import { authorizeStudent } from '../middleware/authorizeStudent.js';
import {
  getCourses,
  getRecommendedCourses,
} from '../controllers/course.controller.js';

const router = express.Router();

// Publicly browse active free courses
router.get('/', getCourses);

// Get courses matched to authenticated student's skill gaps
router.get('/recommended/:resumeId', authenticate, authorizeStudent, getRecommendedCourses);

export default router;
