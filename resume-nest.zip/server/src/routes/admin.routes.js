import express from 'express';
import { authenticate } from '../middleware/authenticate.js';
import { authorizeAdmin, requirePermission } from '../middleware/authorizeAdmin.js';
import {
  getDashboard,
  getStudents,
  getCourses,
  createCourse,
  updateCourse,
  deleteCourse,
  toggleCourseActive,
  getAnalytics,
  getSettings,
  addDomain,
  updateDomain,
  deleteDomain,
  getAdminProfile,
} from '../controllers/admin.controller.js';

const router = express.Router();

// Strict admin middleware pipeline
router.use(authenticate);
router.use(authorizeAdmin);

// Dashboard
router.get('/dashboard', getDashboard);

// Students Management
router.get('/students', requirePermission('view_students'), getStudents);

// Courses Management
router.get('/courses', requirePermission('manage_courses'), getCourses);
router.post('/courses', requirePermission('manage_courses'), createCourse);
router.put('/courses/:courseId', requirePermission('manage_courses'), updateCourse);
router.delete('/courses/:courseId', requirePermission('manage_courses'), deleteCourse);
router.patch('/courses/:courseId/active', requirePermission('manage_courses'), toggleCourseActive);

// Analytics
router.get('/analytics', requirePermission('view_analytics'), getAnalytics);

// Settings (approved college domains)
router.get('/settings', requirePermission('manage_settings'), getSettings);
router.post('/settings/domains', requirePermission('manage_settings'), addDomain);
router.put('/settings/domains/:domainId', requirePermission('manage_settings'), updateDomain);
router.delete('/settings/domains/:domainId', requirePermission('manage_settings'), deleteDomain);

// Profile
router.get('/profile', getAdminProfile);

export default router;
