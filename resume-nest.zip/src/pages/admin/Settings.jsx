import React, { useEffect, useState } from 'react';
import api from '../../services/api.js';
import LoadingState from '../../components/LoadingState.jsx';
import ErrorState from '../../components/ErrorState.jsx';
import {
  Settings as SettingsIcon,
  ShieldCheck,
  Plus,
  Power,
  Trash2,
  X,
  Save,
  CheckCircle2,
} from 'lucide-react';

export default function Settings() {
  const [domains, setDomains] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // New domain form state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [domainInput, setDomainInput] = useState('');
  const [nameInput, setNameInput] = useState('');
  const [activeInput, setActiveInput] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const fetchDomains = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.get('/admin/settings');
      setDomains(data.approvedCollegeDomains || []);
    } catch (err) {
      setError(err.message || 'Failed to load approved college domains.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDomains();
  }, []);

  const handleToggleActive = async (id, currentActive) => {
    try {
      const updated = await api.put(`/admin/settings/domains/${id}`, {
        active: !currentActive,
      });
      setDomains((prev) =>
        prev.map((d) => (d.id === id ? { ...d, active: !currentActive } : d))
      );
    } catch (err) {
      alert(err.message || 'Failed to update domain status');
    }
  };

  const handleDelete = async (id, domain) => {
    if (confirm(`Remove approved college domain "${domain}"? Students with this email domain will lose access.`)) {
      try {
        await api.delete(`/admin/settings/domains/${id}`);
        setDomains((prev) => prev.filter((d) => d.id !== id));
      } catch (err) {
        alert(err.message || 'Failed to delete domain');
      }
    }
  };

  const handleAddDomain = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const created = await api.post('/admin/settings/domains', {
        domain: domainInput,
        collegeName: nameInput,
        active: activeInput,
      });
      setDomains((prev) => [created.domain, ...prev]);
      setIsModalOpen(false);
      setDomainInput('');
      setNameInput('');
    } catch (err) {
      alert(err.message || 'Failed to add domain');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <LoadingState message="Loading approved college domain registry..." />;
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <ErrorState title="Settings Error" message={error} onRetry={fetchDomains} />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <SettingsIcon className="w-6 h-6 text-indigo-400" />
            <span>Approved College Domains</span>
          </h1>
          <p className="text-xs text-slate-400">
            Control the academic gatekeeper. Only students from active domains in this registry are permitted to log in.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Add Approved Domain</span>
        </button>
      </div>

      {/* Registry Table */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-[11px] text-slate-400 uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="px-5 py-3.5">College Domain</th>
                <th className="px-5 py-3.5">Institution / University Name</th>
                <th className="px-5 py-3.5">Gatekeeper Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {domains.map((item) => (
                <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="px-5 py-3.5 font-mono font-bold text-white">
                    @{item.domain}
                  </td>
                  <td className="px-5 py-3.5">
                    <span className="font-medium text-slate-200">🎓 {item.collegeName}</span>
                  </td>
                  <td className="px-5 py-3.5">
                    <button
                      onClick={() => handleToggleActive(item.id, item.active)}
                      className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[10px] font-semibold transition-colors ${
                        item.active
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      <Power className="w-3 h-3" />
                      <span>{item.active ? 'Approved & Active' : 'Suspended'}</span>
                    </button>
                  </td>
                  <td className="px-5 py-3.5 text-right">
                    <button
                      onClick={() => handleDelete(item.id, item.domain)}
                      className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors"
                      title="Delete domain"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Domain Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Add Approved College Domain</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddDomain} className="space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                  Email Domain * (e.g. stanford.edu, iitb.ac.in)
                </label>
                <input
                  type="text"
                  value={domainInput}
                  onChange={(e) => setDomainInput(e.target.value)}
                  required
                  placeholder="e.g. mit.edu"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                  Institution Name *
                </label>
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  required
                  placeholder="e.g. Massachusetts Institute of Technology"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="pt-2">
                <label className="flex items-center space-x-2 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={activeInput}
                    onChange={(e) => setActiveInput(e.target.checked)}
                    className="rounded bg-slate-950 border-slate-800 text-indigo-600 focus:ring-0"
                  />
                  <span>Active immediately</span>
                </label>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-medium hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center space-x-1.5 px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{submitting ? 'Adding...' : 'Add Domain'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
