import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useResume } from '../hooks/useResume.js';
import api from '../services/api.js';
import CourseCard from '../components/CourseCard.jsx';
import LoadingState from '../components/LoadingState.jsx';
import {
  BookOpen,
  Search,
  Filter,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

const CATEGORIES = [
  'All',
  'Computer Science',
  'Web Development',
  'Software Engineering',
  'Artificial Intelligence',
  'Data Science',
  'Cloud & DevOps',
  'Database & Backend',
  'Systems & DevOps',
];

export default function Courses() {
  const [searchParams] = useSearchParams();
  const resumeId = searchParams.get('resumeId');
  const { fetchRecommendedCourses } = useResume();

  const [courses, setCourses] = useState([]);
  const [matchedSkills, setMatchedSkills] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadCourses() {
      setLoading(true);
      try {
        // If a resumeId is in query params, fetch specific recommendations first
        if (resumeId) {
          const recData = await fetchRecommendedCourses(resumeId);
          if (recData?.missingSkills) {
            setMatchedSkills(recData.missingSkills);
          }
        }

        // Fetch full verified catalog
        const res = await api.get('/courses');
        setCourses(res.courses || []);
      } catch (err) {
        console.error('Failed to load courses:', err);
      } finally {
        setLoading(false);
      }
    }

    loadCourses();
  }, [resumeId]);

  const filteredCourses = courses.filter((course) => {
    const matchesCategory =
      selectedCategory === 'All' || course.category?.toLowerCase() === selectedCategory.toLowerCase();

    const matchesSearch =
      searchQuery.trim() === '' ||
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.provider.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.skills?.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCategory && matchesSearch;
  });

  if (loading) {
    return <LoadingState message="Loading verified free courses catalog..." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-xl space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center space-x-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>100% Free & Verified Catalog</span>
          </span>
          {matchedSkills.length > 0 && (
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center space-x-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Targeting {matchedSkills.length} Identified Skill Gaps</span>
            </span>
          )}
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Free University & Industry Course Bridge
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
          Curated zero-cost courses from Harvard, MIT, Stanford, freeCodeCamp, DeepLearning.AI, and Google Cloud. Bridge resume deficiencies without spending a dime.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search skills, providers, titles..."
            className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>
      </div>

      {/* Courses Grid */}
      {filteredCourses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map((course) => (
            <CourseCard
              key={course.id}
              course={course}
              highlightedSkills={matchedSkills}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-slate-900/40 rounded-2xl border border-dashed border-slate-800 space-y-2">
          <BookOpen className="w-8 h-8 text-slate-500 mx-auto" />
          <p className="text-sm font-semibold text-slate-300">No courses match your filter criteria.</p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
            }}
            className="text-xs text-indigo-400 hover:underline"
          >
            Clear filters
          </button>
        </div>
      )}
    </div>
  );
}
