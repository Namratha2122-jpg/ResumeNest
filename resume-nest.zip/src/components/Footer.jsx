import React from 'react';
import { GraduationCap, ShieldCheck, Cpu, BookOpen, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="relative z-10 bg-slate-950/90 border-t border-slate-800/80 text-slate-400 text-xs backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center space-x-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-cyan-400 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="font-black text-base bg-gradient-to-r from-white via-indigo-200 to-cyan-300 bg-clip-text text-transparent">
                Resume Nest
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Empowering university engineering students with authoritative ATS resume screening, Google X-Y-Z bullet rewrites, and 100% free verified university course matching.
            </p>
          </div>

          {/* Architecture & Security */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Security Architecture</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Authoritative Domain Gatekeeper</span>
              </li>
              <li className="flex items-center space-x-2">
                <Cpu className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <span>Server-Side Gemini 3.8 Flash</span>
              </li>
              <li className="flex items-center space-x-2">
                <BookOpen className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>Curated Verified Free Courses</span>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Quick Navigation</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/courses" className="text-slate-300 hover:text-cyan-400 transition-colors">Free Course Directory</Link>
              </li>
              <li>
                <Link to="/builder" className="text-slate-300 hover:text-cyan-400 transition-colors">ATS Resume Builder</Link>
              </li>
              <li>
                <Link to="/dashboard" className="text-slate-300 hover:text-cyan-400 transition-colors">Student Dashboard</Link>
              </li>
              <li>
                <Link to="/admin/login" className="text-slate-400 hover:text-indigo-400 transition-colors">Admin Portal</Link>
              </li>
            </ul>
          </div>

          {/* Compliance & Standard */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">ATS 10-Factor Engine</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Scoring strictly complies with industry recruitment algorithms across 10 weighted metrics: Contact (5%), Summary (10%), Education (10%), Skills (15%), Experience (15%), Projects (15%), Certifications (5%), Keywords (10%), Formatting (5%), and Role Relevance (10%).
            </p>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 gap-4">
          <p>© {new Date().getFullYear()} Resume Nest. Built for college & university engineering students.</p>
          <div className="flex items-center space-x-1.5 text-slate-300 font-mono">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Zero Client-Side Secret Leakage</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
