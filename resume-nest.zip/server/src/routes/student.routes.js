import express from 'express';
import { authenticate } from '../middleware/authenticate.js';
import { authorizeStudent } from '../middleware/authorizeStudent.js';
import {
  getProfile,
  updateProfile,
  getResumes,
  createResume,
  getResumeById,
  updateResume,
  deleteResume,
  analyzeResume,
  getAnalysis,
  improveSection,
  getCourses,
  getRecommendations,
} from '../controllers/student.controller.js';

const router = express.Router();

// Strict student middleware pipeline
router.use(authenticate);
router.use(authorizeStudent);

// Profile
router.get('/profile', getProfile);
router.put('/profile', updateProfile);

// Resumes
router.get('/resumes', getResumes);
router.post('/resumes', createResume);
router.get('/resumes/:resumeId', getResumeById);
router.put('/resumes/:resumeId', updateResume);
router.delete('/resumes/:resumeId', deleteResume);

// Analysis
router.post('/analysis/:resumeId', analyzeResume);
router.get('/analysis/:resumeId', getAnalysis);
router.post('/improve', improveSection);

// Courses & Recommendations
router.get('/courses', getCourses);
router.get('/recommendations/:resumeId', getRecommendations);

export default router;
