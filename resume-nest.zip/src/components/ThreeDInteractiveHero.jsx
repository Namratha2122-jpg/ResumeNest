import React, { useState } from 'react';
import { Sparkles, Bot, ArrowRight, CheckCircle2, Flame, Smile, AlertCircle, ThumbsUp, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';

const FUNNY_BULLETS = [
  {
    raw: 'I attended team standups and smiled politely.',
    toast: 'Facilitated cross-functional sprint alignment across 6 engineering stakeholders, boosting squad delivery cadence by 18%.',
    robotMood: 'impressed',
    score: 96,
    reaction: 'The ATS recruiter algorithm just sent an interview invite while wiping a tear.',
    badge: '10/10 Recruiter Catnip',
  },
  {
    raw: 'Built a website using HTML and 14 Stack Overflow tabs.',
    toast: 'Engineered responsive single-page architecture utilizing semantic web standards and optimized DOM rendering cycles.',
    robotMood: 'impressed',
    score: 91,
    reaction: 'Stack Overflow copy-paste disguised as senior architecture. The robot approves.',
    badge: 'Silicon Valley Approved',
  },
  {
    raw: 'Fixed a stubborn bug by deleting the failing test file.',
    toast: 'Refactored end-to-end regression test suite, streamlining CI/CD deployment pipelines and mitigating false-positive blockers.',
    robotMood: 'hilarious',
    score: 88,
    reaction: 'Chaotic good engineering energy. Reframed into pure DevOps productivity.',
    badge: 'Zero Fluff Guaranteed',
  },
  {
    raw: 'Made the coffee and did not set the lab equipment on fire.',
    toast: 'Managed critical daily resource provisioning and maintained 100% operational hardware safety compliance in research lab.',
    robotMood: 'legendary',
    score: 94,
    reaction: 'Even the campus printer gave a standing ovation for this phrasing.',
    badge: 'Executive Level Caffeine',
  },
];

export default function ThreeDInteractiveHero() {
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [showToast, setShowToast] = useState(true);

  const current = FUNNY_BULLETS[selectedIdx];

  return (
    <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-12">
      {/* 3D Floating Decorative Elements */}
      <div className="absolute top-10 left-4 hidden lg:block animate-float pointer-events-none z-20">
        <div className="p-3.5 rounded-2xl bg-slate-900/90 border-2 border-indigo-500/40 shadow-2xl backdrop-blur-md rotate-[-6deg]">
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-300">
            <span className="text-base">🤖</span>
            <span>ATS Bot Mood: Impressed</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-1 font-mono">0% Recruiter Eye-Roll Guarantee</p>
        </div>
      </div>

      <div className="absolute top-16 right-4 hidden lg:block animate-float-slow pointer-events-none z-20">
        <div className="p-3.5 rounded-2xl bg-slate-900/90 border-2 border-emerald-500/40 shadow-2xl backdrop-blur-md rotate-[5deg]">
          <div className="flex items-center space-x-2 text-xs font-bold text-emerald-400">
            <span className="text-base">🚀</span>
            <span>Google X-Y-Z Formula Active</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-1 font-mono">Accomplished [X] by [Z] with [Y]</p>
        </div>
      </div>

      {/* Main 3D Card Stage */}
      <div className="perspective-1000">
        <div className="rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border-2 border-indigo-500/30 shadow-[0_25px_60px_-15px_rgba(79,70,229,0.35)] p-6 sm:p-10 relative overflow-hidden preserve-3d">
          
          {/* Subtle isometric grid background */}
          <div className="absolute inset-0 isometric-grid opacity-30 pointer-events-none" />

          {/* Header Tagline */}
          <div className="relative z-10 text-center space-y-3 mb-8">
            <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-indigo-500/15 border border-indigo-400/30 text-indigo-300 text-xs font-bold shadow-inner">
              <span className="animate-spin text-sm">✨</span>
              <span>Interactive 3D Resume Transformer</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Watch Honest College Truths Turn into Recruiter Gold
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto">
              Click any campus bullet point below. See how server-side Gemini diagnoses the gap and upgrades your wording with quantifiable impact.
            </p>
          </div>

          {/* Interactive Selector Tabs */}
          <div className="relative z-10 grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
            {FUNNY_BULLETS.map((item, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setSelectedIdx(idx);
                  setShowToast(true);
                }}
                className={`p-3 rounded-xl text-left text-xs font-semibold transition-all border ${
                  selectedIdx === idx
                    ? 'bg-indigo-600/30 border-indigo-500 text-white shadow-lg shadow-indigo-600/20 translate-y-[-2px]'
                    : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center space-x-1.5 mb-1 text-[11px] font-bold">
                  <span>{idx === 0 ? '☕' : idx === 1 ? '💻' : idx === 2 ? '🐛' : '🧪'}</span>
                  <span>Option {idx + 1}</span>
                </div>
                <p className="truncate text-[11px] text-slate-300">{item.raw}</p>
              </button>
            ))}
          </div>

          {/* 3D Comparison Stage */}
          <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
            
            {/* Raw Student Reality */}
            <div className="rounded-2xl bg-slate-950/90 border border-rose-500/30 p-5 sm:p-6 flex flex-col justify-between space-y-4 shadow-xl">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <span className="text-base">😴</span>
                    <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">
                      The Raw College Experience
                    </span>
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/20">
                    ATS Score: 32/100
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-sm font-mono text-slate-300 italic">
                  "{current.raw}"
                </div>

                <div className="mt-4 space-y-1.5 text-xs text-slate-400">
                  <p className="text-rose-400 font-semibold flex items-center space-x-1.5">
                    <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>Recruiter Reality Check:</span>
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Passive voice, zero metric indicators, and zero technical keyword matches. The recruiter bot drops this into the void within 3 seconds.
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                <span>Result: Automated rejection email</span>
                <span>Time: 2:04 AM</span>
              </div>
            </div>

            {/* Resume Nest Transformed */}
            <div className="rounded-2xl bg-gradient-to-br from-indigo-950/80 via-slate-950 to-slate-900 border-2 border-emerald-500/40 p-5 sm:p-6 flex flex-col justify-between space-y-4 shadow-2xl relative overflow-hidden">
              <div className="absolute -top-12 -right-12 w-32 h-32 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />

              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <span className="text-base">🚀</span>
                    <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                      After Resume Nest AI Polish
                    </span>
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center space-x-1">
                    <Sparkles className="w-3 h-3 text-amber-300" />
                    <span>ATS Score: {current.score}/100</span>
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/90 border border-indigo-500/30 text-sm font-semibold text-white leading-relaxed shadow-inner">
                  "{current.toast}"
                </div>

                <div className="mt-4 p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 space-y-1">
                  <p className="text-xs font-bold text-indigo-300 flex items-center space-x-1.5">
                    <Bot className="w-4 h-4 text-amber-400 flex-shrink-0" />
                    <span>Nestor's Verdict:</span>
                  </p>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    {current.reaction}
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] font-bold text-emerald-400 flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{current.badge}</span>
                </span>

                <Link
                  to="/login"
                  className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/30 transition-all active:scale-95"
                >
                  <span>Build Yours Free</span>
                  <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
            </div>

          </div>

          {/* Interactive Bottom Trust Ribbon */}
          <div className="relative z-10 mt-8 pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
            <div className="flex items-center space-x-2">
              <span className="text-emerald-400 font-bold">✓ 100% Free for Students</span>
              <span>·</span>
              <span>Verified .edu & .ac.in Access Only</span>
            </div>

            <div className="flex items-center space-x-4">
              <span className="text-slate-300 font-medium">Want to test your full resume?</span>
              <Link
                to="/login"
                className="text-indigo-400 hover:text-indigo-300 font-bold underline underline-offset-4"
              >
                Sign in with campus account →
              </Link>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
