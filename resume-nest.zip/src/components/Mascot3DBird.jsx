import React, { useState } from 'react';

export default function Mascot3DBird({ className = 'w-48 h-48', message = "I eat ATS parser traps for breakfast! 🦉✨" }) {
  const [isWinking, setIsWinking] = useState(false);

  return (
    <div
      className={`relative flex flex-col items-center select-none group cursor-pointer ${className}`}
      onMouseEnter={() => setIsWinking(true)}
      onMouseLeave={() => setIsWinking(false)}
      onClick={() => setIsWinking(!isWinking)}
    >
      {/* Speech Bubble */}
      {message && (
        <div className="absolute -top-12 px-3 py-1.5 rounded-xl bg-slate-900 border-2 border-indigo-500/60 shadow-xl text-[11px] font-bold text-white whitespace-nowrap animate-float z-30 flex items-center space-x-1.5">
          <span>{message}</span>
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[6px] border-t-indigo-500/60" />
        </div>
      )}

      {/* 3D Owl Bot SVG */}
      <svg
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full filter drop-shadow-[0_20px_25px_rgba(79,70,229,0.35)] transition-transform duration-300 group-hover:scale-105 group-hover:rotate-1"
      >
        <defs>
          {/* Radial & Linear 3D Gradients */}
          <linearGradient id="body3d" x1="50" y1="40" x2="150" y2="180" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#818CF8" />
            <stop offset="45%" stopColor="#4F46E5" />
            <stop offset="100%" stopColor="#312E81" />
          </linearGradient>

          <linearGradient id="belly3d" x1="100" y1="80" x2="100" y2="170" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#EEF2FF" />
            <stop offset="100%" stopColor="#C7D2FE" />
          </linearGradient>

          <linearGradient id="gold3d" x1="80" y1="10" x2="130" y2="40" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FCD34D" />
            <stop offset="100%" stopColor="#D97706" />
          </linearGradient>

          <linearGradient id="cap3d" x1="30" y1="30" x2="170" y2="50" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#1E1B4B" />
            <stop offset="100%" stopColor="#0F172A" />
          </linearGradient>

          <filter id="shadow3d" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="8" stdDeviation="6" floodColor="#0F172A" floodOpacity="0.5" />
          </filter>
        </defs>

        {/* Ground 3D Shadow */}
        <ellipse cx="100" cy="188" rx="60" ry="12" fill="#020617" opacity="0.6" />

        {/* Owl Main Body (Plump 3D Egg Shape) */}
        <rect x="42" y="55" width="116" height="125" rx="58" fill="url(#body3d)" filter="url(#shadow3d)" />

        {/* 3D Highlights on Body */}
        <ellipse cx="75" cy="85" rx="20" ry="35" fill="#A5B4FC" opacity="0.25" transform="rotate(-20 75 85)" />

        {/* White Belly Patch */}
        <path
          d="M62 110 C62 85, 138 85, 138 110 C138 150, 130 172, 100 172 C70 172, 62 150, 62 110 Z"
          fill="url(#belly3d)"
        />

        {/* Mini 3D Resume in Belly Pocket */}
        <rect x="80" y="115" width="40" height="52" rx="4" fill="#FFFFFF" filter="url(#shadow3d)" transform="rotate(-5 100 140)" />
        <rect x="86" y="122" width="28" height="4" rx="2" fill="#4F46E5" />
        <rect x="86" y="130" width="20" height="3" rx="1.5" fill="#94A3B8" />
        <rect x="86" y="136" width="24" height="3" rx="1.5" fill="#94A3B8" />
        <circle cx="109" cy="154" r="5" fill="#10B981" />
        <path d="M107 154 L108.5 155.5 L111.5 152.5" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" />

        {/* Wings */}
        {/* Left Wing */}
        <path
          d="M45 90 C30 110, 32 145, 52 155 C56 150, 52 115, 45 90 Z"
          fill="#3730A3"
        />
        {/* Right Wing (Holding Magnifying Glass) */}
        <path
          d="M155 90 C170 110, 168 145, 148 155 C144 150, 148 115, 155 90 Z"
          fill="#3730A3"
        />

        {/* Magnifying Glass */}
        <circle cx="165" cy="130" r="14" stroke="#F59E0B" strokeWidth="4" fill="#67E8F9" fillOpacity="0.4" />
        <line x1="155" y1="140" x2="145" y2="155" stroke="#D97706" strokeWidth="5" strokeLinecap="round" />

        {/* Cute Nerd Glasses Frame */}
        <rect x="58" y="75" width="36" height="30" rx="8" stroke="#F59E0B" strokeWidth="4.5" fill="#1E293B" />
        <rect x="106" y="75" width="36" height="30" rx="8" stroke="#F59E0B" strokeWidth="4.5" fill="#1E293B" />
        <line x1="94" y1="88" x2="106" y2="88" stroke="#F59E0B" strokeWidth="4" />

        {/* Eyes (Interactive Winking on Hover!) */}
        {isWinking ? (
          <>
            {/* Left Eye: Big cute sparkle pupil */}
            <circle cx="76" cy="90" r="8" fill="#38BDF8" />
            <circle cx="79" cy="87" r="3" fill="#FFFFFF" />
            {/* Right Eye: Wink curve */}
            <path d="M116 93 Q124 85 132 93" stroke="#F8FAFC" strokeWidth="3.5" strokeLinecap="round" fill="none" />
          </>
        ) : (
          <>
            {/* Both Eyes Open with AI Sparkle */}
            <circle cx="76" cy="90" r="8" fill="#38BDF8" />
            <circle cx="79" cy="87" r="3" fill="#FFFFFF" />
            <circle cx="124" cy="90" r="8" fill="#38BDF8" />
            <circle cx="127" cy="87" r="3" fill="#FFFFFF" />
          </>
        )}

        {/* Golden Cute 3D Beak */}
        <polygon points="100,95 91,107 109,107" fill="url(#gold3d)" />

        {/* Graduation Mortarboard Hat (3D Diamond Top) */}
        <polygon points="100,18 165,36 100,54 35,36" fill="url(#cap3d)" filter="url(#shadow3d)" />
        <polygon points="100,18 165,36 100,40 35,36" fill="#312E81" opacity="0.6" />
        <rect x="75" y="44" width="50" height="15" rx="4" fill="#0F172A" />

        {/* Hat Tassel Button & String */}
        <circle cx="100" cy="36" r="4" fill="#F59E0B" />
        <path d="M100 36 Q130 42 145 60" stroke="#FBBF24" strokeWidth="2.5" fill="none" />
        <circle cx="145" cy="62" r="3" fill="#D97706" />

        {/* Cute Feet */}
        <ellipse cx="80" cy="180" rx="8" ry="4" fill="#F59E0B" />
        <ellipse cx="120" cy="180" rx="8" ry="4" fill="#F59E0B" />
      </svg>
    </div>
  );
}
