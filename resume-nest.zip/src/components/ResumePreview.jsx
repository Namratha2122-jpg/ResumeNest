import React, { useRef, useState } from 'react';
import { Printer, Copy, Check, FileDown, Sparkles, ExternalLink, Download } from 'lucide-react';

function triggerBlobDownload(content, fileName, contentType) {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export default function ResumePreview({ resumeData }) {
  const [copied, setCopied] = useState(false);
  const [template, setTemplate] = useState('modern'); // 'modern', 'classic', 'minimal'
  const printRef = useRef(null);

  if (!resumeData) return null;

  const { personalInfo = {}, summary = '', education = [], skills = {}, experience = [], projects = [], certifications = [] } = resumeData;

  const handlePrint = () => {
    window.print();
  };

  const getPlainText = () => {
    let text = `${personalInfo.fullName || 'Student Name'}\n`;
    text += `${personalInfo.email || ''} | ${personalInfo.phone || ''} | ${personalInfo.location || ''}\n`;
    if (personalInfo.linkedin) text += `LinkedIn: ${personalInfo.linkedin}\n`;
    if (personalInfo.github) text += `GitHub: ${personalInfo.github}\n\n`;

    if (summary) text += `PROFESSIONAL SUMMARY\n${summary}\n\n`;

    if (education.length) {
      text += `EDUCATION\n`;
      education.forEach((edu) => {
        text += `${edu.institution} - ${edu.degree} (${edu.graduationYear || ''})\n`;
        if (edu.gpa) text += `GPA: ${edu.gpa}\n`;
        if (edu.coursework) text += `Coursework: ${edu.coursework}\n`;
      });
      text += '\n';
    }

    if (skills.languages || skills.frameworks || skills.developerTools) {
      text += `TECHNICAL SKILLS\n`;
      if (skills.languages) text += `Languages: ${skills.languages}\n`;
      if (skills.frameworks) text += `Frameworks: ${skills.frameworks}\n`;
      if (skills.developerTools) text += `Tools & Cloud: ${skills.developerTools}\n`;
      if (skills.coreConcepts) text += `Core Concepts: ${skills.coreConcepts}\n`;
      text += '\n';
    }

    if (experience.length) {
      text += `EXPERIENCE\n`;
      experience.forEach((exp) => {
        text += `${exp.role} | ${exp.company} (${exp.period || ''})\n`;
        exp.bullets?.forEach((b) => {
          if (b.trim()) text += `• ${b}\n`;
        });
      });
      text += '\n';
    }

    if (projects.length) {
      text += `PROJECTS\n`;
      projects.forEach((p) => {
        text += `${p.title} | ${p.technologies}\n`;
        if (p.link) text += `Link: ${p.link}\n`;
        text += `${p.description}\n`;
      });
      text += '\n';
    }

    if (certifications.length) {
      text += `CERTIFICATIONS & HONORS\n`;
      certifications.forEach((c) => (text += `• ${c}\n`));
    }

    return text;
  };

  const handleCopyText = () => {
    const text = getPlainText();
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadTxt = () => {
    const text = getPlainText();
    const cleanName = (personalInfo.fullName || 'Student_Resume').replace(/[^a-zA-Z0-9]/g, '_');
    triggerBlobDownload(text, `${cleanName}_ATS.txt`, 'text/plain');
  };

  const handleDownloadJson = () => {
    const cleanName = (personalInfo.fullName || 'Student_Resume').replace(/[^a-zA-Z0-9]/g, '_');
    triggerBlobDownload(JSON.stringify(resumeData, null, 2), `${cleanName}.json`, 'application/json');
  };

  return (
    <div className="space-y-4">
      {/* Top Preview Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-900 border border-slate-800 rounded-xl">
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-slate-300">Style:</span>
          <div className="flex rounded-lg bg-slate-950 p-1 border border-slate-800 text-xs">
            <button
              onClick={() => setTemplate('modern')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                template === 'modern' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Modern ATS
            </button>
            <button
              onClick={() => setTemplate('classic')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                template === 'classic' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Classic Ivy
            </button>
            <button
              onClick={() => setTemplate('minimal')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                template === 'minimal' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Tech Minimal
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleCopyText}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-colors"
            title="Copy plain ATS text"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Text'}</span>
          </button>

          <button
            onClick={handleDownloadTxt}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
            title="Download plain-text ATS resume"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>.TXT</span>
          </button>

          <button
            onClick={handleDownloadJson}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
            title="Download JSON resume data"
          >
            <FileDown className="w-3.5 h-3.5 text-indigo-400" />
            <span>.JSON</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition-all"
            title="Print or Save to PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Actual Resume Sheet (Paper-like view) */}
      <div
        ref={printRef}
        id="resume-printable-area"
        className="w-full bg-white text-slate-900 rounded-xl shadow-2xl p-8 sm:p-12 font-sans border border-slate-200 transition-all text-[13px] leading-relaxed max-w-4xl mx-auto min-h-[1050px]"
      >
        {/* Header */}
        <div className={`border-b pb-4 mb-5 text-center ${template === 'modern' ? 'border-slate-800' : 'border-slate-300'}`}>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 uppercase">
            {personalInfo.fullName || 'YOUR FULL NAME'}
          </h1>
          
          <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 mt-2 text-xs text-slate-600 font-medium">
            {personalInfo.email && <span>{personalInfo.email}</span>}
            {personalInfo.phone && <span>• {personalInfo.phone}</span>}
            {personalInfo.location && <span>• {personalInfo.location}</span>}
            {personalInfo.linkedin && (
              <span>• <a href={`https://${personalInfo.linkedin.replace(/^https?:\/\//, '')}`} target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline">{personalInfo.linkedin}</a></span>
            )}
            {personalInfo.github && (
              <span>• <a href={`https://${personalInfo.github.replace(/^https?:\/\//, '')}`} target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline">{personalInfo.github}</a></span>
            )}
          </div>
        </div>

        {/* Summary */}
        {summary && (
          <div className="mb-5">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
              Professional Summary
            </h2>
            <p className="text-slate-700 text-xs leading-relaxed text-justify">{summary}</p>
          </div>
        )}

        {/* Education */}
        {education.length > 0 && (
          <div className="mb-5">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
              Education
            </h2>
            <div className="space-y-3">
              {education.map((edu, idx) => (
                <div key={idx}>
                  <div className="flex items-baseline justify-between">
                    <span className="font-bold text-slate-900">{edu.institution || 'University Name'}</span>
                    <span className="text-xs text-slate-600 font-semibold">{edu.graduationYear ? `Expected ${edu.graduationYear}` : ''}</span>
                  </div>
                  <div className="flex items-baseline justify-between text-xs text-slate-700">
                    <span className="italic">{edu.degree}</span>
                    {edu.gpa && <span className="font-medium text-slate-800">GPA: {edu.gpa}</span>}
                  </div>
                  {edu.coursework && (
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      <span className="font-semibold text-slate-700">Relevant Coursework:</span> {edu.coursework}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Technical Skills */}
        {(skills.languages || skills.frameworks || skills.developerTools || skills.coreConcepts) && (
          <div className="mb-5">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
              Technical Skills
            </h2>
            <div className="space-y-1 text-xs text-slate-700">
              {skills.languages && (
                <p>
                  <strong className="text-slate-900">Languages:</strong> {skills.languages}
                </p>
              )}
              {skills.frameworks && (
                <p>
                  <strong className="text-slate-900">Frameworks & Libraries:</strong> {skills.frameworks}
                </p>
              )}
              {skills.developerTools && (
                <p>
                  <strong className="text-slate-900">Developer Tools & Cloud:</strong> {skills.developerTools}
                </p>
              )}
              {skills.coreConcepts && (
                <p>
                  <strong className="text-slate-900">Core Concepts:</strong> {skills.coreConcepts}
                </p>
              )}
            </div>
          </div>
        )}

        {/* Experience */}
        {experience.length > 0 && (
          <div className="mb-5">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
              Experience & Internships
            </h2>
            <div className="space-y-3.5">
              {experience.map((exp, idx) => (
                <div key={idx}>
                  <div className="flex items-baseline justify-between">
                    <div>
                      <span className="font-bold text-slate-900">{exp.role || 'Role'}</span>
                      <span className="text-slate-600 font-medium"> — {exp.company || 'Company'}</span>
                    </div>
                    <span className="text-xs text-slate-600 font-medium">{exp.period}</span>
                  </div>
                  {exp.location && <p className="text-[11px] text-slate-500 italic mb-1">{exp.location}</p>}

                  {exp.bullets && exp.bullets.length > 0 && (
                    <ul className="list-disc list-outside pl-4 space-y-1 mt-1 text-xs text-slate-700">
                      {exp.bullets.filter(b => b.trim()).map((bullet, bIdx) => (
                        <li key={bIdx} className="leading-snug">
                          {bullet}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects */}
        {projects.length > 0 && (
          <div className="mb-5">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
              Projects
            </h2>
            <div className="space-y-3">
              {projects.map((proj, idx) => (
                <div key={idx}>
                  <div className="flex items-baseline justify-between">
                    <div>
                      <span className="font-bold text-slate-900">{proj.title}</span>
                      {proj.technologies && (
                        <span className="text-slate-600 text-xs font-mono ml-2">| {proj.technologies}</span>
                      )}
                    </div>
                    {proj.link && (
                      <a
                        href={proj.link}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-indigo-600 hover:underline"
                      >
                        Source / Demo
                      </a>
                    )}
                  </div>
                  {proj.description && (
                    <p className="text-xs text-slate-700 mt-1 leading-snug">{proj.description}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Certifications */}
        {certifications.length > 0 && (
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
              Certifications & Leadership
            </h2>
            <ul className="list-disc list-outside pl-4 space-y-0.5 text-xs text-slate-700">
              {certifications.map((cert, idx) => (
                <li key={idx}>{cert}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
