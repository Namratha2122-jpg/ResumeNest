import React from 'react';
import { Link } from 'react-router-dom';
import {
  ShieldCheck,
  Cpu,
  BarChart3,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  Lock,
  Layers,
  Sparkles,
} from 'lucide-react';

export default function Features() {
  const features = [
    {
      title: 'Authoritative College Domain Gatekeeper',
      category: 'Security & Access',
      description:
        'Access to student resources is strictly protected by backend validation. Only email domains verified in the approvedCollegeDomains Firestore collection are granted student privileges. Unapproved personal webmail (Gmail, Yahoo, etc.) receives a 403 Forbidden rejection.',
      icon: ShieldCheck,
    },
    {
      title: 'Separate Administrator Control Center',
      category: 'Architecture',
      description:
        'Administrators undergo a distinct authentication flow validated against the admins collection with granular permissions (view_students, manage_courses, view_analytics, manage_settings). Students can never escalate to admin.',
      icon: Lock,
    },
    {
      title: 'Server-Side Gemini 3.8 Flash Diagnostic',
      category: 'Artificial Intelligence',
      description:
        'All AI requests are executed entirely by Node.js backend routes using Google GenAI SDK. Browser bundles never touch Gemini API keys or internal scoring instructions.',
      icon: Cpu,
    },
    {
      title: 'Strict 10-Factor ATS Engine',
      category: 'Recruiting Standard',
      description:
        'The frontend never generates fake scores. Scores are calculated by a backend formula weighing Technical Skills (15%), Work Experience (15%), Projects (15%), Summary (10%), Education (10%), Keywords (10%), Role Relevance (10%), Certifications (5%), Formatting (5%), and Contact Info (5%).',
      icon: BarChart3,
    },
    {
      title: '100% Free Verified Course Bridge',
      category: 'Skill Enhancement',
      description:
        'AI identifies candidate skill gaps, but course URLs originate strictly from our verified catalog. Active courses from Harvard, MIT OCW, Stanford, and freeCodeCamp help students bridge gaps without paying for tuition.',
      icon: BookOpen,
    },
    {
      title: 'Real-Time Section Rephrase & Polish',
      category: 'AI Assistant',
      description:
        'Use Google X-Y-Z formula ("Accomplished [X] as measured by [Y] by doing [Z]") to transform passive bullet points into impactful achievement statements with one click.',
      icon: Sparkles,
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <span className="text-xs font-semibold px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
          Core Capabilities
        </span>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          Enterprise ATS Screening for Students
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          Designed from the ground up with strict separation of duties, authoritative server-side validation, and genuine university course integrations.
        </p>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((f, i) => {
          const Icon = f.icon;
          return (
            <div
              key={i}
              className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-semibold text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                    {f.category}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white leading-snug">{f.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{f.description}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom CTA */}
      <div className="text-center pt-6">
        <Link
          to="/login"
          className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all active:scale-95"
        >
          <span>Start Building Your Resume</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
