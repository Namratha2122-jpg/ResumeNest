import React, { useEffect, useState } from 'react';
import { useAuth } from '../../hooks/useAuth.jsx';
import api from '../../services/api.js';
import LoadingState from '../../components/LoadingState.jsx';
import { Shield, Lock, CheckCircle2, Key, User } from 'lucide-react';

export default function AdminProfile() {
  const { user } = useAuth();
  const [adminDetails, setAdminDetails] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadAdminInfo() {
      try {
        const res = await api.get('/admin/profile');
        setAdminDetails(res.admin);
      } catch (err) {
        console.error('Failed to load admin profile:', err);
      } finally {
        setLoading(false);
      }
    }
    loadAdminInfo();
  }, []);

  if (loading) {
    return <LoadingState message="Loading administrator profile..." />;
  }

  const permissions = adminDetails?.permissions || user?.permissions || [
    'manage_courses',
    'view_students',
    'view_analytics',
    'manage_settings',
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h1 className="text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
          <Shield className="w-6 h-6 text-amber-400" />
          <span>Administrator Profile</span>
        </h1>
        <p className="text-xs text-slate-400">
          Backend verified administrative credentials and assigned authorization permissions.
        </p>
      </div>

      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex items-center space-x-4 pb-6 border-b border-slate-800">
          <div className="w-14 h-14 rounded-2xl bg-amber-400/10 text-amber-400 border border-amber-400/20 flex items-center justify-center font-bold text-xl">
            {user?.email?.slice(0, 2).toUpperCase() || 'AD'}
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">{adminDetails?.name || 'System Administrator'}</h2>
            <p className="text-xs text-slate-400 font-mono">{user?.email}</p>
            <div className="mt-1 flex items-center space-x-2 text-[10px] font-mono text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Status: Active Administrator in admins collection</span>
            </div>
          </div>
        </div>

        {/* Permissions list */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
            <Key className="w-4 h-4 text-indigo-400" />
            <span>Assigned Administrative Permissions</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { id: 'manage_courses', label: 'Course Catalog Management', desc: 'Create, edit, activate and delete courses' },
              { id: 'view_students', label: 'Student Directory Access', desc: 'Inspect registered student records and profiles' },
              { id: 'view_analytics', label: 'Database Analytics', desc: 'View calculated ATS score distributions and metrics' },
              { id: 'manage_settings', label: 'Domain Gatekeeper Management', desc: 'Authorize and configure approved university domains' },
            ].map((p) => {
              const hasPerm = permissions.includes(p.id);
              return (
                <div
                  key={p.id}
                  className={`p-3.5 rounded-xl border transition-all ${
                    hasPerm
                      ? 'bg-slate-950 border-emerald-500/20 text-slate-200'
                      : 'bg-slate-950/40 border-slate-800 text-slate-500'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    <CheckCircle2
                      className={`w-4 h-4 ${hasPerm ? 'text-emerald-400' : 'text-slate-600'}`}
                    />
                    <span className="text-xs font-bold">{p.label}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">{p.desc}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Security Notice */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-1">
          <div className="flex items-center space-x-1.5 text-slate-300 font-semibold">
            <Lock className="w-3.5 h-3.5 text-indigo-400" />
            <span>Server-Enforced Authorization</span>
          </div>
          <p className="text-[11px] text-slate-500 leading-relaxed">
            All administrative actions are gated by server-side middleware (<code>authorizeAdmin.js</code>). Client-side manipulation of roles or URLs is strictly rejected with HTTP 403 Forbidden.
          </p>
        </div>
      </div>
    </div>
  );
}
