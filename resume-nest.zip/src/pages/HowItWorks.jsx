import React from 'react';
import { Link } from 'react-router-dom';
import {
  GraduationCap,
  ShieldCheck,
  Cpu,
  BarChart3,
  BookOpen,
  ArrowRight,
  Lock,
  Layers,
  CheckCircle2,
} from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      step: '01',
      title: 'Sign in with Your College Google Account',
      description:
        'Access is gated by our server-side College Domain Gatekeeper. Your university email domain is checked against active accredited institutions in the approvedCollegeDomains registry.',
      icon: GraduationCap,
      badge: 'Authoritative Domain Check',
    },
    {
      step: '02',
      title: 'Build or Paste Your Academic Resume',
      description:
        'Use our single-column ATS-compliant builder formatted specifically for high-volume recruitment algorithms. Every document is securely stored under your verified student UID.',
      icon: Layers,
      badge: 'Zero Parser Traps',
    },
    {
      step: '03',
      title: 'Server-Side Gemini 3.8 Flash Diagnostic',
      description:
        'The backend invokes Gemini with structured JSON schemas to audit your resume across 10 recruiting dimensions. The model identifies strengths, missing keywords, and critical flaws without exposing API keys to the browser.',
      icon: Cpu,
      badge: 'Protected Server AI',
    },
    {
      step: '04',
      title: 'Strict 10-Factor ATS Score Calculation',
      description:
        'The backend computes your final readiness score using immutable mathematical weights: Skills (15%), Experience (15%), Projects (15%), Summary (10%), Education (10%), Keywords (10%), Role Relevance (10%), Certifications (5%), Formatting (5%), and Contact (5%).',
      icon: BarChart3,
      badge: 'Weighted Engine',
    },
    {
      step: '05',
      title: 'Bridge Skill Gaps with 100% Free Courses',
      description:
        'Gemini discovers your missing technical capabilities, and our backend matches them to genuine, verified free courses from Harvard, MIT, Stanford, and freeCodeCamp. Zero paywalls.',
      icon: BookOpen,
      badge: 'Verified Catalog',
    },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Header */}
      <div className="text-center space-y-3 max-w-3xl mx-auto">
        <span className="text-xs font-semibold px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
          Architecture & Verification Flow
        </span>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          How Resume Nest Works
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          From institutional authentication to server-side AI evaluation and verified course bridging — here is our complete client-server workflow.
        </p>
      </div>

      {/* Step by Step Timeline */}
      <div className="space-y-6">
        {steps.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6"
            >
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 rounded-xl bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center flex-shrink-0 font-mono font-bold text-lg">
                  {item.step}
                </div>
                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base font-bold text-white">{item.title}</h3>
                    <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      {item.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
                    {item.description}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* CTA Box */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-slate-900 to-indigo-950/60 border border-slate-800 text-center space-y-4">
        <h3 className="text-xl font-bold text-white">Ready to test your campus resume?</h3>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          Sign in with your campus Google account or test one of our verified institutional demo accounts.
        </p>
        <div className="pt-2">
          <Link
            to="/login"
            className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all active:scale-95"
          >
            <span>Student Sign In</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
