import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';
import {
  Shield,
  ShieldAlert,
  ArrowRight,
  Code2,
  Crown,
  CheckCircle2,
  Loader2,
} from 'lucide-react';

export default function AdminLogin() {
  const [errorMsg, setErrorMsg] = useState('');
  const [loadingAdmin, setLoadingAdmin] = useState(null); // 'dinesh' | 'namratha' | 'test' | null
  const { loginAdmin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogin = async (targetEmail, targetName, adminKey) => {
    setErrorMsg('');
    setLoadingAdmin(adminKey);

    try {
      const result = await loginAdmin(targetEmail, targetName);

      if (result.success) {
        const from = location.state?.from?.pathname || '/admin/dashboard';
        navigate(from, { replace: true });
      } else {
        setErrorMsg(result.error || 'Access denied: You do not have administrator permissions.');
      }
    } catch (err) {
      setErrorMsg(err.message || 'An error occurred during administrator authentication.');
    } finally {
      setLoadingAdmin(null);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-12">
      <div className="card-3d rounded-3xl bg-slate-900 border-2 border-amber-500/30 p-6 sm:p-8 space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-amber-500/10">
            <Shield className="w-7 h-7" />
          </div>
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400 bg-amber-400/15 px-3 py-1 rounded-full border border-amber-400/30">
            Resume Nest Admin
          </span>
          <h2 className="text-2xl font-black text-white tracking-tight">Administrator Gateway</h2>
          <p className="text-xs text-slate-400">
            Strict Two-Admin Access Control Policy
          </p>
        </div>

        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start space-x-2.5 text-xs text-rose-300">
            <ShieldAlert className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Access Denied</p>
              <p className="text-[11px] text-rose-300/90">{errorMsg}</p>
            </div>
          </div>
        )}

        {/* Dedicated Authorized Administrator Accounts */}
        <div className="space-y-3.5">
          <div className="flex items-center justify-between pb-1 border-b border-slate-800">
            <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
              Authorized Admins (Only 2 Accounts)
            </span>
            <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              Verified
            </span>
          </div>

          {/* Admin 1: Naga Surya Dinesh */}
          <button
            type="button"
            disabled={loadingAdmin !== null}
            onClick={() =>
              handleLogin('nagasuryadinesh@gmail.com', 'Naga Surya Dinesh', 'dinesh')
            }
            className={`w-full p-4 rounded-2xl bg-slate-950 hover:bg-slate-800/90 border-2 transition-all text-left group shadow-lg flex items-center justify-between ${
              loadingAdmin === 'dinesh'
                ? 'border-amber-400 bg-slate-900'
                : 'border-amber-500/40 hover:border-amber-400'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <Crown className="w-4 h-4 text-amber-400" />
                <span className="text-sm font-black text-amber-300">
                  Naga Surya Dinesh
                </span>
              </div>
              <p className="text-xs text-slate-300 font-medium">Deployment Owner & Super Admin</p>
              <p className="text-[11px] text-slate-400 font-mono">nagasuryadinesh@gmail.com</p>
            </div>

            <div className="flex items-center space-x-2 pl-3">
              {loadingAdmin === 'dinesh' ? (
                <Loader2 className="w-5 h-5 text-amber-400 animate-spin" />
              ) : (
                <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors">
                  <ArrowRight className="w-4 h-4" />
                </div>
              )}
            </div>
          </button>

          {/* Admin 2: Namratha Siri */}
          <button
            type="button"
            disabled={loadingAdmin !== null}
            onClick={() =>
              handleLogin('namratha.siri@admin.resumenest', 'Namratha Siri', 'namratha')
            }
            className={`w-full p-4 rounded-2xl bg-slate-950 hover:bg-slate-800/90 border-2 transition-all text-left group shadow-lg flex items-center justify-between ${
              loadingAdmin === 'namratha'
                ? 'border-cyan-400 bg-slate-900'
                : 'border-cyan-500/40 hover:border-cyan-400'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <Code2 className="w-4 h-4 text-cyan-400" />
                <span className="text-sm font-black text-cyan-300">
                  Namratha Siri
                </span>
                <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold">
                  Admin & Developer
                </span>
              </div>
              <p className="text-xs text-slate-300 font-medium">Administrator & Developer</p>
              <p className="text-[11px] text-slate-400 font-mono flex items-center space-x-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400 inline" />
                <span>Direct Access (Zero email required)</span>
              </p>
            </div>

            <div className="flex items-center space-x-2 pl-3">
              {loadingAdmin === 'namratha' ? (
                <Loader2 className="w-5 h-5 text-cyan-400 animate-spin" />
              ) : (
                <div className="w-8 h-8 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 flex items-center justify-center group-hover:bg-cyan-400 group-hover:text-slate-950 transition-colors">
                  <ArrowRight className="w-4 h-4" />
                </div>
              )}
            </div>
          </button>
        </div>

        {/* Security Policy Information */}
        <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-400 space-y-1.5 leading-relaxed">
          <div className="flex items-center space-x-1.5 text-slate-300 font-semibold">
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            <span>Strict Access Policy</span>
          </div>
          <p>
            Only <strong>Naga Surya Dinesh</strong> and <strong>Namratha Siri</strong> are provisioned with administrative privileges in the system.
          </p>
        </div>

        {/* Test Unauthorized Access Button */}
        <div className="pt-2 border-t border-slate-800">
          <button
            type="button"
            disabled={loadingAdmin !== null}
            onClick={() =>
              handleLogin('unauthorized.guest@example.com', 'Guest User', 'test')
            }
            className="w-full py-2.5 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-dashed border-rose-500/30 text-rose-300 text-xs font-medium transition-colors flex items-center justify-center space-x-1.5"
          >
            {loadingAdmin === 'test' ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <ShieldAlert className="w-3.5 h-3.5" />
            )}
            <span>Test Unauthorized Account (Expected: 403 Forbidden)</span>
          </button>
        </div>

        <div className="text-center pt-1">
          <Link to="/login" className="text-xs text-slate-400 hover:text-white transition-colors">
            Student looking for resume builder? <span className="text-indigo-400 font-semibold">Student Login →</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
