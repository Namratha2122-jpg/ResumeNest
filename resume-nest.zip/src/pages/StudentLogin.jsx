import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';
import {
  GraduationCap,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Lock,
} from 'lucide-react';

import Mascot3DBird from '../components/Mascot3DBird.jsx';

const DEMO_CAMPUS_ACCOUNTS = [
  { name: 'Alex Chen', email: 'alex.chen@stanford.edu', college: 'Stanford University' },
  { name: 'Maya Patel', email: 'mayap@mit.edu', college: 'MIT' },
  { name: 'Jordan Lee', email: 'jordan@berkeley.edu', college: 'UC Berkeley' },
  { name: 'Sarah Miller', email: 'smiller@harvard.edu', college: 'Harvard University' },
  { name: 'Rohan Sharma', email: 'rohan@iitb.ac.in', college: 'IIT Bombay' },
];

export default function StudentLogin() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);
  const { loginStudent } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogin = async (targetEmail, targetName) => {
    setErrorMsg('');
    setLoading(true);

    const emailToUse = targetEmail || email;
    const nameToUse = targetName || name;

    if (!emailToUse || !emailToUse.includes('@')) {
      setErrorMsg('Please provide a valid college email address.');
      setLoading(false);
      return;
    }

    try {
      const result = await loginStudent(emailToUse, nameToUse);

      if (result.success) {
        const from = location.state?.from?.pathname || '/dashboard';
        navigate(from, { replace: true });
      } else if (result.status === 403) {
        // Backend authoritatively rejected unapproved domain
        navigate('/access-denied', {
          state: {
            reason: result.error || 'Resume Nest is currently available only to students using an approved college email address.',
            domain: result.domain,
          },
        });
      } else {
        setErrorMsg(result.error || 'Failed to sign in. Please verify your details.');
      }
    } catch (err) {
      setErrorMsg(err.message || 'An error occurred during authentication.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-8">
      <div className="card-3d rounded-3xl bg-slate-900 border-2 border-indigo-500/30 p-6 sm:p-8 space-y-6">
        {/* Mascot & Header */}
        <div className="text-center space-y-2">
          <div className="flex justify-center -mt-2 mb-2">
            <Mascot3DBird className="w-28 h-28" message="Got your campus email ready? 🎓" />
          </div>
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-indigo-400 bg-indigo-500/15 px-3 py-1 rounded-full border border-indigo-500/30">
            Campus Career Portal
          </span>
          <h2 className="text-2xl font-black text-white tracking-tight">Student Login</h2>
          <p className="text-xs text-slate-400">
            Sign in with your approved university email (.edu, .ac.in, etc.)
          </p>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center space-x-2.5 text-xs text-rose-300">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleLogin();
          }}
          className="space-y-4"
        >
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">
              Full Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Alex Chen"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">
              Campus Email Address (.edu, .ac.in, etc.)
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. student@stanford.edu"
              required
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Backend verifies domain against approved college registry.
            </p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-3d-indigo w-full py-3.5 rounded-xl bg-indigo-600 text-white font-extrabold text-sm disabled:opacity-50 flex items-center justify-center space-x-2"
          >
            <span>{loading ? 'Verifying College Domain...' : 'Continue with College Google Account'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="relative flex py-2 items-center">
          <div className="flex-grow border-t border-slate-800"></div>
          <span className="flex-shrink mx-3 text-[11px] text-slate-500 uppercase tracking-wider font-semibold">
            Or Test With Verified Campus Account
          </span>
          <div className="flex-grow border-t border-slate-800"></div>
        </div>

        {/* Quick Demo Campus Account Switcher */}
        <div className="space-y-2">
          <div className="grid grid-cols-1 gap-2">
            {DEMO_CAMPUS_ACCOUNTS.map((acc, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  setEmail(acc.email);
                  setName(acc.name);
                  handleLogin(acc.email, acc.name);
                }}
                className="w-full p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800/80 hover:border-indigo-500/40 text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <p className="text-xs font-semibold text-white group-hover:text-indigo-300">
                    {acc.name}
                  </p>
                  <p className="text-[11px] text-emerald-400 font-mono">{acc.email}</p>
                </div>
                <span className="text-[10px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                  {acc.college}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Test 403 Forbidden Flow Button */}
        <div className="pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={() => {
              setEmail('user@gmail.com');
              setName('Personal Account');
              handleLogin('user@gmail.com', 'Personal Account');
            }}
            className="w-full py-2 px-3 rounded-lg bg-slate-950 hover:bg-slate-800 border border-dashed border-rose-500/30 text-rose-300 text-xs font-medium transition-colors flex items-center justify-center space-x-1.5"
          >
            <span>Test Unapproved Email Rejection (e.g. user@gmail.com)</span>
          </button>
        </div>

        <div className="text-center pt-2">
          <Link to="/admin/login" className="text-xs text-slate-400 hover:text-white transition-colors">
            Are you an administrator? <span className="text-indigo-400 font-semibold">Admin Login →</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
