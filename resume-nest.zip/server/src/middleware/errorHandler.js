/**
 * Centralized Error Handler Middleware
 */
export function errorHandler(err, req, res, next) {
  console.error('[ServerError]', err);

  // If response is already committed, delegate to default express error handler
  if (res.headersSent) {
    return next(err);
  }

  // Handle specific known error messages or statuses
  if (err.status === 400 || err.name === 'ValidationError') {
    return res.status(400).json({
      error: err.message || 'Please provide valid resume information.',
      details: err.details || null,
    });
  }

  if (err.status === 401) {
    return res.status(401).json({
      error: 'Please sign in to continue.',
    });
  }

  if (err.status === 403) {
    return res.status(403).json({
      error: err.message || 'You do not have permission to access this resume.',
    });
  }

  if (err.status === 503 || err.message?.includes('GEMINI_UNAVAILABLE') || err.message?.includes('AI model')) {
    return res.status(503).json({
      error: 'AI analysis is temporarily unavailable. Please try again.',
      details: err.message,
    });
  }

  return res.status(500).json({
    error: 'An unexpected error occurred. Please try again.',
    message: err.message,
  });
}
