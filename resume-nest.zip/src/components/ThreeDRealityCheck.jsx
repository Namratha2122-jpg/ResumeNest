import React from 'react';
import { Skull, PartyPopper, Check, X, Sparkles, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function ThreeDRealityCheck() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
        <span className="text-xs font-mono font-bold uppercase tracking-widest text-amber-400 bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20">
          The Brutal Truth of Campus Recruiting
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
          Why 70% of College Resumes Disappear into the ATS Black Hole
        </h2>
        <p className="text-xs sm:text-sm text-slate-400">
          Recruitment bots spend 6.2 seconds screening your document. Here is the difference between an instant rejection and a round-one phone call.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
        {/* Card 1: The Doomed Resume */}
        <div className="card-3d rounded-3xl bg-slate-900/90 border-2 border-rose-500/30 p-6 sm:p-8 flex flex-col justify-between space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 transform translate-x-4 -translate-y-4 w-32 h-32 bg-rose-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center font-bold text-lg">
                  💀
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">The Typical College Resume</h3>
                  <p className="text-[11px] text-rose-400 font-mono">Status: Ghosted within 48 hours</p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-slate-500 line-through">Score: 28</span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-400">Objective Statement:</span>
                <p className="text-slate-300 italic">"Hardworking student looking for an entry-level position where I can learn, grow, and gain experience."</p>
                <p className="text-[10px] text-rose-400">❌ Bot reaction: Every student on earth wrote this exact sentence.</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-400">Skills Section:</span>
                <p className="text-slate-300 italic">"Microsoft Word, PowerPoint, Googling, Asking ChatGPT, Python (Basic)"</p>
                <p className="text-[10px] text-rose-400">❌ Bot reaction: "Basic Python" gets ranked at the 8th percentile.</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-400">Project Bullets:</span>
                <p className="text-slate-300 italic">"• Worked on an online store project with friends and fixed some CSS bugs."</p>
                <p className="text-[10px] text-rose-400">❌ Bot reaction: Zero metrics, zero architecture keywords.</p>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-300 flex items-center space-x-2">
            <span className="text-lg">📉</span>
            <span>Probability of recruiter callback: <strong>~3%</strong></span>
          </div>
        </div>

        {/* Card 2: The Resume Nest Engineered Document */}
        <div className="card-3d rounded-3xl bg-gradient-to-b from-indigo-950/60 via-slate-900 to-slate-900 border-2 border-emerald-500/40 p-6 sm:p-8 flex flex-col justify-between space-y-6 relative overflow-hidden shadow-[0_20px_50px_rgba(16,185,129,0.15)]">
          <div className="absolute top-0 right-0 transform translate-x-4 -translate-y-4 w-32 h-32 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />

          <div className="space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-lg shadow-inner">
                  🎉
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">The Resume Nest Document</h3>
                  <p className="text-[11px] text-emerald-400 font-mono">Status: Recruiter Calendly Link Sent</p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">
                Score: 94
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/30 space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-400">10-Factor Technical Summary:</span>
                <p className="text-slate-200">"Computer Science undergraduate specialized in distributed microservices, TypeScript, and Go. Demonstrated history of optimizing database latency by 32% under load."</p>
                <p className="text-[10px] text-emerald-400 font-semibold">✓ Bot reaction: High keyword density match for Software Engineer (96%).</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/30 space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-400">Categorized Skills & Certifications:</span>
                <p className="text-slate-200">"Languages: Python, Go, TypeScript · Frameworks: React, Node.js · Tools: Docker, PostgreSQL, Git, CI/CD"</p>
                <p className="text-[10px] text-emerald-400 font-semibold">✓ Bot reaction: Zero parser ambiguity; clear tech stack.</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/30 space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-400">Google X-Y-Z Project Bullets:</span>
                <p className="text-slate-200">"• Architected distributed key-value store using Raft consensus in Go, handling 10,000+ ops/sec with zero state divergence across simulated partitions."</p>
                <p className="text-[10px] text-emerald-400 font-semibold">✓ Bot reaction: Concrete metrics + architectural complexity proven.</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="text-xs text-emerald-400 font-semibold flex items-center space-x-1.5">
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Callback rate: <strong>5.4× Industry Average</strong></span>
            </div>

            <Link
              to="/login"
              className="btn-3d-indigo inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold"
            >
              <span>Upgrade My Resume</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
