import api from './api.js';
import { createStudentToken } from './firebaseClient.js';

const TOKEN_KEY = 'resume_nest_token';
const USER_KEY = 'resume_nest_user';

export const authService = {
  /**
   * Student Login:
   * Generates token and calls backend /api/auth/verify-student.
   * Backend authoritatively verifies token & approved college domain.
   */
  async loginStudent(email, name = '') {
    const token = createStudentToken({ email, name });
    localStorage.setItem(TOKEN_KEY, token);

    try {
      const response = await api.post('/auth/verify-student', {});
      if (response?.user && response.userType === 'student') {
        localStorage.setItem(USER_KEY, JSON.stringify(response.user));
        return { success: true, user: response.user, userType: 'student' };
      }
      throw new Error('Student verification failed');
    } catch (error) {
      if (error.status === 403) {
        const rejected = {
          email,
          domain: email.split('@')[1] || '',
          userType: null,
          isAuthorized: false,
          error: error.message,
        };
        localStorage.setItem(USER_KEY, JSON.stringify(rejected));
        return {
          success: false,
          status: 403,
          error: error.message,
          domain: rejected.domain,
        };
      }
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
      throw error;
    }
  },

  /**
   * Admin Login:
   * Separate authentication flow. Calls backend /api/auth/verify-admin.
   * Backend authoritatively verifies that UID is an active admin in admins collection.
   */
  async loginAdmin(email, name = '') {
    const token = createStudentToken({ email, name });
    localStorage.setItem(TOKEN_KEY, token);

    try {
      const response = await api.post('/auth/verify-admin', {});
      if (response?.user && response.userType === 'admin') {
        localStorage.setItem(USER_KEY, JSON.stringify(response.user));
        return { success: true, user: response.user, userType: 'admin' };
      }
      throw new Error('Administrator authorization failed');
    } catch (error) {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
      if (error.status === 403) {
        return {
          success: false,
          status: 403,
          error: 'You do not have administrator access.',
        };
      }
      throw error;
    }
  },

  /**
   * Universal session verification on initial load or browser refresh.
   * Calls /api/auth/session to authoritatively determine userType.
   */
  async verifySession() {
    const token = localStorage.getItem(TOKEN_KEY);
    if (!token) return null;

    try {
      const response = await api.get('/auth/session');
      if (response?.user && response.userType) {
        localStorage.setItem(USER_KEY, JSON.stringify(response.user));
        return {
          user: response.user,
          userType: response.userType,
        };
      }
      return null;
    } catch (error) {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
      return null;
    }
  },

  /**
   * Logout
   */
  logout() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },

  getCurrentUser() {
    const raw = localStorage.getItem(USER_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  },

  async getInstitutions() {
    try {
      const res = await api.get('/auth/institutions');
      return res.institutions || [];
    } catch {
      return [];
    }
  },
};

export default authService;
