import React from 'react';
import { FilePlus2, BookOpen, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function EmptyState({
  title = 'No resumes yet',
  description = 'Build your first ATS-optimized student resume to get an instant readiness diagnosis and personalized free course recommendations.',
  actionText = 'Create Resume',
  actionLink = '/builder',
  icon: Icon = FilePlus2,
  onAction = null,
}) {
  return (
    <div className="flex flex-col items-center justify-center p-12 text-center bg-slate-900/40 rounded-2xl border border-dashed border-slate-800 max-w-md mx-auto">
      <div className="w-16 h-16 rounded-2xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mb-4">
        <Icon className="w-8 h-8" />
      </div>

      <h3 className="text-base font-bold text-white mb-2">{title}</h3>
      <p className="text-xs text-slate-400 mb-6 leading-relaxed">{description}</p>

      {onAction ? (
        <button
          onClick={onAction}
          className="flex items-center space-x-2 px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition-all"
        >
          <Sparkles className="w-4 h-4" />
          <span>{actionText}</span>
        </button>
      ) : (
        <Link
          to={actionLink}
          className="flex items-center space-x-2 px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition-all"
        >
          <Sparkles className="w-4 h-4" />
          <span>{actionText}</span>
        </Link>
      )}
    </div>
  );
}
