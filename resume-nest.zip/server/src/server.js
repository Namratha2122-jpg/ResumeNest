import express from 'express';
import compression from 'compression';
import authRoutes from './routes/auth.routes.js';
import studentRoutes from './routes/student.routes.js';
import adminRoutes from './routes/admin.routes.js';
import courseRoutes from './routes/course.routes.js';
import templateRoutes from './routes/template.routes.js';
import realtimeRoutes from './routes/realtime.routes.js';
import { errorHandler } from './middleware/errorHandler.js';

export function createApiApp() {
  const app = express();

  // High-Throughput HTTP Compression (skips SSE streams)
  app.use(
    compression({
      level: 6,
      threshold: 1024,
      filter: (req, res) => {
        if (req.headers.accept === 'text/event-stream' || req.path.includes('/realtime/stream')) {
          return false;
        }
        return compression.filter(req, res);
      },
    })
  );

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Separate API Route Groups
  app.use('/api/auth', authRoutes);
  app.use('/api/student', studentRoutes);
  app.use('/api/admin', adminRoutes);

  // Public course browsing
  app.use('/api/courses', courseRoutes);

  // Student Community Templates Hub
  app.use('/api/templates', templateRoutes);

  // Real-Time Database SSE Stream & Metrics
  app.use('/api/realtime', realtimeRoutes);

  // Backward compatibility aliases for student endpoints
  app.use('/api/resumes', studentRoutes);
  app.use('/api/profile', studentRoutes);
  app.use('/api/analysis', studentRoutes);

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'Resume Nest Scalable API',
      serverReachCapacity: '10,000 - 50,000+ Concurrent Students',
      realtimeActive: true,
      timestamp: new Date().toISOString(),
    });
  });

  // Centralized Error Handling
  app.use(errorHandler);

  return app;
}
