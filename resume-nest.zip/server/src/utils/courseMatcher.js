/**
 * Curated Course Catalog & Skill Gap Matcher
 * 
 * RULE:
 * Gemini identifies skill gaps.
 * Gemini MUST NOT invent course URLs.
 * Course URLs must strictly originate from courseCatalog.
 * ONLY FREE + ACTIVE courses are returned.
 */

export const COURSE_CATALOG = [
  {
    id: 'cs50-intro-cs',
    title: 'CS50: Introduction to Computer Science',
    provider: 'Harvard University / edX',
    url: 'https://cs50.harvard.edu/x/',
    isFree: true,
    isActive: true,
    level: 'Beginner to Intermediate',
    duration: '10 weeks (6-18 hrs/week)',
    rating: 4.9,
    reviewsCount: 154000,
    skills: ['C', 'Python', 'SQL', 'Algorithms', 'Data Structures', 'Memory Management', 'Computer Science Fundamentals'],
    description: "An introduction to the intellectual enterprises of computer science and the art of programming. Free access to all lectures, problem sets, and auto-grader.",
    category: 'Computer Science',
    badges: ['Top Pick', '100% Free Audit', 'Harvard'],
  },
  {
    id: 'helsinki-fullstack',
    title: 'Full Stack Open (Deep Dive to Modern Web Development)',
    provider: 'University of Helsinki',
    url: 'https://fullstackopen.com/en/',
    isFree: true,
    isActive: true,
    level: 'Intermediate',
    duration: 'Self-paced (60-120 hrs)',
    rating: 4.95,
    reviewsCount: 42000,
    skills: ['React', 'Node.js', 'Express', 'TypeScript', 'GraphQL', 'REST API', 'PostgreSQL', 'Docker', 'CI/CD', 'Jest'],
    description: 'Learn React, Redux, Node.js, MongoDB, GraphQL, and TypeScript in one go. Comprehensive university course completely free with free certificate.',
    category: 'Web Development',
    badges: ['Free Certificate', 'Industry Standard', 'Hands-on'],
  },
  {
    id: 'fcc-responsive-web',
    title: 'Responsive Web Design & Modern CSS',
    provider: 'freeCodeCamp',
    url: 'https://www.freecodecamp.org/learn/2022/responsive-web-design/',
    isFree: true,
    isActive: true,
    level: 'Beginner',
    duration: '300 hours (Self-paced)',
    rating: 4.8,
    reviewsCount: 88000,
    skills: ['HTML5', 'CSS3', 'Flexbox', 'CSS Grid', 'Responsive Design', 'Accessibility', 'Tailwind CSS'],
    description: 'Master HTML and CSS by building 20+ responsive web projects, including landing pages, technical documentation, and forms.',
    category: 'Web Development',
    badges: ['100% Free', 'Interactive Code', 'Certificate'],
  },
  {
    id: 'fcc-js-algorithms',
    title: 'JavaScript Algorithms and Data Structures',
    provider: 'freeCodeCamp',
    url: 'https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures-v8/',
    isFree: true,
    isActive: true,
    level: 'Beginner to Intermediate',
    duration: '300 hours (Self-paced)',
    rating: 4.85,
    reviewsCount: 95000,
    skills: ['JavaScript', 'ES6+', 'Data Structures', 'Algorithms', 'OOP', 'Functional Programming', 'Debugging'],
    description: 'Learn the fundamentals of JavaScript, variables, arrays, objects, functions, loops, and classic algorithmic problem solving.',
    category: 'Software Engineering',
    badges: ['100% Free', 'Interactive Code', 'Certificate'],
  },
  {
    id: 'mit-ocw-python',
    title: 'Introduction to Computer Science and Programming in Python (6.0001)',
    provider: 'MIT OpenCourseWare',
    url: 'https://ocw.mit.edu/courses/6-0001-introduction-to-computer-science-and-programming-in-python-fall-2016/',
    isFree: true,
    isActive: true,
    level: 'Beginner',
    duration: '9 weeks (12 hrs/week)',
    rating: 4.9,
    reviewsCount: 65000,
    skills: ['Python', 'Object-Oriented Programming', 'Testing', 'Algorithmic Complexity', 'Problem Solving', 'Data Analysis'],
    description: 'MIT undergraduate curriculum covering computational problem solving, data structures, and algorithmic efficiency in Python.',
    category: 'Programming',
    badges: ['MIT Official', 'Open CourseWare', 'Free Lectures'],
  },
  {
    id: 'deeplearning-prompt-eng',
    title: 'ChatGPT & LLM Prompt Engineering for Developers',
    provider: 'DeepLearning.AI',
    url: 'https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/',
    isFree: true,
    isActive: true,
    level: 'Beginner to Intermediate',
    duration: '1-2 hours',
    rating: 4.9,
    reviewsCount: 38000,
    skills: ['Prompt Engineering', 'LLMs', 'Generative AI', 'Gemini API', 'API Integration', 'Python'],
    description: 'Created with Andrew Ng and Isa Fulford, teach how to use LLMs via API to build summarizers, inferrers, transformers, and chatbots.',
    category: 'Artificial Intelligence',
    badges: ['Industry Leading', 'Andrew Ng', '100% Free'],
  },
  {
    id: 'kaggle-ml-intro',
    title: 'Intro to Machine Learning & Scikit-Learn',
    provider: 'Kaggle Learn',
    url: 'https://www.kaggle.com/learn/intro-to-machine-learning',
    isFree: true,
    isActive: true,
    level: 'Beginner',
    duration: '3 hours (Hands-on)',
    rating: 4.8,
    reviewsCount: 71000,
    skills: ['Machine Learning', 'Scikit-Learn', 'Model Validation', 'Random Forests', 'Python', 'Data Science'],
    description: 'Hands-on micro-course covering decision trees, random forests, model validation, underfitting/overfitting, and competitive ML pipelines.',
    category: 'Data Science',
    badges: ['100% Free', 'Interactive Jupyter', 'Fast Track'],
  },
  {
    id: 'kaggle-pandas-sql',
    title: 'Data Analysis with Pandas and SQL',
    provider: 'Kaggle Learn',
    url: 'https://www.kaggle.com/learn/pandas',
    isFree: true,
    isActive: true,
    level: 'Beginner',
    duration: '4 hours',
    rating: 4.8,
    reviewsCount: 54000,
    skills: ['Pandas', 'SQL', 'Data Wrangling', 'Data Cleaning', 'Data Visualization', 'Python'],
    description: 'Solve real-world data manipulation tasks using pandas DataFrame slicing, indexing, grouping, sorting, and data reshaping.',
    category: 'Data Science',
    badges: ['Hands-on', 'Free Certificate', 'Kaggle'],
  },
  {
    id: 'coursera-meta-frontend',
    title: 'Meta Front-End Developer Specialization (Audit Mode)',
    provider: 'Meta / Coursera',
    url: 'https://www.coursera.org/professional-certificates/meta-front-end-developer',
    isFree: true,
    isActive: true,
    level: 'Beginner',
    duration: '7 months (6 hrs/week)',
    rating: 4.7,
    reviewsCount: 48000,
    skills: ['React', 'JavaScript', 'HTML/CSS', 'Git', 'GitHub', 'UI/UX Design', 'Unit Testing'],
    description: 'Comprehensive curriculum designed by Meta engineering staff. Free to audit all courses, videos, and reading materials.',
    category: 'Web Development',
    badges: ['Meta Official', 'Free Audit Available', 'Portfolio Ready'],
  },
  {
    id: 'google-cloud-digital-leader',
    title: 'Google Cloud Digital Leader & Cloud Fundamentals',
    provider: 'Google Cloud Skills Boost',
    url: 'https://www.cloudskillsboost.google/course_templates/153',
    isFree: true,
    isActive: true,
    level: 'Beginner',
    duration: 'Self-paced (8-12 hrs)',
    rating: 4.75,
    reviewsCount: 31000,
    skills: ['Google Cloud', 'Cloud Computing', 'Cloud Architecture', 'DevOps', 'Security', 'Scalability'],
    description: 'Learn cloud concepts, Google Cloud products, infrastructure, data management, and security solutions for modern software delivery.',
    category: 'Cloud & DevOps',
    badges: ['Google Official', 'Free Tier', 'Beginner Friendly'],
  },
  {
    id: 'msft-azure-fundamentals',
    title: 'Microsoft Azure Fundamentals (AZ-900 Learning Path)',
    provider: 'Microsoft Learn',
    url: 'https://learn.microsoft.com/en-us/training/paths/microsoft-azure-fundamentals-describe-cloud-concepts/',
    isFree: true,
    isActive: true,
    level: 'Beginner',
    duration: 'Self-paced (10 hrs)',
    rating: 4.8,
    reviewsCount: 62000,
    skills: ['Cloud Computing', 'Azure', 'Microservices', 'Storage', 'Networking', 'Cloud Security'],
    description: 'Official interactive training path from Microsoft explaining cloud models, virtualization, disaster recovery, and Azure architecture.',
    category: 'Cloud & DevOps',
    badges: ['Microsoft Official', '100% Free', 'Interactive Sandbox'],
  },
  {
    id: 'linux-foundation-intro',
    title: 'Introduction to Linux (LFS101x)',
    provider: 'Linux Foundation / edX',
    url: 'https://www.edx.org/learn/linux/the-linux-foundation-introduction-to-linux',
    isFree: true,
    isActive: true,
    level: 'Beginner',
    duration: '14 weeks (5-7 hrs/week)',
    rating: 4.7,
    reviewsCount: 82000,
    skills: ['Linux', 'Bash', 'Command Line', 'Shell Scripting', 'System Administration', 'Git'],
    description: 'Learn Linux command line navigation, user permissions, shell environments, bash scripts, and server operations directly from the Linux Foundation.',
    category: 'Systems & DevOps',
    badges: ['Official Linux', 'Free Audit', 'Crucial Skill'],
  },
  {
    id: 'fcc-relational-database',
    title: 'Relational Database & SQL Certification',
    provider: 'freeCodeCamp',
    url: 'https://www.freecodecamp.org/learn/relational-database/',
    isFree: true,
    isActive: true,
    level: 'Intermediate',
    duration: '300 hours (Self-paced)',
    rating: 4.9,
    reviewsCount: 29000,
    skills: ['PostgreSQL', 'SQL', 'Bash', 'Git', 'Database Design', 'Schema Architecture', 'Data Normalization'],
    description: 'Work inside real Linux virtual machines and PostgreSQL terminals to build relational database schemas, migrations, and complex queries.',
    category: 'Database & Backend',
    badges: ['100% Free', 'Linux VM Environment', 'Verified Certificate'],
  },
  {
    id: 'stanford-algorithms',
    title: 'Algorithms: Design and Analysis',
    provider: 'Stanford Online / edX',
    url: 'https://online.stanford.edu/courses/soe-ycsalgorithms1-algorithms-design-and-analysis-part-1',
    isFree: true,
    isActive: true,
    level: 'Intermediate',
    duration: '6 weeks (4-8 hrs/week)',
    rating: 4.85,
    reviewsCount: 51000,
    skills: ['Algorithms', 'Divide and Conquer', 'Graph Search', 'Dijkstra', 'Sorting', 'Big-O Analysis', 'Technical Interviews'],
    description: 'Taught by Prof. Tim Roughgarden. Learn asymptotic analysis, master method, divide and conquer, heaps, and graph search for technical interviews.',
    category: 'Computer Science',
    badges: ['Stanford', 'Free Audit', 'Interview Prep'],
  },
  {
    id: 'deeplearning-ai-ml-spec',
    title: 'Machine Learning Specialization',
    provider: 'DeepLearning.AI & Stanford / Coursera',
    url: 'https://www.coursera.org/specializations/machine-learning-introduction',
    isFree: true,
    isActive: true,
    level: 'Beginner to Intermediate',
    duration: '3 months (9 hrs/week)',
    rating: 4.9,
    reviewsCount: 140000,
    skills: ['Machine Learning', 'Deep Learning', 'Neural Networks', 'Linear Regression', 'Logistic Regression', 'Gradient Descent', 'Python', 'NumPy'],
    description: 'Foundational AI course taught by pioneer Andrew Ng. Audit for free to master supervised learning, neural networks, and recommender systems.',
    category: 'Artificial Intelligence',
    badges: ['World Renowned', 'Andrew Ng', 'Free Audit Available'],
  }
];

/**
 * Matches missing skills against the verified courseCatalog.
 * ONLY returns FREE + ACTIVE courses.
 * @param {string[]} missingSkills - Array of skill gaps identified by Gemini
 * @returns {Array} Array of recommended course objects
 */
export function matchCoursesToSkillGaps(missingSkills = []) {
  if (!Array.isArray(missingSkills) || missingSkills.length === 0) {
    // Return top popular foundational free courses if no specific gaps
    return COURSE_CATALOG.filter(c => c.isFree && c.isActive).slice(0, 4);
  }

  const normalizedGaps = missingSkills.map(s => String(s).toLowerCase().trim());

  // Score each active free course by match count
  const scored = COURSE_CATALOG
    .filter(course => course.isFree && course.isActive)
    .map(course => {
      let matchedSkills = [];
      const courseSkillsNormalized = course.skills.map(s => s.toLowerCase());

      for (const gap of normalizedGaps) {
        // Direct or partial match
        const found = courseSkillsNormalized.some(cs => cs.includes(gap) || gap.includes(cs));
        if (found) {
          const originalSkill = course.skills.find(s => s.toLowerCase().includes(gap) || gap.includes(s.toLowerCase()));
          if (originalSkill && !matchedSkills.includes(originalSkill)) {
            matchedSkills.push(originalSkill);
          }
        }
      }

      return {
        ...course,
        matchCount: matchedSkills.length,
        matchedGaps: matchedSkills,
      };
    })
    .filter(c => c.matchCount > 0)
    .sort((a, b) => b.matchCount - a.matchCount || b.rating - a.rating);

  // If matches found, return them. If fewer than 3, backfill with top active free foundational courses
  if (scored.length >= 3) {
    return scored.slice(0, 6);
  }

  const resultIds = new Set(scored.map(c => c.id));
  const fallback = COURSE_CATALOG
    .filter(c => c.isFree && c.isActive && !resultIds.has(c.id))
    .slice(0, 4 - scored.length);

  return [...scored, ...fallback];
}
