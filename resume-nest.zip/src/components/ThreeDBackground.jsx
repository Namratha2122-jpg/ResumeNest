import React, { useEffect, useRef, useState } from 'react';
import { useTheme } from '../context/ThemeContext.jsx';

export default function ThreeDBackground() {
  const { isDark } = useTheme();
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const containerRef = useRef(null);

  useEffect(() => {
    const handleMouseMove = (e) => {
      // Calculate normalized mouse offset (-1 to 1)
      const { innerWidth, innerHeight } = window;
      const x = (e.clientX / innerWidth - 0.5) * 2;
      const y = (e.clientY / innerHeight - 0.5) * 2;
      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const parallaxStyle1 = {
    transform: `translate3d(${mousePos.x * 25}px, ${mousePos.y * 25}px, 0px)`,
    transition: 'transform 0.2s cubic-bezier(0.1, 0.9, 0.2, 1)',
  };

  const parallaxStyle2 = {
    transform: `translate3d(${mousePos.x * -35}px, ${mousePos.y * -35}px, 0px)`,
    transition: 'transform 0.2s cubic-bezier(0.1, 0.9, 0.2, 1)',
  };

  const parallaxStyle3 = {
    transform: `translate3d(${mousePos.x * 15}px, ${mousePos.y * 15}px, 0px) rotate(${mousePos.x * 6}deg)`,
    transition: 'transform 0.2s cubic-bezier(0.1, 0.9, 0.2, 1)',
  };

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none"
      aria-hidden="true"
    >
      {/* 3D Horizon Grid (Infinite Cyber Floor) */}
      <div
        className="absolute -bottom-32 left-1/2 -translate-x-1/2 w-[200vw] h-[60vh] opacity-25"
        style={{
          perspective: '500px',
          transform: 'rotateX(72deg)',
          transformOrigin: 'bottom center',
        }}
      >
        <div
          className={`w-full h-full ${
            isDark
              ? 'bg-[linear-gradient(to_right,rgba(99,102,241,0.25)_1px,transparent_1px),linear-gradient(to_bottom,rgba(99,102,241,0.25)_1px,transparent_1px)]'
              : 'bg-[linear-gradient(to_right,rgba(79,70,229,0.18)_1px,transparent_1px),linear-gradient(to_bottom,rgba(79,70,229,0.18)_1px,transparent_1px)]'
          } bg-[size:48px_48px] [mask-image:linear-gradient(to_top,black,transparent_85%)]`}
        />
      </div>

      {/* Layer 1: Giant Ethereal 3D Color Orbs */}
      <div
        style={parallaxStyle1}
        className={`absolute -top-24 -left-24 w-96 h-96 sm:w-[550px] sm:h-[550px] rounded-full blur-[130px] transition-colors duration-500 ${
          isDark
            ? 'bg-gradient-to-br from-indigo-600/35 via-violet-600/25 to-transparent'
            : 'bg-gradient-to-br from-indigo-400/25 via-violet-300/20 to-transparent'
        }`}
      />

      <div
        style={parallaxStyle2}
        className={`absolute top-1/3 -right-32 w-96 h-96 sm:w-[500px] sm:h-[500px] rounded-full blur-[140px] transition-colors duration-500 ${
          isDark
            ? 'bg-gradient-to-bl from-cyan-500/25 via-teal-500/20 to-transparent'
            : 'bg-gradient-to-bl from-cyan-300/30 via-emerald-200/20 to-transparent'
        }`}
      />

      <div
        style={parallaxStyle1}
        className={`absolute -bottom-24 left-1/3 w-80 h-80 sm:w-[450px] sm:h-[450px] rounded-full blur-[120px] transition-colors duration-500 ${
          isDark
            ? 'bg-gradient-to-tr from-amber-500/20 via-orange-600/15 to-transparent'
            : 'bg-gradient-to-tr from-amber-300/25 via-yellow-200/20 to-transparent'
        }`}
      />

      {/* Layer 2: Floating 3D Geometric Isometric Polyhedra (Pure SVG) */}

      {/* 3D Isometric Cube 1 (Top Right) */}
      <div
        style={parallaxStyle3}
        className="absolute top-24 right-[12%] w-24 h-24 hidden lg:block opacity-60 animate-float"
      >
        <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_15px_20px_rgba(99,102,241,0.3)]">
          {/* Top Face */}
          <polygon points="50,15 85,35 50,55 15,35" fill={isDark ? '#818CF8' : '#C7D2FE'} />
          {/* Left Face */}
          <polygon points="15,35 50,55 50,90 15,70" fill={isDark ? '#4F46E5' : '#818CF8'} />
          {/* Right Face */}
          <polygon points="50,55 85,35 85,70 50,90" fill={isDark ? '#3730A3' : '#4F46E5'} />
          {/* Glowing Vertex Accents */}
          <circle cx="50" cy="15" r="2.5" fill="#38BDF8" />
          <circle cx="85" cy="35" r="2.5" fill="#38BDF8" />
          <circle cx="15" cy="35" r="2.5" fill="#38BDF8" />
          <circle cx="50" cy="55" r="2.5" fill="#FDE047" />
        </svg>
      </div>

      {/* 3D Isometric Crystal Diamond 2 (Mid Left) */}
      <div
        style={parallaxStyle2}
        className="absolute top-[48%] left-[6%] w-20 h-24 hidden lg:block opacity-50 animate-float-slow"
      >
        <svg viewBox="0 0 80 100" className="w-full h-full filter drop-shadow-[0_12px_24px_rgba(6,182,212,0.3)]">
          {/* Top Diamond Apex */}
          <polygon points="40,5 75,45 40,55 5,45" fill={isDark ? '#22D3EE' : '#67E8F9'} />
          {/* Bottom Diamond Pyramid */}
          <polygon points="5,45 40,55 40,95" fill={isDark ? '#0891B2' : '#06B6D4'} />
          <polygon points="40,55 75,45 40,95" fill={isDark ? '#0E7490' : '#0891B2'} />
          {/* Center Glow */}
          <circle cx="40" cy="55" r="3" fill="#FFFFFF" />
        </svg>
      </div>

      {/* 3D Floating Ring / Torus (Bottom Right) */}
      <div
        style={parallaxStyle1}
        className="absolute bottom-28 right-[8%] w-28 h-28 hidden lg:block opacity-45 animate-float"
      >
        <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_15px_25px_rgba(245,158,11,0.25)]">
          <ellipse
            cx="50"
            cy="50"
            rx="40"
            ry="20"
            fill="none"
            stroke={isDark ? '#F59E0B' : '#FBBF24'}
            strokeWidth="8"
            strokeDasharray="180 30"
            transform="rotate(-25 50 50)"
          />
          <ellipse
            cx="50"
            cy="50"
            rx="24"
            ry="12"
            fill="none"
            stroke={isDark ? '#6366F1' : '#818CF8'}
            strokeWidth="4"
            transform="rotate(-25 50 50)"
          />
        </svg>
      </div>

      {/* Subtle Star Particle Flecks */}
      <div className="absolute inset-0 opacity-40">
        {[
          { top: '15%', left: '25%', size: '3px', delay: '0s' },
          { top: '22%', left: '78%', size: '4px', delay: '1.2s' },
          { top: '65%', left: '18%', size: '3.5px', delay: '2.1s' },
          { top: '75%', left: '85%', size: '4.5px', delay: '0.8s' },
          { top: '42%', left: '92%', size: '3px', delay: '3.0s' },
          { top: '88%', left: '45%', size: '4px', delay: '1.7s' },
        ].map((star, i) => (
          <div
            key={i}
            className={`absolute rounded-full animate-pulse ${
              isDark ? 'bg-cyan-300 shadow-[0_0_8px_#22d3ee]' : 'bg-indigo-500 shadow-[0_0_6px_#6366f1]'
            }`}
            style={{
              top: star.top,
              left: star.left,
              width: star.size,
              height: star.size,
              animationDelay: star.delay,
              animationDuration: '2.8s',
            }}
          />
        ))}
      </div>
    </div>
  );
}
