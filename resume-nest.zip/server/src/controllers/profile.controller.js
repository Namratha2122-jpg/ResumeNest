import { firestoreDb } from '../config/firebaseAdmin.js';
import { validateProfileInput } from '../validators/profile.validator.js';

// Local store for profiles when Firestore credentials are not mounted
const localProfiles = new Map();

/**
 * Get authenticated student profile
 * GET /api/profile
 */
export async function getProfile(req, res, next) {
  try {
    const userId = req.user.uid;

    let profile = null;
    if (firestoreDb) {
      const doc = await firestoreDb.collection('users').doc(userId).get();
      if (doc.exists) {
        profile = doc.data();
      }
    } else {
      profile = localProfiles.get(userId);
    }

    if (!profile) {
      // Return default profile based on authenticated user
      profile = {
        userId,
        email: req.user.email,
        name: req.user.name,
        college: req.user.collegeName,
        domain: req.user.domain,
        major: 'Computer Science',
        degree: 'Bachelor of Science',
        graduationYear: '2026',
        targetRole: 'Software Engineer',
        bio: 'Passionate student preparing for software engineering and technical roles.',
        skills: ['Python', 'JavaScript', 'React', 'SQL', 'Git'],
        onboarded: true,
      };
    }

    return res.json({ profile });
  } catch (error) {
    next(error);
  }
}

/**
 * Update authenticated student profile
 * PUT /api/profile
 */
export async function updateProfile(req, res, next) {
  try {
    const userId = req.user.uid;
    validateProfileInput(req.body);

    // Prevent client from changing core security fields
    const { userId: _u, domain: _d, email: _e, ...safeUpdates } = req.body;

    const updated = {
      userId,
      email: req.user.email,
      domain: req.user.domain,
      college: req.user.collegeName,
      ...safeUpdates,
      updatedAt: new Date().toISOString(),
    };

    if (firestoreDb) {
      await firestoreDb.collection('users').doc(userId).set(updated, { merge: true });
    } else {
      localProfiles.set(userId, updated);
    }

    return res.json({ profile: updated, message: 'Profile updated successfully.' });
  } catch (error) {
    next(error);
  }
}
