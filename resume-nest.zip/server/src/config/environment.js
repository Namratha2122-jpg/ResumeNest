import dotenv from 'dotenv';
dotenv.config();

export const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  geminiApiKey: process.env.GEMINI_API_KEY || '',
  firebaseProjectId: process.env.FIREBASE_PROJECT_ID || '',
  firebaseClientEmail: process.env.FIREBASE_CLIENT_EMAIL || '',
  firebasePrivateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n') || '',
  appUrl: process.env.APP_URL || 'http://localhost:3000',
  // Exactly two authorized administrator accounts
  authorizedAdmins: [
    {
      email: 'nagasuryadinesh@gmail.com',
      name: 'Naga Surya Dinesh',
      role: 'Deployment Owner & Super Administrator',
    },
    {
      email: process.env.NAMRATHA_ADMIN_EMAIL || 'namrathasiri@gmail.com',
      aliases: ['namratha.siri@gmail.com'],
      name: 'Namratha Siri',
      role: 'Administrator',
    },
  ],
};
