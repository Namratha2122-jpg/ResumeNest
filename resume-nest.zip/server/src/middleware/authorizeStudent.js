import { isDomainApproved } from '../services/db.service.js';

/**
 * Student Authorization Middleware
 * Enforces college domain authorization against approvedCollegeDomains collection.
 * Rejects unauthorized domains with 403 Forbidden.
 */
export async function authorizeStudent(req, res, next) {
  if (!req.user || !req.user.domain) {
    return res.status(401).json({
      error: 'Please sign in to continue.',
      code: 'UNAUTHORIZED',
    });
  }

  const isApproved = await isDomainApproved(req.user.domain);

  if (!isApproved) {
    return res.status(403).json({
      error: 'Resume Nest is currently available only to students using an approved college email address.',
      code: 'FORBIDDEN_DOMAIN',
      domain: req.user.domain,
      email: req.user.email,
    });
  }

  req.user.userType = 'student';
  req.user.isAuthorized = true;
  next();
}
