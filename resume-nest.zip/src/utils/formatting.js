/**
 * Formatting Utilities
 */

export function formatDate(dateString) {
  if (!dateString) return '';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('en-US', {
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateString;
  }
}

export function getScoreColor(score) {
  if (score >= 85) return 'text-emerald-500';
  if (score >= 70) return 'text-blue-500';
  if (score >= 55) return 'text-amber-500';
  return 'text-rose-500';
}

export function getScoreBgColor(score) {
  if (score >= 85) return 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400';
  if (score >= 70) return 'bg-blue-500/10 border-blue-500/20 text-blue-400';
  if (score >= 55) return 'bg-amber-500/10 border-amber-500/20 text-amber-400';
  return 'bg-rose-500/10 border-rose-500/20 text-rose-400';
}

export function getScoreBadge(score) {
  if (score >= 85) {
    return {
      text: 'ATS Ready (Top 10%)',
      badgeClass: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
      description: 'Optimized for automated enterprise recruiters & screening robots.',
    };
  }
  if (score >= 70) {
    return {
      text: 'Competitive Candidate',
      badgeClass: 'bg-blue-500/15 text-blue-300 border-blue-500/30',
      description: 'Solid structure. Minor keyword optimization recommended.',
    };
  }
  if (score >= 55) {
    return {
      text: 'Borderline Passing',
      badgeClass: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
      description: 'Missing crucial technical keywords and quantifiable metrics.',
    };
  }
  return {
    text: 'High Rejection Risk',
    badgeClass: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
    description: 'Significant formatting or skill deficiencies likely to fail automated filters.',
  };
}
