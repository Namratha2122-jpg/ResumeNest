import { useEffect, useState, useRef, useCallback } from 'react';

/**
 * Custom React Hook for Real-Time Database Streaming (SSE)
 * Connects instantly to the Resume Nest server Pub/Sub hub.
 */
export function useRealtime(eventHandlers = {}) {
  const [isConnected, setIsConnected] = useState(false);
  const [activeSubscribers, setActiveSubscribers] = useState(1);
  const [lastEvent, setLastEvent] = useState(null);
  const eventSourceRef = useRef(null);
  const reconnectTimeoutRef = useRef(null);
  const handlersRef = useRef(eventHandlers);

  handlersRef.current = eventHandlers;

  const connect = useCallback(() => {
    if (typeof window === 'undefined') return;

    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    try {
      const es = new EventSource('/api/realtime/stream');
      eventSourceRef.current = es;

      es.addEventListener('connected', (e) => {
        try {
          const data = JSON.parse(e.data);
          setIsConnected(true);
          if (data.activeSubscribers) {
            setActiveSubscribers(data.activeSubscribers);
          }
        } catch (err) {
          setIsConnected(true);
        }
      });

      es.addEventListener('ping', (e) => {
        try {
          const data = JSON.parse(e.data);
          setIsConnected(true);
          if (data.activeClients) {
            setActiveSubscribers(data.activeClients);
          }
        } catch (err) {}
      });

      es.addEventListener('templates:created', (e) => {
        try {
          const data = JSON.parse(e.data);
          setLastEvent({ type: 'templates:created', data });
          if (handlersRef.current['templates:created']) {
            handlersRef.current['templates:created'](data);
          }
        } catch (err) {
          console.error('[Realtime] Failed to parse template event:', err);
        }
      });

      es.addEventListener('templates:upvoted', (e) => {
        try {
          const data = JSON.parse(e.data);
          setLastEvent({ type: 'templates:upvoted', data });
          if (handlersRef.current['templates:upvoted']) {
            handlersRef.current['templates:upvoted'](data);
          }
        } catch (err) {
          console.error('[Realtime] Failed to parse upvote event:', err);
        }
      });

      es.addEventListener('courses:updated', (e) => {
        try {
          const data = JSON.parse(e.data);
          setLastEvent({ type: 'courses:updated', data });
          if (handlersRef.current['courses:updated']) {
            handlersRef.current['courses:updated'](data);
          }
        } catch (err) {}
      });

      es.onerror = () => {
        setIsConnected(false);
        es.close();
        // Reconnect after 3 seconds
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = setTimeout(connect, 3000);
      };
    } catch (err) {
      console.warn('[Realtime] SSE connection error:', err);
    }
  }, []);

  useEffect(() => {
    connect();

    return () => {
      clearTimeout(reconnectTimeoutRef.current);
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, [connect]);

  return {
    isConnected,
    activeSubscribers,
    lastEvent,
  };
}
