import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';
import {
  GraduationCap,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Lock,
} from 'lucide-react';

const DEMO_CAMPUS_ACCOUNTS = [
  { name: 'Alex Chen', email: 'alex.chen@stanford.edu', college: 'Stanford University' },
  { name: 'Maya Patel', email: 'mayap@mit.edu', college: 'MIT' },
  { name: 'Jordan Lee', email: 'jordan@berkeley.edu', college: 'UC Berkeley' },
  { name: 'Sarah Miller', email: 'smiller@harvard.edu', college: 'Harvard University' },
  { name: 'Rohan Sharma', email: 'rohan@iitb.ac.in', college: 'IIT Bombay' },
];

export default function Login() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogin = async (targetEmail, targetName) => {
    setErrorMsg('');
    setLoading(true);

    const emailToUse = targetEmail || email;
    const nameToUse = targetName || name;

    if (!emailToUse || !emailToUse.includes('@')) {
      setErrorMsg('Please provide a valid email address.');
      setLoading(false);
      return;
    }

    try {
      const result = await login(emailToUse, nameToUse);

      if (result.success) {
        // Redirect to intended route or dashboard
        const from = location.state?.from?.pathname || '/dashboard';
        navigate(from, { replace: true });
      } else if (result.status === 403) {
        // Authoritative backend rejection
        navigate('/access-denied');
      } else {
        setErrorMsg(result.error || 'Failed to sign in. Please verify your details.');
      }
    } catch (err) {
      setErrorMsg(err.message || 'An error occurred during authentication.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-12">
      <div className="rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 sm:p-8 space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center mx-auto mb-3 shadow-inner">
            <GraduationCap className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Campus Sign In</h2>
          <p className="text-xs text-slate-400">
            Sign in with your verified college or university email address.
          </p>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center space-x-2.5 text-xs text-rose-300">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleLogin();
          }}
          className="space-y-4"
        >
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">
              Full Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Alex Chen"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">
              Campus Email Address (.edu, .ac.*, etc.)
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. student@stanford.edu"
              required
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Backend authoritatively validates domain eligibility.
            </p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center space-x-2"
          >
            <span>{loading ? 'Verifying with Backend...' : 'Authenticate with Campus Email'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="relative flex py-2 items-center">
          <div className="flex-grow border-t border-slate-800"></div>
          <span className="flex-shrink mx-3 text-[11px] text-slate-500 uppercase tracking-wider font-semibold">
            Or Test With Demo Account
          </span>
          <div className="flex-grow border-t border-slate-800"></div>
        </div>

        {/* Quick Demo Campus Account Switcher */}
        <div className="space-y-2">
          <p className="text-[11px] text-slate-400 font-medium">
            Click any verified student to authenticate immediately:
          </p>
          <div className="grid grid-cols-1 gap-2">
            {DEMO_CAMPUS_ACCOUNTS.map((acc, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  setEmail(acc.email);
                  setName(acc.name);
                  handleLogin(acc.email, acc.name);
                }}
                className="w-full p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800/80 hover:border-indigo-500/40 text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <p className="text-xs font-semibold text-white group-hover:text-indigo-300">
                    {acc.name}
                  </p>
                  <p className="text-[11px] text-emerald-400 font-mono">{acc.email}</p>
                </div>
                <span className="text-[10px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                  {acc.college}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Test 403 Forbidden Flow Button */}
        <div className="pt-3 border-t border-slate-800">
          <button
            type="button"
            onClick={() => {
              setEmail('user@gmail.com');
              setName('Personal Account');
              handleLogin('user@gmail.com', 'Personal Account');
            }}
            className="w-full py-2 px-3 rounded-lg bg-slate-950 hover:bg-slate-800 border border-dashed border-rose-500/30 text-rose-300 text-xs font-medium transition-colors flex items-center justify-center space-x-1.5"
          >
            <span>Test 403 Gatekeeper Rejection (e.g. user@gmail.com)</span>
          </button>
        </div>
      </div>
    </div>
  );
}
