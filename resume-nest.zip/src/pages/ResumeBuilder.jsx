import React, { useEffect, useState } from 'react';
import { useSearchParams, useParams, useNavigate } from 'react-router-dom';
import { useResume } from '../hooks/useResume.js';
import ResumeForm from '../components/ResumeForm.jsx';
import ResumePreview from '../components/ResumePreview.jsx';
import LoadingState from '../components/LoadingState.jsx';
import ErrorState from '../components/ErrorState.jsx';
import {
  FileEdit,
  Eye,
  Sparkles,
  ArrowRight,
  SplitSquareVertical,
  Check,
} from 'lucide-react';

export default function ResumeBuilder() {
  const [searchParams] = useSearchParams();
  const routeParams = useParams();
  const resumeId = routeParams.resumeId || searchParams.get('id');
  const navigate = useNavigate();

  const {
    getResume,
    createResume,
    updateResume,
    improveSection,
    loading: hookLoading,
  } = useResume();

  const [resumeData, setResumeData] = useState(null);
  const [loading, setLoading] = useState(!!resumeId && resumeId !== 'new');
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('editor'); // 'editor', 'preview', 'split'
  const [currentId, setCurrentId] = useState(resumeId && resumeId !== 'new' ? resumeId : null);

  useEffect(() => {
    async function loadResume() {
      if (resumeId && resumeId !== 'new') {
        setLoading(true);
        try {
          const doc = await getResume(resumeId);
          setResumeData(doc);
          setCurrentId(doc.id);
        } catch (err) {
          console.error('Failed to load resume:', err);
        } finally {
          setLoading(false);
        }
      } else {
        // Fresh resume - check if user clicked "Use Template" from Community Hub
        let templateData = null;
        try {
          const raw = localStorage.getItem('resume_nest_imported_template');
          if (raw) {
            templateData = JSON.parse(raw);
            localStorage.removeItem('resume_nest_imported_template');
          }
        } catch (e) {}

        setResumeData({
          title: templateData?.title || 'Software Engineering Resume - 2026',
          targetRole: templateData?.targetRole || 'Software Engineer',
          personalInfo: {
            fullName: user?.name || 'Alex Chen',
            email: user?.email || 'alex.chen@stanford.edu',
            phone: '(650) 555-0199',
            location: user?.collegeName || 'Stanford, CA',
            linkedin: 'linkedin.com/in/' + (user?.name?.toLowerCase().replace(/\s+/g, '') || 'alexchen'),
            github: 'github.com/' + (user?.name?.toLowerCase().replace(/\s+/g, '') || 'alexchen'),
          },
          summary:
            'Motivated undergraduate with strong background in distributed systems, RESTful microservices, and React. Proven record in optimizing server latency and automating cloud deployment workflows.',
          education: [
            {
              institution: user?.collegeName || 'Stanford University',
              degree: 'Bachelor of Science in Computer Science',
              graduationYear: '2026',
              gpa: '3.85 / 4.0',
              coursework:
                'Data Structures, Algorithms, Operating Systems, Computer Networking, Database Systems, Artificial Intelligence',
            },
          ],
          skills: {
            languages: templateData?.skills || 'Python, TypeScript, JavaScript, Go, C++, SQL',
            frameworks: 'React, Node.js, Express, Next.js, Tailwind CSS',
            developerTools: 'Git, Docker, Linux, PostgreSQL, MongoDB, Redis, Vite',
            coreConcepts: 'REST APIs, Microservices, CI/CD, Raft Consensus, Distributed Systems',
          },
          experience: [
            {
              role: 'Software Engineering Intern',
              company: 'CloudScale Technologies',
              location: 'San Francisco, CA',
              period: 'Jun 2025 - Aug 2025',
              bullets: [
                templateData?.bullet ||
                  'Architected high-throughput microservices using Node.js and Express, improving API response times by 32% under peak workloads.',
                'Built modular React dashboards adopted by 15,000+ daily active engineering users across internal portals.',
                'Configured GitHub Actions CI/CD pipelines and Docker containerization, reducing build failure rates by 40%.',
              ],
            },
          ],
          projects: [
            {
              title: 'Distributed Key-Value Store',
              technologies: 'Go, Docker, Raft, gRPC',
              link: 'https://github.com/alexchen/distributed-kv',
              description:
                'Engineered a distributed, fault-tolerant key-value store implementing the Raft consensus algorithm. Successfully survived simulated network partitions without data corruption.',
            },
            {
              title: 'AI Resume Keyword Engine',
              technologies: 'React, Node.js, PostgreSQL, Tailwind CSS',
              link: 'https://github.com/alexchen/resume-engine',
              description:
                'Created a full-stack tool parsing developer resumes and identifying ATS keyword disparities with 94% screening accuracy.',
            },
          ],
          certifications: [
            'Google Cloud Associate Cloud Engineer (2025)',
            'Stanford ACM Competitive Programming Finalist (2024)',
          ],
        });
        setLoading(false);
      }
    }

    loadResume();
  }, [resumeId, getResume]);

  const handleSave = async (formData) => {
    setSaving(true);
    try {
      if (currentId) {
        const updated = await updateResume(currentId, formData);
        setResumeData(updated);
        return updated;
      } else {
        const created = await createResume(formData);
        setCurrentId(created.id);
        setResumeData(created);
        navigate(`/resume/${created.id}`, { replace: true });
        return created;
      }
    } catch (err) {
      console.error('Save failed:', err);
      throw err;
    } finally {
      setSaving(false);
    }
  };

  const handleImproveSection = async ({ section, content, targetRole, instruction }) => {
    return await improveSection({
      resumeId: currentId,
      section,
      content,
      targetRole,
      instruction,
    });
  };

  const handlePreFillSample = (setFormData) => {
    const sample = {
      title: 'Machine Learning & Full Stack Resume',
      targetRole: 'Machine Learning Engineer',
      personalInfo: {
        fullName: 'Maya Patel',
        email: 'mayap@mit.edu',
        phone: '(617) 555-0142',
        location: 'Cambridge, MA',
        linkedin: 'linkedin.com/in/mayapatel',
        github: 'github.com/mayapatel',
      },
      summary:
        'MIT Computer Science junior specialized in deep learning, natural language processing, and scalable data pipelines. Published research in low-latency transformer inference with experience training PyTorch models on distributed GPU clusters.',
      education: [
        {
          institution: 'Massachusetts Institute of Technology (MIT)',
          degree: 'Bachelor of Science in Computer Science and Engineering (Course 6-3)',
          graduationYear: '2026',
          gpa: '4.9 / 5.0',
          coursework:
            'Machine Learning (6.036), Deep Learning (6.S191), Algorithms (6.006), Computational Biology, Linear Algebra',
        },
      ],
      skills: {
        languages: 'Python, C++, SQL, Julia, Bash, TypeScript',
        frameworks: 'PyTorch, TensorFlow, HuggingFace, Scikit-Learn, FastAPI, React',
        developerTools: 'Docker, Kubernetes, CUDA, Linux, Git, Weights & Biases',
        coreConcepts: 'Transformers, Quantization, Distributed Training, Data Pipelines, LLM Fine-Tuning',
      },
      experience: [
        {
          role: 'Machine Learning Research Intern',
          company: 'MIT CSAIL Lab',
          location: 'Cambridge, MA',
          period: 'Jan 2025 - Present',
          bullets: [
            'Fine-tuned open-source LLMs on specialized domain datasets, boosting domain extraction accuracy by 28% over base benchmarks.',
            'Optimized model inference latency using INT8 quantization and TensorRT, achieving 3.4x speedup on edge GPUs.',
            'Co-authored research submission for NeurIPS workshop on efficient parameter tuning.',
          ],
        },
      ],
      projects: [
        {
          title: 'Distributed Neural Architecture Search',
          technologies: 'Python, PyTorch, Ray, Docker',
          link: 'https://github.com/mayap/distributed-nas',
          description:
            'Built an asynchronous neural architecture search system exploring 500+ CNN variations concurrently using Ray on university clusters.',
        },
      ],
      certifications: [
        'DeepLearning.AI Machine Learning Specialization (Andrew Ng)',
        '1st Place - MIT HackMIT AI Track (2024)',
      ],
    };
    setFormData(sample);
    setResumeData(sample);
  };

  if (loading) {
    return <LoadingState message="Loading your resume..." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <span>ATS Resume Builder</span>
            {currentId && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-mono">
                ID: {currentId.slice(0, 10)}
              </span>
            )}
          </h1>
          <p className="text-xs text-slate-400">
            Build and optimize an ATS-compliant single-column resume formatted for recruiters.
          </p>
        </div>

        {/* View Toggle & Analysis Trigger */}
        <div className="flex items-center space-x-3 w-full sm:w-auto justify-between sm:justify-end">
          {/* Tab selector */}
          <div className="flex rounded-xl bg-slate-900 p-1 border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('editor')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === 'editor' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileEdit className="w-3.5 h-3.5" />
              <span>Editor</span>
            </button>
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === 'preview' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Preview</span>
            </button>
            <button
              onClick={() => setActiveTab('split')}
              className={`hidden lg:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === 'split' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <SplitSquareVertical className="w-3.5 h-3.5" />
              <span>Split View</span>
            </button>
          </div>

          {currentId && (
            <button
              onClick={() => navigate(`/analyze/${currentId}`)}
              className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-500/20 transition-all active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Analyze with Gemini</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Editor Content Area */}
      <div>
        {activeTab === 'editor' && (
          <ResumeForm
            initialData={resumeData}
            onSave={handleSave}
            isSaving={saving}
            onImproveSection={handleImproveSection}
            onPreFillSample={handlePreFillSample}
          />
        )}

        {activeTab === 'preview' && (
          <ResumePreview resumeData={resumeData} />
        )}

        {activeTab === 'split' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            <div className="max-h-[calc(100vh-180px)] overflow-y-auto pr-2">
              <ResumeForm
                initialData={resumeData}
                onSave={handleSave}
                isSaving={saving}
                onImproveSection={handleImproveSection}
                onPreFillSample={handlePreFillSample}
              />
            </div>
            <div className="max-h-[calc(100vh-180px)] overflow-y-auto pl-2 sticky top-24">
              <ResumePreview resumeData={resumeData} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
