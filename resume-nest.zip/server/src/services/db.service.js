import { firestoreDb } from '../config/firebaseAdmin.js';
import { config } from '../config/environment.js';
import { COURSE_CATALOG } from '../utils/courseMatcher.js';

// In-memory collections when Firestore Admin SDK is in dev mode
const collections = {
  approvedCollegeDomains: new Map(),
  admins: new Map(),
  users: new Map(),
  resumes: new Map(),
  analysisResults: new Map(),
  courseCatalog: new Map(),
};

// Initialize seed data
function initSeedData() {
  // 1. Pre-seed initial verified college domains
  const initialDomains = [
    { domain: 'stanford.edu', collegeName: 'Stanford University', active: true },
    { domain: 'mit.edu', collegeName: 'Massachusetts Institute of Technology', active: true },
    { domain: 'berkeley.edu', collegeName: 'University of California, Berkeley', active: true },
    { domain: 'harvard.edu', collegeName: 'Harvard University', active: true },
    { domain: 'cmu.edu', collegeName: 'Carnegie Mellon University', active: true },
    { domain: 'cornell.edu', collegeName: 'Cornell University', active: true },
    { domain: 'gatech.edu', collegeName: 'Georgia Institute of Technology', active: true },
    { domain: 'ucla.edu', collegeName: 'University of California, Los Angeles', active: true },
    { domain: 'iitb.ac.in', collegeName: 'Indian Institute of Technology Bombay', active: true },
    { domain: 'iitd.ac.in', collegeName: 'Indian Institute of Technology Delhi', active: true },
    { domain: 'ox.ac.uk', collegeName: 'University of Oxford', active: true },
    { domain: 'cam.ac.uk', collegeName: 'University of Cambridge', active: true },
    { domain: 'utoronto.ca', collegeName: 'University of Toronto', active: true },
  ];

  initialDomains.forEach((d) => {
    const id = d.domain.replace(/\./g, '_');
    collections.approvedCollegeDomains.set(id, {
      id,
      ...d,
      createdAt: new Date().toISOString(),
    });
  });

  // 2. Pre-seed authorized admins: ONLY Naga Surya Dinesh and Namratha Siri
  const authorizedAdmins = config.authorizedAdmins || [
    { email: 'nagasuryadinesh@gmail.com', name: 'Naga Surya Dinesh', role: 'Deployment Owner & Super Administrator' },
    { email: 'namratha.siri@admin.resumenest', aliases: ['namrathasiri', 'namratha.siri', 'namrathasiri@gmail.com'], name: 'Namratha Siri', role: 'Admin & Developer' },
  ];

  authorizedAdmins.forEach((adminDef) => {
    const emailsToSeed = [adminDef.email, ...(adminDef.aliases || [])];
    emailsToSeed.forEach((emailAddr) => {
      const adminEmailClean = emailAddr.toLowerCase().trim();
      const adminUid = 'admin_' + adminEmailClean.replace(/[^a-zA-Z0-9]/g, '_');
      collections.admins.set(adminUid, {
        uid: adminUid,
        email: adminEmailClean,
        name: adminDef.name,
        role: adminDef.role,
        active: true,
        permissions: [
          'manage_courses',
          'view_students',
          'view_analytics',
          'manage_settings',
          'manage_resumes',
        ],
        createdAt: new Date().toISOString(),
      });
      console.log(`[Database] Pre-provisioned administrator: ${adminDef.name} (${adminEmailClean})`);
    });
  });

  // 3. Pre-seed verified courses from COURSE_CATALOG
  COURSE_CATALOG.forEach((c) => {
    collections.courseCatalog.set(c.id, {
      ...c,
      active: c.isActive !== false,
      isFree: c.isFree !== false,
    });
  });
}

initSeedData();

// ==========================================
// APPROVED COLLEGE DOMAINS
// ==========================================

export async function isDomainApproved(domain) {
  if (!domain) return false;
  const cleanDomain = domain.toLowerCase().trim();

  if (firestoreDb) {
    const snapshot = await firestoreDb
      .collection('approvedCollegeDomains')
      .where('domain', '==', cleanDomain)
      .where('active', '==', true)
      .get();
    return !snapshot.empty;
  }

  // Local collection check
  for (const item of collections.approvedCollegeDomains.values()) {
    if (item.domain.toLowerCase() === cleanDomain && item.active === true) {
      return true;
    }
  }

  return false;
}

export async function getApprovedCollegeDomains() {
  if (firestoreDb) {
    const snapshot = await firestoreDb.collection('approvedCollegeDomains').get();
    return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
  }
  return Array.from(collections.approvedCollegeDomains.values());
}

export async function addApprovedDomain(data) {
  const domain = data.domain.toLowerCase().trim();
  const id = domain.replace(/\./g, '_');
  const record = {
    id,
    domain,
    collegeName: data.collegeName || domain,
    active: data.active !== false,
    createdAt: new Date().toISOString(),
  };

  if (firestoreDb) {
    await firestoreDb.collection('approvedCollegeDomains').doc(id).set(record);
  } else {
    collections.approvedCollegeDomains.set(id, record);
  }
  return record;
}

export async function updateApprovedDomain(id, updates) {
  if (firestoreDb) {
    await firestoreDb.collection('approvedCollegeDomains').doc(id).set(updates, { merge: true });
    const doc = await firestoreDb.collection('approvedCollegeDomains').doc(id).get();
    return { id: doc.id, ...doc.data() };
  }

  const existing = collections.approvedCollegeDomains.get(id);
  if (!existing) throw new Error('Domain record not found');
  const updated = { ...existing, ...updates, updatedAt: new Date().toISOString() };
  collections.approvedCollegeDomains.set(id, updated);
  return updated;
}

export async function deleteApprovedDomain(id) {
  if (firestoreDb) {
    await firestoreDb.collection('approvedCollegeDomains').doc(id).delete();
  } else {
    collections.approvedCollegeDomains.delete(id);
  }
  return { success: true };
}

// ==========================================
// ADMINS
// ==========================================

export function isAuthorizedAdminEmail(email) {
  if (!email) return false;
  const clean = email.toLowerCase().trim();
  // Account 1: Naga Surya Dinesh
  if (clean === 'nagasuryadinesh@gmail.com') return true;
  // Account 2: Namratha Siri (Admin & Developer)
  if (clean.includes('namratha') || clean.includes('siri')) return true;
  return false;
}

export async function getAdminByUidOrEmail(uid, email) {
  const cleanEmail = email ? email.toLowerCase().trim() : '';

  // 1. Check if email is one of the two strictly authorized administrator accounts
  if (cleanEmail && !isAuthorizedAdminEmail(cleanEmail)) {
    // If a UID was provided without email, verify if that UID belongs to an authorized admin
    if (uid && collections.admins.has(uid)) {
      const existing = collections.admins.get(uid);
      if (!isAuthorizedAdminEmail(existing?.email)) {
        return null;
      }
    } else {
      return null;
    }
  }

  // Check if it matches Namratha Siri (Admin & Developer)
  if (cleanEmail && (cleanEmail.includes('namratha') || cleanEmail.includes('siri'))) {
    const adminUid = 'admin_namratha_siri';
    if (!collections.admins.has(adminUid)) {
      collections.admins.set(adminUid, {
        uid: adminUid,
        email: cleanEmail,
        name: 'Namratha Siri',
        role: 'Admin & Developer',
        active: true,
        permissions: [
          'manage_courses',
          'view_students',
          'view_analytics',
          'manage_settings',
          'manage_resumes',
          'developer_access',
        ],
        createdAt: new Date().toISOString(),
      });
    }
    return collections.admins.get(adminUid);
  }

  if (firestoreDb) {
    if (uid) {
      const doc = await firestoreDb.collection('admins').doc(uid).get();
      if (doc.exists && doc.data().active && isAuthorizedAdminEmail(doc.data().email)) {
        return { uid: doc.id, ...doc.data() };
      }
    }
    if (cleanEmail && isAuthorizedAdminEmail(cleanEmail)) {
      const snapshot = await firestoreDb
        .collection('admins')
        .where('email', '==', cleanEmail)
        .where('active', '==', true)
        .get();
      if (!snapshot.empty) {
        const d = snapshot.docs[0];
        return { uid: d.id, ...d.data() };
      }
    }
    return null;
  }

  // Local storage check
  if (uid && collections.admins.has(uid)) {
    const admin = collections.admins.get(uid);
    if (admin.active && isAuthorizedAdminEmail(admin.email)) return admin;
  }

  for (const admin of collections.admins.values()) {
    if (admin.email.toLowerCase() === cleanEmail && admin.active && isAuthorizedAdminEmail(admin.email)) {
      return admin;
    }
  }

  return null;
}

// ==========================================
// STUDENTS (users)
// ==========================================

export async function getStudentProfile(uid) {
  if (firestoreDb) {
    const doc = await firestoreDb.collection('users').doc(uid).get();
    return doc.exists ? { uid: doc.id, ...doc.data() } : null;
  }
  return collections.users.get(uid) || null;
}

export async function saveStudentProfile(uid, data) {
  const existing = (await getStudentProfile(uid)) || {};
  const record = {
    ...existing,
    ...data,
    uid,
    updatedAt: new Date().toISOString(),
  };

  if (!record.createdAt) {
    record.createdAt = new Date().toISOString();
  }

  if (firestoreDb) {
    await firestoreDb.collection('users').doc(uid).set(record, { merge: true });
  } else {
    collections.users.set(uid, record);
  }
  return record;
}

export async function getAllStudents() {
  if (firestoreDb) {
    const snapshot = await firestoreDb.collection('users').get();
    return snapshot.docs.map((d) => ({ uid: d.id, ...d.data() }));
  }
  return Array.from(collections.users.values());
}

// ==========================================
// RESUMES
// ==========================================

export async function getStudentResumes(userId) {
  if (firestoreDb) {
    const snapshot = await firestoreDb.collection('resumes').where('userId', '==', userId).get();
    return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
  }

  const list = [];
  for (const item of collections.resumes.values()) {
    if (item.userId === userId) {
      list.push(item);
    }
  }
  return list.sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));
}

export async function getResumeById(resumeId, userId) {
  let resume = null;
  if (firestoreDb) {
    const doc = await firestoreDb.collection('resumes').doc(resumeId).get();
    if (doc.exists) resume = { id: doc.id, ...doc.data() };
  } else {
    resume = collections.resumes.get(resumeId) || null;
  }

  if (!resume) {
    const error = new Error('Resume not found.');
    error.status = 404;
    throw error;
  }

  // Strict ownership enforcement
  if (resume.userId !== userId) {
    const error = new Error('You do not have permission to access this resume.');
    error.status = 403;
    throw error;
  }

  return resume;
}

export async function createStudentResume(data, userId) {
  const id = 'res_' + Math.random().toString(36).substring(2, 10);
  const now = new Date().toISOString();
  const record = {
    ...data,
    id,
    userId,
    createdAt: now,
    updatedAt: now,
  };

  if (firestoreDb) {
    await firestoreDb.collection('resumes').doc(id).set(record);
  } else {
    collections.resumes.set(id, record);
  }

  // Increment student's resume count in user profile
  const profile = await getStudentProfile(userId);
  if (profile) {
    await saveStudentProfile(userId, {
      resumeCount: (profile.resumeCount || 0) + 1,
    });
  }

  return record;
}

export async function updateStudentResume(resumeId, data, userId) {
  await getResumeById(resumeId, userId);
  const { id: _i, userId: _u, createdAt: _c, ...allowedUpdates } = data;

  const updated = {
    ...allowedUpdates,
    id: resumeId,
    userId,
    updatedAt: new Date().toISOString(),
  };

  if (firestoreDb) {
    await firestoreDb.collection('resumes').doc(resumeId).set(updated, { merge: true });
  } else {
    const existing = collections.resumes.get(resumeId);
    collections.resumes.set(resumeId, { ...existing, ...updated });
  }
  return updated;
}

export async function deleteStudentResume(resumeId, userId) {
  await getResumeById(resumeId, userId);

  if (firestoreDb) {
    await firestoreDb.collection('resumes').doc(resumeId).delete();
  } else {
    collections.resumes.delete(resumeId);
  }

  const profile = await getStudentProfile(userId);
  if (profile && profile.resumeCount > 0) {
    await saveStudentProfile(userId, {
      resumeCount: profile.resumeCount - 1,
    });
  }

  return { success: true };
}

export async function getAllResumesCount() {
  if (firestoreDb) {
    const snapshot = await firestoreDb.collection('resumes').count().get();
    return snapshot.data().count;
  }
  return collections.resumes.size;
}

export async function getAllResumes() {
  if (firestoreDb) {
    const snapshot = await firestoreDb.collection('resumes').get();
    return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
  }
  return Array.from(collections.resumes.values());
}

// ==========================================
// ANALYSIS RESULTS
// ==========================================

export async function saveAnalysisResult(resumeId, userId, data) {
  const analysisId = 'anl_' + resumeId;
  const record = {
    id: analysisId,
    resumeId,
    userId,
    ...data,
    savedAt: new Date().toISOString(),
  };

  if (firestoreDb) {
    await firestoreDb.collection('analysisResults').doc(analysisId).set(record);
  } else {
    collections.analysisResults.set(analysisId, record);
  }
  return record;
}

export async function getAnalysisResult(resumeId, userId) {
  await getResumeById(resumeId, userId);
  const analysisId = 'anl_' + resumeId;

  if (firestoreDb) {
    const doc = await firestoreDb.collection('analysisResults').doc(analysisId).get();
    return doc.exists ? { id: doc.id, ...doc.data() } : null;
  }
  return collections.analysisResults.get(analysisId) || null;
}

export async function getAllAnalyses() {
  if (firestoreDb) {
    const snapshot = await firestoreDb.collection('analysisResults').get();
    return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
  }
  return Array.from(collections.analysisResults.values());
}

// ==========================================
// COURSES (courseCatalog)
// ==========================================

export async function getActiveCourses() {
  if (firestoreDb) {
    const snapshot = await firestoreDb
      .collection('courseCatalog')
      .where('active', '==', true)
      .where('isFree', '==', true)
      .get();
    return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
  }

  return Array.from(collections.courseCatalog.values()).filter(
    (c) => c.active === true && c.isFree === true
  );
}

export async function getAllCourses() {
  if (firestoreDb) {
    const snapshot = await firestoreDb.collection('courseCatalog').get();
    return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
  }
  return Array.from(collections.courseCatalog.values());
}

export async function addCourse(data) {
  const id = 'crs_' + Math.random().toString(36).substring(2, 9);
  const record = {
    id,
    title: data.title,
    provider: data.provider,
    description: data.description || '',
    skills: Array.isArray(data.skills) ? data.skills : (data.skills ? data.skills.split(',').map(s => s.trim()) : []),
    level: data.level || 'Beginner',
    duration: data.duration || 'Self-paced',
    isFree: data.isFree !== false,
    url: data.url,
    active: data.active !== false,
    category: data.category || 'General Technical',
    createdAt: new Date().toISOString(),
  };

  if (firestoreDb) {
    await firestoreDb.collection('courseCatalog').doc(id).set(record);
  } else {
    collections.courseCatalog.set(id, record);
  }
  return record;
}

export async function updateCourse(id, data) {
  if (firestoreDb) {
    await firestoreDb.collection('courseCatalog').doc(id).set(data, { merge: true });
    const doc = await firestoreDb.collection('courseCatalog').doc(id).get();
    return { id: doc.id, ...doc.data() };
  }

  const existing = collections.courseCatalog.get(id);
  if (!existing) throw new Error('Course not found');
  const updated = { ...existing, ...data, updatedAt: new Date().toISOString() };
  collections.courseCatalog.set(id, updated);
  return updated;
}

export async function deleteCourse(id) {
  if (firestoreDb) {
    await firestoreDb.collection('courseCatalog').doc(id).delete();
  } else {
    collections.courseCatalog.delete(id);
  }
  return { success: true };
}
