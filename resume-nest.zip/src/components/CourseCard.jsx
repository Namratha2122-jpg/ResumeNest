import React from 'react';
import { ExternalLink, Star, Clock, Award, CheckCircle2 } from 'lucide-react';

export default function CourseCard({ course, highlightedSkills = [] }) {
  const isSkillMatched = (skill) => {
    return highlightedSkills.some(
      (hs) => hs.toLowerCase() === skill.toLowerCase() || skill.toLowerCase().includes(hs.toLowerCase())
    );
  };

  return (
    <div className="flex flex-col justify-between rounded-xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all p-5 shadow-lg group">
      <div>
        {/* Top Header: Provider & Badges */}
        <div className="flex items-center justify-between mb-2.5 gap-2">
          <span className="text-xs font-semibold text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded-full border border-indigo-500/20 truncate">
            {course.provider}
          </span>
          <div className="flex items-center space-x-1.5 flex-shrink-0">
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              100% Free
            </span>
          </div>
        </div>

        {/* Course Title */}
        <h4 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors mb-2 line-clamp-2">
          {course.title}
        </h4>

        {/* Description */}
        <p className="text-xs text-slate-400 mb-4 line-clamp-2 leading-relaxed">
          {course.description}
        </p>

        {/* Metadata: Duration & Rating */}
        <div className="flex items-center space-x-4 text-[11px] text-slate-400 mb-4">
          {course.duration && (
            <div className="flex items-center space-x-1">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>{course.duration}</span>
            </div>
          )}
          {course.rating && (
            <div className="flex items-center space-x-1 text-amber-400">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
              <span>{course.rating}</span>
            </div>
          )}
          {course.level && (
            <span className="text-slate-500">• {course.level}</span>
          )}
        </div>

        {/* Skills Taught */}
        {course.skills && course.skills.length > 0 && (
          <div className="mb-4">
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block mb-1.5">
              Skills Taught:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {course.skills.slice(0, 5).map((skill, i) => {
                const matched = isSkillMatched(skill);
                return (
                  <span
                    key={i}
                    className={`text-[10px] px-2 py-0.5 rounded font-medium ${
                      matched
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {skill}
                  </span>
                );
              })}
              {course.skills.length > 5 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800/60 text-slate-500">
                  +{course.skills.length - 5} more
                </span>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Action Button */}
      <div className="pt-3 border-t border-slate-800 flex items-center justify-between mt-auto">
        <span className="text-[11px] text-slate-500 font-mono truncate max-w-[140px]">
          {course.category}
        </span>
        <a
          href={course.url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-all shadow-sm group-hover:shadow-indigo-600/30"
        >
          <span>Enroll Free</span>
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>
    </div>
  );
}
