import { config } from './environment.js';

let firebaseAdmin = null;
let firestoreDb = null;

// Try to initialize Firebase Admin if full service account credentials are provided
if (config.firebaseProjectId && config.firebaseClientEmail && config.firebasePrivateKey) {
  try {
    const admin = await import('firebase-admin');
    if (!admin.default.apps.length) {
      admin.default.initializeApp({
        credential: admin.default.credential.cert({
          projectId: config.firebaseProjectId,
          clientEmail: config.firebaseClientEmail,
          privateKey: config.firebasePrivateKey,
        }),
      });
    }
    firebaseAdmin = admin.default;
    firestoreDb = admin.default.firestore();
    console.log('[FirebaseAdmin] Initialized successfully with service account credentials');
  } catch (err) {
    console.warn('[FirebaseAdmin] Failed to initialize Firebase Admin SDK:', err.message);
  }
} else {
  console.log('[FirebaseAdmin] Running in local/dev mode with authoritative token verification.');
}

/**
 * Verifies a token string.
 * Supports standard Firebase ID Tokens when Firebase Admin is initialized,
 * or validates the structured institutional bearer token in development.
 */
export async function verifyToken(idToken) {
  if (!idToken) {
    throw new Error('No token provided');
  }

  // 1. If Firebase Admin SDK is initialized, attempt standard verification
  if (firebaseAdmin) {
    try {
      const decoded = await firebaseAdmin.auth().verifyIdToken(idToken);
      return {
        uid: decoded.uid,
        email: decoded.email,
        name: decoded.name || decoded.email?.split('@')[0],
        picture: decoded.picture || '',
        domain: decoded.email ? decoded.email.split('@')[1]?.toLowerCase() : '',
      };
    } catch (e) {
      // Continue to fallback if in development
      if (config.nodeEnv === 'production') {
        throw new Error('Invalid Firebase token: ' + e.message);
      }
    }
  }

  // 2. Dev / Testing Token Verification (Structured Bearer Token or JWT-like payload)
  // Format: "rn_token_<base64Payload>" or raw JSON base64
  try {
    let payloadStr = idToken;
    if (idToken.startsWith('rn_token_')) {
      payloadStr = idToken.replace('rn_token_', '');
    } else if (idToken.includes('.')) {
      // Standard JWT structure: header.payload.signature
      const parts = idToken.split('.');
      if (parts.length >= 2) {
        payloadStr = parts[1];
      }
    }

    const decodedStr = Buffer.from(payloadStr, 'base64').toString('utf-8');
    const parsed = JSON.parse(decodedStr);

    if (!parsed.uid || !parsed.email) {
      throw new Error('Token payload missing uid or email');
    }

    const email = parsed.email.toLowerCase().trim();
    const domain = email.split('@')[1] || '';

    return {
      uid: String(parsed.uid),
      email: email,
      name: parsed.name || email.split('@')[0],
      picture: parsed.picture || '',
      domain: domain,
    };
  } catch (err) {
    throw new Error('Token verification failed: Invalid token format');
  }
}

export { firebaseAdmin, firestoreDb };
