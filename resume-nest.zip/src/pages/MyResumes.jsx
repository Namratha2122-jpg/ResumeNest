import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useResume } from '../hooks/useResume.js';
import EmptyState from '../components/EmptyState.jsx';
import LoadingState from '../components/LoadingState.jsx';
import {
  FolderOpen,
  Plus,
  FileEdit,
  Sparkles,
  Trash2,
  Copy,
  Printer,
  Calendar,
  Target,
  ArrowRight,
} from 'lucide-react';

export default function MyResumes() {
  const { resumes, fetchResumes, deleteResume, createResume, loading } = useResume();
  const [deletingId, setDeletingId] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchResumes();
  }, [fetchResumes]);

  const handleDelete = async (id, title) => {
    if (confirm(`Are you sure you want to delete "${title}"?`)) {
      setDeletingId(id);
      try {
        await deleteResume(id);
      } catch (err) {
        console.error('Delete failed:', err);
      } finally {
        setDeletingId(null);
      }
    }
  };

  const handleDuplicate = async (resume) => {
    const { id, userId, createdAt, updatedAt, ...copyData } = resume;
    const duplicated = {
      ...copyData,
      title: `${resume.title} (Copy)`,
    };
    try {
      const created = await createResume(duplicated);
      navigate(`/builder?id=${created.id}`);
    } catch (err) {
      console.error('Duplicate failed:', err);
    }
  };

  if (loading && resumes.length === 0) {
    return <LoadingState message="Loading your student resumes..." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <FolderOpen className="w-6 h-6 text-indigo-400" />
            <span>My Resumes</span>
          </h1>
          <p className="text-xs text-slate-400">
            Manage your tailored resume variations. Each document is stored securely under your student UID.
          </p>
        </div>

        <Link
          to="/resume/new"
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Resume</span>
        </Link>
      </div>

      {/* Resumes List */}
      {resumes.length === 0 ? (
        <EmptyState
          title="No resumes found"
          description="Build your first ATS-ready resume to start receiving Gemini screening reports and free course matches."
          actionText="Create Resume"
          actionLink="/resume/new"
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resumes.map((resume) => (
            <div
              key={resume.id}
              className="flex flex-col justify-between rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all p-5 shadow-lg space-y-4 group"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors line-clamp-1">
                    {resume.title}
                  </h3>
                  <button
                    onClick={() => handleDelete(resume.id, resume.title)}
                    disabled={deletingId === resume.id}
                    className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                    title="Delete resume"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex items-center space-x-2 text-xs text-slate-400 mb-3">
                  <Target className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Target: {resume.targetRole || 'Software Engineer'}</span>
                </div>

                <div className="text-[11px] text-slate-500 flex items-center space-x-1.5 mb-4">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Updated: {new Date(resume.updatedAt).toLocaleDateString()}</span>
                </div>

                {/* Summary snippet */}
                {resume.summary && (
                  <p className="text-xs text-slate-400 line-clamp-2 italic leading-relaxed">
                    "{resume.summary}"
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <div className="flex items-center space-x-2">
                  <Link
                    to={`/resume/${resume.id}`}
                    className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
                  >
                    <FileEdit className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </Link>

                  <button
                    onClick={() => handleDuplicate(resume)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                    title="Duplicate resume"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>

                <Link
                  to={`/analyze/${resume.id}`}
                  className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-semibold transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>ATS Report</span>
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
