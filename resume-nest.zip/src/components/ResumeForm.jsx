import React, { useState } from 'react';
import ResumeSection from './ResumeSection.jsx';
import {
  User,
  GraduationCap,
  Briefcase,
  Wrench,
  FolderGit2,
  Award,
  FileText,
  Trash2,
  Sparkles,
  Save,
  Check,
} from 'lucide-react';

const POPULAR_ROLES = [
  'Software Engineer',
  'Frontend Developer',
  'Backend Developer',
  'Full Stack Engineer',
  'Machine Learning Engineer',
  'Data Scientist',
  'DevOps / Cloud Engineer',
  'Mobile App Developer (iOS/Android)',
  'Cybersecurity Analyst',
  'Product Manager (Technical)',
];

export default function ResumeForm({
  initialData = {},
  onSave,
  isSaving = false,
  onImproveSection,
  onPreFillSample,
}) {
  const [formData, setFormData] = useState({
    title: initialData.title || 'Software Engineering Resume',
    targetRole: initialData.targetRole || 'Software Engineer',
    personalInfo: {
      fullName: initialData.personalInfo?.fullName || '',
      email: initialData.personalInfo?.email || '',
      phone: initialData.personalInfo?.phone || '',
      location: initialData.personalInfo?.location || '',
      linkedin: initialData.personalInfo?.linkedin || '',
      github: initialData.personalInfo?.github || '',
      portfolio: initialData.personalInfo?.portfolio || '',
    },
    summary: initialData.summary || '',
    education: initialData.education || [
      {
        institution: '',
        degree: 'Bachelor of Science in Computer Science',
        graduationYear: '2026',
        gpa: '3.8',
        coursework: 'Data Structures, Algorithms, Operating Systems, Database Systems, Computer Networks',
      },
    ],
    skills: initialData.skills || {
      languages: 'Python, TypeScript, JavaScript, Java, C++',
      frameworks: 'React, Node.js, Express, Tailwind CSS, Next.js',
      developerTools: 'Git, Docker, Linux, PostgreSQL, MongoDB, Vite',
      coreConcepts: 'REST APIs, Data Structures, OOP, Microservices, CI/CD',
    },
    experience: initialData.experience || [
      {
        role: 'Software Engineering Intern',
        company: 'Tech Innovations Lab',
        location: 'San Francisco, CA',
        period: 'Jun 2025 - Aug 2025',
        bullets: [
          'Engineered real-time REST API microservices using Node.js and Express, reducing payload latency by 32%.',
          'Developed responsive React dashboard components for 10,000+ active university campus users.',
          'Automated Docker build pipelines and GitHub Actions workflows, shortening deployment cycle from 45 to 8 minutes.',
        ],
      },
    ],
    projects: initialData.projects || [
      {
        title: 'Distributed File Storage Engine',
        technologies: 'Go, Docker, gRPC, Raft Consensus',
        link: 'https://github.com/student/distributed-storage',
        description:
          'Built a distributed, fault-tolerant key-value storage system implementing the Raft consensus algorithm. Handled concurrent reads/writes across 5 nodes with zero data loss during simulated partitioned failure.',
      },
      {
        title: 'AI Resume Keyword Matcher',
        technologies: 'React, Node.js, Python, PostgreSQL',
        link: 'https://github.com/student/resume-matcher',
        description:
          'Designed a web application parsing student resume text against tech job descriptions, highlighting keyword disparities and boosting recruiter interview match rate.',
      },
    ],
    certifications: initialData.certifications || [
      'Google Cloud Certified Associate Cloud Engineer (2025)',
      '1st Place - University Hackathon (Best Scalable Architecture)',
    ],
  });

  const [polishingSection, setPolishingSection] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handlePersonalInfoChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      personalInfo: { ...prev.personalInfo, [field]: value },
    }));
  };

  const handleSkillsChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      skills: { ...prev.skills, [field]: value },
    }));
  };

  // Education helpers
  const addEducation = () => {
    setFormData((prev) => ({
      ...prev,
      education: [
        ...prev.education,
        { institution: '', degree: '', graduationYear: '', gpa: '', coursework: '' },
      ],
    }));
  };

  const updateEducation = (index, field, value) => {
    setFormData((prev) => {
      const updated = [...prev.education];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, education: updated };
    });
  };

  const removeEducation = (index) => {
    setFormData((prev) => ({
      ...prev,
      education: prev.education.filter((_, i) => i !== index),
    }));
  };

  // Experience helpers
  const addExperience = () => {
    setFormData((prev) => ({
      ...prev,
      experience: [
        ...prev.experience,
        { role: '', company: '', location: '', period: '', bullets: [''] },
      ],
    }));
  };

  const updateExperience = (index, field, value) => {
    setFormData((prev) => {
      const updated = [...prev.experience];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, experience: updated };
    });
  };

  const updateBullet = (expIndex, bulletIndex, value) => {
    setFormData((prev) => {
      const updated = [...prev.experience];
      const bullets = [...updated[expIndex].bullets];
      bullets[bulletIndex] = value;
      updated[expIndex] = { ...updated[expIndex], bullets };
      return { ...prev, experience: updated };
    });
  };

  const addBullet = (expIndex) => {
    setFormData((prev) => {
      const updated = [...prev.experience];
      updated[expIndex] = {
        ...updated[expIndex],
        bullets: [...updated[expIndex].bullets, ''],
      };
      return { ...prev, experience: updated };
    });
  };

  const removeBullet = (expIndex, bulletIndex) => {
    setFormData((prev) => {
      const updated = [...prev.experience];
      updated[expIndex] = {
        ...updated[expIndex],
        bullets: updated[expIndex].bullets.filter((_, i) => i !== bulletIndex),
      };
      return { ...prev, experience: updated };
    });
  };

  const removeExperience = (index) => {
    setFormData((prev) => ({
      ...prev,
      experience: prev.experience.filter((_, i) => i !== index),
    }));
  };

  // Project helpers
  const addProject = () => {
    setFormData((prev) => ({
      ...prev,
      projects: [
        ...prev.projects,
        { title: '', technologies: '', link: '', description: '' },
      ],
    }));
  };

  const updateProject = (index, field, value) => {
    setFormData((prev) => {
      const updated = [...prev.projects];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, projects: updated };
    });
  };

  const removeProject = (index) => {
    setFormData((prev) => ({
      ...prev,
      projects: prev.projects.filter((_, i) => i !== index),
    }));
  };

  // Submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (onSave) {
      await onSave(formData);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }
  };

  // Trigger AI Polish for a section
  const triggerPolish = async (sectionName, contentToPolish, applyCallback) => {
    if (!onImproveSection) return;
    setPolishingSection(sectionName);
    try {
      const result = await onImproveSection({
        section: sectionName,
        content: contentToPolish,
        targetRole: formData.targetRole,
      });
      if (result?.improvedContent) {
        applyCallback(result.improvedContent);
      }
    } catch (err) {
      console.error('Section polish error:', err);
    } finally {
      setPolishingSection(null);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Top Header Card: Title, Target Role & Actions */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Resume Document Name
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
              placeholder="e.g. Software Engineer - Summer 2026"
              required
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Target Career Role (Used for Gemini ATS Scoring)
            </label>
            <select
              value={formData.targetRole}
              onChange={(e) => setFormData({ ...formData, targetRole: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
            >
              {POPULAR_ROLES.map((role) => (
                <option key={role} value={role}>
                  {role}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center space-x-2 pt-2 md:pt-0">
          {onPreFillSample && (
            <button
              type="button"
              onClick={() => onPreFillSample(setFormData)}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-colors"
            >
              Pre-fill Sample Data
            </button>
          )}

          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center space-x-2 px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold shadow-lg shadow-indigo-600/30 transition-all active:scale-95 disabled:opacity-50"
          >
            {saveSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Saved!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saving...' : 'Save Resume'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 1. Personal Information */}
      <ResumeSection title="Personal Information & Header" icon={User} badge="5% ATS Weight">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <div>
            <label className="text-xs text-slate-400 block mb-1">Full Legal Name *</label>
            <input
              type="text"
              value={formData.personalInfo.fullName}
              onChange={(e) => handlePersonalInfoChange('fullName', e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. Alex Chen"
              required
            />
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1">Campus / Contact Email *</label>
            <input
              type="email"
              value={formData.personalInfo.email}
              onChange={(e) => handlePersonalInfoChange('email', e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. achen@stanford.edu"
              required
            />
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1">Phone Number</label>
            <input
              type="tel"
              value={formData.personalInfo.phone}
              onChange={(e) => handlePersonalInfoChange('phone', e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. (650) 555-0199"
            />
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1">Location (City, State)</label>
            <input
              type="text"
              value={formData.personalInfo.location}
              onChange={(e) => handlePersonalInfoChange('location', e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. Stanford, CA"
            />
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1">LinkedIn URL</label>
            <input
              type="text"
              value={formData.personalInfo.linkedin}
              onChange={(e) => handlePersonalInfoChange('linkedin', e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. linkedin.com/in/alexchen"
            />
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1">GitHub / Portfolio URL</label>
            <input
              type="text"
              value={formData.personalInfo.github}
              onChange={(e) => handlePersonalInfoChange('github', e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. github.com/alexchen"
            />
          </div>
        </div>
      </ResumeSection>

      {/* 2. Professional / Student Summary */}
      <ResumeSection
        title="Professional Summary"
        icon={FileText}
        badge="10% ATS Weight"
        onAIPolish={() =>
          triggerPolish('summary', formData.summary, (improved) =>
            setFormData((prev) => ({ ...prev, summary: improved }))
          )
        }
        isPolishing={polishingSection === 'summary'}
      >
        <p className="text-xs text-slate-400 mb-2">
          Concise 2-3 sentence overview highlighting your academic specialization, technical strengths, and target impact.
        </p>
        <textarea
          rows={3}
          value={formData.summary}
          onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
          className="w-full p-3 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500 leading-relaxed font-sans"
          placeholder="e.g. Computer Science junior at Stanford University with hands-on experience in distributed systems and cloud infrastructure. Passionate about designing resilient full-stack architectures and low-latency APIs."
        />
      </ResumeSection>

      {/* 3. Education */}
      <ResumeSection
        title="Education & Degree"
        icon={GraduationCap}
        badge="10% ATS Weight"
        onAdd={addEducation}
        addLabel="Add University / Degree"
      >
        <div className="space-y-4">
          {formData.education.map((edu, index) => (
            <div key={index} className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 relative space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-indigo-400">Education #{index + 1}</span>
                {formData.education.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeEducation(index)}
                    className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                <div className="sm:col-span-2">
                  <label className="text-[11px] text-slate-400 block mb-1">University / College Name *</label>
                  <input
                    type="text"
                    value={edu.institution}
                    onChange={(e) => updateEducation(index, 'institution', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. Stanford University"
                    required
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="text-[11px] text-slate-400 block mb-1">Degree & Major *</label>
                  <input
                    type="text"
                    value={edu.degree}
                    onChange={(e) => updateEducation(index, 'degree', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. B.S. in Computer Science"
                    required
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Graduation Year</label>
                  <input
                    type="text"
                    value={edu.graduationYear}
                    onChange={(e) => updateEducation(index, 'graduationYear', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. 2026"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">GPA (Optional)</label>
                  <input
                    type="text"
                    value={edu.gpa}
                    onChange={(e) => updateEducation(index, 'gpa', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. 3.8 / 4.0"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="text-[11px] text-slate-400 block mb-1">Relevant Coursework</label>
                  <input
                    type="text"
                    value={edu.coursework}
                    onChange={(e) => updateEducation(index, 'coursework', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. Data Structures, Algorithms, Distributed Systems"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </ResumeSection>

      {/* 4. Technical & Domain Skills */}
      <ResumeSection title="Technical & Domain Skills" icon={Wrench} badge="15% ATS Weight">
        <p className="text-xs text-slate-400 mb-3">
          Categorized skills parse much better in ATS systems. Comma-separated.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-slate-300 block mb-1 font-medium">Programming Languages</label>
            <input
              type="text"
              value={formData.skills.languages}
              onChange={(e) => handleSkillsChange('languages', e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. Python, TypeScript, Java, C++, Go, SQL"
            />
          </div>

          <div>
            <label className="text-xs text-slate-300 block mb-1 font-medium">Frameworks & Libraries</label>
            <input
              type="text"
              value={formData.skills.frameworks}
              onChange={(e) => handleSkillsChange('frameworks', e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. React, Node.js, Express, Next.js, Django, Tailwind CSS"
            />
          </div>

          <div>
            <label className="text-xs text-slate-300 block mb-1 font-medium">Developer Tools & Cloud</label>
            <input
              type="text"
              value={formData.skills.developerTools}
              onChange={(e) => handleSkillsChange('developerTools', e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. Git, Docker, Linux, AWS, GCP, PostgreSQL, MongoDB"
            />
          </div>

          <div>
            <label className="text-xs text-slate-300 block mb-1 font-medium">Core Concepts & Methodologies</label>
            <input
              type="text"
              value={formData.skills.coreConcepts}
              onChange={(e) => handleSkillsChange('coreConcepts', e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. REST APIs, Microservices, CI/CD, Agile, Object-Oriented Design"
            />
          </div>
        </div>
      </ResumeSection>

      {/* 5. Experience & Internships */}
      <ResumeSection
        title="Work & Internship Experience"
        icon={Briefcase}
        badge="15% ATS Weight"
        onAdd={addExperience}
        addLabel="Add Experience"
      >
        <div className="space-y-6">
          {formData.experience.map((exp, expIdx) => (
            <div key={expIdx} className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
                <span className="text-xs font-bold text-indigo-400">Position #{expIdx + 1}</span>
                {formData.experience.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeExperience(expIdx)}
                    className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Job Title / Role *</label>
                  <input
                    type="text"
                    value={exp.role}
                    onChange={(e) => updateExperience(expIdx, 'role', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. Software Engineering Intern"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Company / Organization *</label>
                  <input
                    type="text"
                    value={exp.company}
                    onChange={(e) => updateExperience(expIdx, 'company', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. Meta / Google / Campus Lab"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Location</label>
                  <input
                    type="text"
                    value={exp.location}
                    onChange={(e) => updateExperience(expIdx, 'location', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. New York, NY / Remote"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Dates / Period</label>
                  <input
                    type="text"
                    value={exp.period}
                    onChange={(e) => updateExperience(expIdx, 'period', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. Jun 2025 - Aug 2025"
                  />
                </div>
              </div>

              {/* Bullet Points */}
              <div className="pt-2">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold text-slate-300">
                    Bullet Points (Use action verbs & quantifiable metrics)
                  </span>
                  <button
                    type="button"
                    onClick={() => addBullet(expIdx)}
                    className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium"
                  >
                    + Add Bullet
                  </button>
                </div>

                <div className="space-y-2">
                  {exp.bullets.map((bullet, bIdx) => (
                    <div key={bIdx} className="flex items-start space-x-2">
                      <span className="text-slate-500 text-xs mt-2.5">•</span>
                      <textarea
                        rows={2}
                        value={bullet}
                        onChange={(e) => updateBullet(expIdx, bIdx, e.target.value)}
                        className="flex-1 p-2 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                        placeholder="e.g. Architected microservices with Express reducing response latency by 25%."
                      />
                      <div className="flex flex-col space-y-1 mt-1">
                        {onImproveSection && bullet.trim().length > 10 && (
                          <button
                            type="button"
                            onClick={() =>
                              triggerPolish('bullet', bullet, (improved) =>
                                updateBullet(expIdx, bIdx, improved)
                              )
                            }
                            className="p-1 rounded bg-amber-400/10 text-amber-400 hover:bg-amber-400/20"
                            title="AI optimize bullet point"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {exp.bullets.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeBullet(expIdx, bIdx)}
                            className="p-1 text-slate-500 hover:text-rose-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </ResumeSection>

      {/* 6. Academic & Personal Projects */}
      <ResumeSection
        title="Academic & Personal Projects"
        icon={FolderGit2}
        badge="15% ATS Weight"
        onAdd={addProject}
        addLabel="Add Project"
      >
        <div className="space-y-4">
          {formData.projects.map((proj, pIdx) => (
            <div key={pIdx} className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-indigo-400">Project #{pIdx + 1}</span>
                {formData.projects.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeProject(pIdx)}
                    className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Project Name *</label>
                  <input
                    type="text"
                    value={proj.title}
                    onChange={(e) => updateProject(pIdx, 'title', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. Distributed Consensus Engine"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Technologies Used *</label>
                  <input
                    type="text"
                    value={proj.technologies}
                    onChange={(e) => updateProject(pIdx, 'technologies', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. Go, Docker, Raft, gRPC"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Live Demo or GitHub URL</label>
                  <input
                    type="text"
                    value={proj.link}
                    onChange={(e) => updateProject(pIdx, 'link', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. github.com/user/project"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Description & Impact</label>
                <textarea
                  rows={2}
                  value={proj.description}
                  onChange={(e) => updateProject(pIdx, 'description', e.target.value)}
                  className="w-full p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                  placeholder="Detail the technical complexity, architecture decisions, and measurable outcomes."
                />
              </div>
            </div>
          ))}
        </div>
      </ResumeSection>

      {/* 7. Certifications & Honors */}
      <ResumeSection title="Certifications, Hackathons & Honors" icon={Award} badge="5% ATS Weight">
        <p className="text-xs text-slate-400 mb-2">
          One per line. Include accredited certifications, hackathon rankings, and campus leadership awards.
        </p>
        <textarea
          rows={3}
          value={formData.certifications.join('\n')}
          onChange={(e) =>
            setFormData({
              ...formData,
              certifications: e.target.value.split('\n').filter((l) => l.trim().length > 0),
            })
          }
          className="w-full p-3 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500 font-sans"
          placeholder="Google Cloud Certified Associate Cloud Engineer&#10;1st Place - University AI Hackathon (2025)"
        />
      </ResumeSection>

      {/* Bottom Save Bar */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
        <p className="text-xs text-slate-400">
          Save your changes before running Gemini ATS analysis.
        </p>
        <button
          type="submit"
          disabled={isSaving}
          className="flex items-center space-x-2 px-6 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold shadow-lg shadow-indigo-600/30 transition-all active:scale-95 disabled:opacity-50"
        >
          {saveSuccess ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span>Saved Successfully</span>
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Saving...' : 'Save Resume'}</span>
            </>
          )}
        </button>
      </div>
    </form>
  );
}
