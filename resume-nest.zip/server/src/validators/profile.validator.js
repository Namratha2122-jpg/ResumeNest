/**
 * Profile Input Validator
 */
export function validateProfileInput(data) {
  if (!data || typeof data !== 'object') {
    const error = new Error('Please provide valid profile information.');
    error.status = 400;
    throw error;
  }

  return true;
}
