/**
 * ATS Score Engine
 * The frontend must NOT calculate or fabricate the final ATS score.
 * Scoring weights are strictly enforced constants in this backend utility.
 */

export const ATS_WEIGHTS = Object.freeze({
  contact: 0.05,       // 5%
  summary: 0.10,       // 10%
  education: 0.10,     // 10%
  skills: 0.15,        // 15%
  experience: 0.15,    // 15%
  projects: 0.15,      // 15%
  certifications: 0.05,// 5%
  keywords: 0.10,      // 10%
  formatting: 0.05,    // 5%
  roleRelevance: 0.10, // 10%
});

// Human labels and descriptions for each weighted category
export const SECTION_METADATA = Object.freeze({
  contact: {
    label: 'Contact & Header',
    weightPct: 5,
    description: 'Accurate email, phone, location, LinkedIn/GitHub links without headers/footers parse traps.',
  },
  summary: {
    label: 'Professional Summary',
    weightPct: 10,
    description: 'High-impact value proposition, target career alignment, and academic stage clarity.',
  },
  education: {
    label: 'Education & Degree',
    weightPct: 10,
    description: 'University name, degree, graduation year, major, coursework, and academic honors.',
  },
  skills: {
    label: 'Technical & Domain Skills',
    weightPct: 15,
    description: 'Categorized technical languages, tools, frameworks, and role-specific competencies.',
  },
  experience: {
    label: 'Work & Internship Experience',
    weightPct: 15,
    description: 'Action verbs, quantifiable impact (XYZ formula), responsibilities, and outcomes.',
  },
  projects: {
    label: 'Academic & Personal Projects',
    weightPct: 15,
    description: 'Independent engineering or research projects demonstrating applied practical knowledge.',
  },
  certifications: {
    label: 'Certifications & Training',
    weightPct: 5,
    description: 'Recognized industry certifications, hackathons, and accredited coursework.',
  },
  keywords: {
    label: 'ATS Keyword Match',
    weightPct: 10,
    description: 'Presence of standard industry terminology expected by recruitment screening bots.',
  },
  formatting: {
    label: 'ATS Parseability & Layout',
    weightPct: 5,
    description: 'Clean single-column standard structure, standard section headers, no complex nested tables.',
  },
  roleRelevance: {
    label: 'Target Role Alignment',
    weightPct: 10,
    description: 'Relevance of achievements, projects, and skills to the requested target job profile.',
  },
});

/**
 * Calculates the authoritative ATS Readiness Score based on validated section scores.
 * @param {Record<string, number>} sectionScores - Object containing scores (0-100) for each key
 * @returns {{ atsScore: number, sectionScores: Record<string, number>, tier: string, summary: string }}
 */
export function calculateATSScore(rawSectionScores = {}) {
  let weightedTotal = 0;
  const validatedScores = {};

  for (const [key, weight] of Object.entries(ATS_WEIGHTS)) {
    // Clamp score between 0 and 100
    const raw = rawSectionScores[key];
    const score = typeof raw === 'number' && !isNaN(raw) ? Math.min(100, Math.max(0, Math.round(raw))) : 50;
    validatedScores[key] = score;
    weightedTotal += score * weight;
  }

  const finalATSScore = Math.min(100, Math.max(0, Math.round(weightedTotal)));

  let tier = 'Needs Improvement';
  let statusBadge = 'High Rejection Risk';
  let summary = 'Significant gaps detected. Follow AI recommendations to pass employer ATS filters.';

  if (finalATSScore >= 85) {
    tier = 'Excellent';
    statusBadge = 'ATS Ready (Top 10%)';
    summary = 'Superb resume structure and keyword density. Optimized for automated recruitment parsers.';
  } else if (finalATSScore >= 72) {
    tier = 'Good';
    statusBadge = 'Competitive (Passing)';
    summary = 'Strong foundation with minor improvements needed in quantifiable metrics and keyword alignment.';
  } else if (finalATSScore >= 60) {
    tier = 'Moderate';
    statusBadge = 'Borderline';
    summary = 'Partial ATS compliance. Lacking several key skills and metrics required for high-volume screening.';
  }

  return {
    atsScore: finalATSScore,
    sectionScores: validatedScores,
    tier,
    statusBadge,
    summary,
  };
}
