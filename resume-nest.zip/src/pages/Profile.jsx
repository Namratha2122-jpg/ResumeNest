import React, { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth.jsx';
import api from '../services/api.js';
import LoadingState from '../components/LoadingState.jsx';
import {
  User,
  GraduationCap,
  ShieldCheck,
  Save,
  Check,
  Mail,
  School,
  Briefcase,
  Lock,
} from 'lucide-react';

export default function Profile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadProfile() {
      try {
        const res = await api.get('/profile');
        setProfile(res.profile);
      } catch (err) {
        setError(err.message || 'Failed to load profile');
      } finally {
        setLoading(false);
      }
    }
    loadProfile();
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    try {
      const res = await api.put('/profile', profile);
      setProfile(res.profile);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      setError(err.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <LoadingState message="Loading your student profile..." />;
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800">
        <h1 className="text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
          <User className="w-6 h-6 text-indigo-400" />
          <span>Student Profile</span>
        </h1>
        <p className="text-xs text-slate-400">
          Manage your verified campus student credentials and career preferences.
        </p>
      </div>

      {/* Verified Status Banner */}
      <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0" />
          <div>
            <p className="text-xs font-bold text-emerald-300">
              Verified Campus Account: {user?.collegeName || profile?.college}
            </p>
            <p className="text-[11px] text-emerald-400/80 font-mono">
              Authenticated Domain: @{user?.domain || profile?.domain}
            </p>
          </div>
        </div>
        <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30">
          Active
        </span>
      </div>

      {/* Profile Form */}
      <form onSubmit={handleSave} className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Full Name
            </label>
            <input
              type="text"
              value={profile?.name || ''}
              onChange={(e) => setProfile({ ...profile, name: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              required
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1 flex items-center space-x-1">
              <span>Campus Email</span>
              <Lock className="w-3 h-3 text-slate-500" title="Email is locked to token UID" />
            </label>
            <input
              type="email"
              value={profile?.email || user?.email || ''}
              disabled
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-400 text-xs cursor-not-allowed font-mono"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              University / College
            </label>
            <input
              type="text"
              value={profile?.college || user?.collegeName || ''}
              onChange={(e) => setProfile({ ...profile, college: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Degree
            </label>
            <input
              type="text"
              value={profile?.degree || 'Bachelor of Science'}
              onChange={(e) => setProfile({ ...profile, degree: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Major / Specialization
            </label>
            <input
              type="text"
              value={profile?.major || 'Computer Science'}
              onChange={(e) => setProfile({ ...profile, major: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Expected Graduation Year
            </label>
            <input
              type="text"
              value={profile?.graduationYear || '2026'}
              onChange={(e) => setProfile({ ...profile, graduationYear: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Primary Target Career Role
            </label>
            <input
              type="text"
              value={profile?.targetRole || 'Software Engineer'}
              onChange={(e) => setProfile({ ...profile, targetRole: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
              placeholder="e.g. Software Engineer, Machine Learning Engineer"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Bio / Career Objective
            </label>
            <textarea
              rows={3}
              value={profile?.bio || ''}
              onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
              className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500 leading-relaxed font-sans"
              placeholder="Brief summary of your academic stage and technical aspirations."
            />
          </div>
        </div>

        {error && (
          <p className="text-xs text-rose-400">{error}</p>
        )}

        <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            Authenticated UID: {user?.uid || profile?.userId}
          </span>

          <button
            type="submit"
            disabled={saving}
            className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition-all active:scale-95 disabled:opacity-50"
          >
            {savedSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Profile Saved!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving...' : 'Save Profile'}</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
