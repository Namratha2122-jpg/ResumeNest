/**
 * Analysis Input Validator
 */
export function validateSectionImprovementInput(data) {
  if (!data || typeof data !== 'object') {
    const error = new Error('Please provide valid section data to improve.');
    error.status = 400;
    throw error;
  }

  if (!data.content || typeof data.content !== 'string' || data.content.trim().length === 0) {
    const error = new Error('Please provide valid resume text to improve.');
    error.status = 400;
    throw error;
  }

  return true;
}
