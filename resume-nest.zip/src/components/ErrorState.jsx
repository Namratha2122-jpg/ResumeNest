import React from 'react';
import { AlertTriangle, RefreshCw, ArrowLeft, ShieldAlert } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function ErrorState({
  title = 'Something went wrong',
  message = 'An unexpected error occurred while processing your request.',
  onRetry = null,
  status = null,
}) {
  const navigate = useNavigate();

  const isAccessDenied = status === 403 || message?.includes('approved college email');

  return (
    <div className="flex flex-col items-center justify-center min-h-[320px] p-8 text-center bg-slate-900/60 rounded-2xl border border-rose-500/20 shadow-xl max-w-lg mx-auto">
      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 ${
        isAccessDenied ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
      }`}>
        {isAccessDenied ? <ShieldAlert className="w-7 h-7" /> : <AlertTriangle className="w-7 h-7" />}
      </div>

      <h3 className="text-base font-bold text-white mb-2">{title}</h3>
      <p className="text-xs text-slate-300 mb-6 leading-relaxed max-w-sm">{message}</p>

      <div className="flex items-center space-x-3">
        {onRetry && (
          <button
            onClick={onRetry}
            className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition-all"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Try Again</span>
          </button>
        )}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-all"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Go Back</span>
        </button>
      </div>
    </div>
  );
}
