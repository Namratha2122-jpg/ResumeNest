import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Sparkles, Plus } from 'lucide-react';

export default function ResumeSection({
  title,
  icon: Icon,
  badge = null,
  children,
  onAdd = null,
  addLabel = 'Add Item',
  defaultExpanded = true,
  onAIPolish = null,
  isPolishing = false,
}) {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);

  return (
    <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden shadow-sm transition-all">
      <div className="flex items-center justify-between p-4 bg-slate-900/90 border-b border-slate-800/60">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-lg bg-indigo-600/10 text-indigo-400 border border-indigo-500/20">
            <Icon className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <span>{title}</span>
              {badge && (
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                  {badge}
                </span>
              )}
            </h3>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {onAIPolish && (
            <button
              type="button"
              onClick={onAIPolish}
              disabled={isPolishing}
              className="flex items-center space-x-1.5 px-2.5 py-1 rounded-md bg-amber-400/10 hover:bg-amber-400/20 text-amber-300 text-xs font-semibold border border-amber-400/20 transition-all disabled:opacity-50"
              title="Enhance this section with Gemini AI"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{isPolishing ? 'Polishing...' : 'AI Enhance'}</span>
            </button>
          )}

          {onAdd && (
            <button
              type="button"
              onClick={onAdd}
              className="flex items-center space-x-1 px-2.5 py-1 rounded-md bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 text-xs font-semibold border border-indigo-500/30 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{addLabel}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {isExpanded && <div className="p-4 sm:p-6 space-y-4">{children}</div>}
    </div>
  );
}
