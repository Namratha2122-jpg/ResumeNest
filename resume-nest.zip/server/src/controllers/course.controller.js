import * as courseService from '../services/course.service.js';

/**
 * Return all active free courses in the verified catalog
 * GET /api/courses
 */
export async function getCourses(req, res, next) {
  try {
    const { category } = req.query;
    const courses = await courseService.getActiveFreeCourses(category);
    return res.json({ courses });
  } catch (error) {
    next(error);
  }
}

/**
 * Return free courses matched against the authenticated student's skill gaps
 * GET /api/courses/recommended/:resumeId
 */
export async function getRecommendedCourses(req, res, next) {
  try {
    const { resumeId } = req.params;
    const userId = req.user.uid;

    const result = await courseService.getRecommendedCoursesForResume(resumeId, userId);
    return res.json(result);
  } catch (error) {
    next(error);
  }
}
