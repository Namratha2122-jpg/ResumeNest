import { realtimeHub } from './realtime.service.js';
import { globalCache } from './cache.service.js';

// Pre-seeded high-impact student readymade templates from top engineering colleges
const INITIAL_COMMUNITY_TEMPLATES = [
  {
    id: 'tmpl_faang_swe_2026',
    title: 'FAANG Software Engineer Intern (2026 Grad)',
    authorName: 'Alex Chen',
    authorCollege: 'Stanford University',
    authorEmail: 'alex.chen@stanford.edu',
    targetRole: 'Software Engineer',
    category: 'Big Tech & Systems',
    atsScore: 98,
    upvotes: 432,
    usesCount: 1860,
    downloadCount: 940,
    tags: ['Google SWE Intern', 'Distributed Systems', 'Workday Tested', 'ATS 98'],
    description:
      'Engineered specifically to beat Taleo and Workday ATS parsers. Includes quantifiable impact metrics, clean single-column structure, and prominent tech stack indexing.',
    previewSections: {
      headline: 'Alex Chen | B.S. Computer Science @ Stanford University',
      skills: 'C++, Go, Python, React, PostgreSQL, Docker, Kubernetes, AWS',
      sampleBullet: 'Optimized internal cache layer using Redis and Go, reducing API p99 latency by 38% under 25,000 req/sec load.',
    },
    rawTemplateData: {
      title: 'FAANG Software Engineer Intern (2026 Grad)',
      targetRole: 'Software Engineer',
      personalInfo: {
        fullName: 'Alex Chen',
        email: 'alex.chen@stanford.edu',
        phone: '(650) 555-0199',
        location: 'Stanford, CA',
        linkedin: 'linkedin.com/in/alexchen-swe',
        github: 'github.com/alexchen',
      },
      summary:
        'Computer Science Junior at Stanford University specializing in distributed systems and cloud infrastructure. Hands-on experience architecting high-throughput Go and C++ microservices handling 25k+ req/sec. Incoming SWE Intern at Google.',
      education: [
        {
          institution: 'Stanford University',
          degree: 'Bachelor of Science in Computer Science',
          graduationYear: '2026',
          gpa: '3.92 / 4.0',
          coursework: 'Distributed Systems, Operating Systems (CS140), Compilers, Database Implementation, Algorithms',
        },
      ],
      skills: {
        languages: 'C++, Go, Python, TypeScript, SQL, Bash',
        frameworks: 'React, Node.js, Express, gRPC, Protobuf',
        developerTools: 'Docker, Kubernetes, AWS (ECS, S3, RDS), Redis, Git, Linux, Prometheus',
        coreConcepts: 'Raft Consensus, Microservices, CI/CD, Cache Invalidation, Concurrency, Multithreading',
      },
      experience: [
        {
          role: 'Software Engineering Intern',
          company: 'CloudScale Technologies',
          location: 'San Francisco, CA',
          period: 'Jun 2025 - Aug 2025',
          bullets: [
            'Architected distributed caching layer in Go utilizing Redis clusters, reducing p99 API query response time from 145ms to 18ms across 25,000 requests/sec.',
            'Refactored legacy monolith into 4 modular microservices with gRPC communication, eliminating deployment downtime and improving system availability to 99.98%.',
            'Implemented automated load testing suite using k6, catching 12 critical concurrency race conditions prior to production rollout.',
          ],
        },
        {
          role: 'Undergraduate Systems Researcher',
          company: 'Stanford Platform Lab',
          location: 'Stanford, CA',
          period: 'Sep 2024 - May 2025',
          bullets: [
            'Benchmarked lock-free data structures in modern C++20 against kernel primitives, identifying 22% throughput improvements under high thread contention.',
            'Collaborated with PhD candidates on distributed checkpointing algorithms across 64-node cluster.',
          ],
        },
      ],
      projects: [
        {
          title: 'Distributed Raft Key-Value Database',
          technologies: 'Go, gRPC, Protobuf, Docker',
          link: 'https://github.com/alexchen/raft-kv',
          description:
            'Engineered a fault-tolerant distributed key-value store with leader election, log replication, and automated membership changes. Passed Jepsen-style network partition simulations with zero data inconsistency.',
        },
        {
          title: 'High-Concurrency HTTP/2 Reverse Proxy',
          technologies: 'C++20, epoll, Linux Sockets',
          link: 'https://github.com/alexchen/cpp-proxy',
          description:
            'Built an asynchronous reverse proxy using Linux epoll event notification, sustaining 60,000 concurrent persistent connections with sub-millisecond memory overhead.',
        },
      ],
      certifications: [
        'AWS Certified Solutions Architect – Associate (2025)',
        '1st Place – Stanford TreeHacks Systems Track (2024)',
      ],
    },
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    isVerified: true,
  },
  {
    id: 'tmpl_ai_ml_research',
    title: 'AI/ML & LLM Engineer Resume (Campus to Unicorn)',
    authorName: 'Priya Sharma',
    authorCollege: 'MIT (Massachusetts Institute of Technology)',
    authorEmail: 'priya.s@mit.edu',
    targetRole: 'AI/ML Engineer',
    category: 'Artificial Intelligence',
    atsScore: 97,
    upvotes: 388,
    usesCount: 1430,
    downloadCount: 820,
    tags: ['PyTorch', 'Hugging Face', 'RAG Pipelines', 'Quantization'],
    description:
      'Targeted for AI researcher and machine learning engineer roles. Highlights academic publication formatting, benchmark performance, and fine-tuning pipelines.',
    previewSections: {
      headline: 'Priya Sharma | M.S. EECS @ MIT',
      skills: 'Python, PyTorch, CUDA, vLLM, LangChain, Transformers, Triton',
      sampleBullet: 'Trained and evaluated 7B parameter reasoning model on code synthesis, achieving 18% improvement on HumanEval benchmark.',
    },
    rawTemplateData: {
      title: 'AI/ML & LLM Engineer Resume',
      targetRole: 'AI/ML Engineer',
      personalInfo: {
        fullName: 'Priya Sharma',
        email: 'priya.s@mit.edu',
        phone: '(617) 555-0142',
        location: 'Cambridge, MA',
        linkedin: 'linkedin.com/in/priyasharma-ai',
        github: 'github.com/priyasharma',
      },
      summary:
        'MIT EECS researcher with 3+ years experience developing deep learning architectures, LLM fine-tuning pipelines, and inference optimization engines. Co-authored NeurIPS workshop paper on parameter-efficient adaptation.',
      education: [
        {
          institution: 'Massachusetts Institute of Technology (MIT)',
          degree: 'Master of Science in Electrical Engineering & Computer Science (Course 6-3)',
          graduationYear: '2026',
          gpa: '4.95 / 5.0',
          coursework: 'Deep Learning (6.S191), Inference & Algorithms (6.438), Machine Learning (6.036), Computer Vision',
        },
      ],
      skills: {
        languages: 'Python, C++, CUDA, SQL, Julia, Bash',
        frameworks: 'PyTorch, vLLM, HuggingFace Transformers, DeepSpeed, Ray Train, Triton, TensorRT-LLM',
        developerTools: 'Weights & Biases, MLflow, Docker, Kubernetes, Slurm, Linux, Git',
        coreConcepts: 'LoRA/QLoRA Fine-Tuning, KV-Cache Optimization, RAG Architectures, Model Quantization (AWQ/GPTQ)',
      },
      experience: [
        {
          role: 'Machine Learning Research Intern',
          company: 'Scale AI',
          location: 'San Francisco, CA',
          period: 'Jun 2025 - Aug 2025',
          bullets: [
            'Developed automated data curation pipeline for fine-tuning 14B reasoning models, boosting benchmark accuracy on GSM8K by 16.4%.',
            'Implemented continuous batching and PagedAttention with vLLM on 8x H100 clusters, cutting generation latency by 3.2x while reducing GPU memory fragmentation.',
            'Authored distributed evaluation harness validating hallucination rates across 50,000 synthetic clinical queries.',
          ],
        },
        {
          role: 'Graduate Research Assistant',
          company: 'MIT CSAIL Vision & Learning Lab',
          location: 'Cambridge, MA',
          period: 'Sep 2024 - Present',
          bullets: [
            'Investigated multimodal representation learning for video understanding, achieving state-of-the-art zero-shot retrieval on UCF-101.',
            'Co-authored peer-reviewed paper accepted at NeurIPS 2025 Workshop on Efficient Foundation Models.',
          ],
        },
      ],
      projects: [
        {
          title: 'Speculative Decoding Engine for Open LLMs',
          technologies: 'PyTorch, CUDA, Triton, Python',
          link: 'https://github.com/priyasharma/spec-decode',
          description:
            'Created a custom Triton kernel for speculative sampling with draft models, yielding 2.4x speedup on Llama-3-70B inference without output quality degradation.',
        },
        {
          title: 'Graph RAG for Enterprise Codebases',
          technologies: 'LangChain, Neo4j, FastAPI, FAISS',
          link: 'https://github.com/priyasharma/graph-rag',
          description:
            'Engineered an AST-guided knowledge graph retrieval pipeline parsing 500k-line repositories with 91% contextual precision.',
        },
      ],
      certifications: [
        'NVIDIA Deep Learning Institute – Fundamentals of Deep Learning (2025)',
        'MIT CSAIL Outstanding Research Fellowship (2024)',
      ],
    },
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    isVerified: true,
  },
  {
    id: 'tmpl_fullstack_startup',
    title: 'Full Stack & YC Accelerator Fellowship Template',
    authorName: 'Marcus Vance',
    authorCollege: 'Harvard University',
    authorEmail: 'm.vance@harvard.edu',
    targetRole: 'Full Stack Engineer',
    category: 'High-Growth Startups',
    atsScore: 96,
    upvotes: 315,
    usesCount: 1220,
    downloadCount: 710,
    tags: ['Next.js 15', 'TypeScript', 'Node.js', 'PostgreSQL', 'Prisma'],
    description:
      'Ultra-clean modern template showcasing 0-to-1 product velocity, architecture diagrams, user growth, and full-stack API design.',
    previewSections: {
      headline: 'Marcus Vance | Harvard College Class of 2026',
      skills: 'TypeScript, Next.js, Node.js, Tailwind CSS, GraphQL, Supabase, Tailwind',
      sampleBullet: 'Built cross-platform collaborative editor supporting 5,000 real-time WebSockets connections with sub-10ms state synchronization.',
    },
    rawTemplateData: {
      title: 'Full Stack & YC Accelerator Template',
      targetRole: 'Full Stack Engineer',
      personalInfo: {
        fullName: 'Marcus Vance',
        email: 'm.vance@harvard.edu',
        phone: '(617) 555-0188',
        location: 'Cambridge, MA',
        linkedin: 'linkedin.com/in/marcus-vance',
        github: 'github.com/marcusvance',
      },
      summary:
        'Product-minded Full Stack Engineer with extensive experience building fast, reactive web applications. Passionate about developer tooling, real-time collaboration, and scaling PostgreSQL backends from zero to 100k+ MAU.',
      education: [
        {
          institution: 'Harvard University',
          degree: 'Bachelor of Arts in Computer Science & Economics',
          graduationYear: '2026',
          gpa: '3.88 / 4.0',
          coursework: 'Systems Programming (CS61), Web Development (CS50), Software Design, Database Systems',
        },
      ],
      skills: {
        languages: 'TypeScript, JavaScript, Python, SQL, HTML5, CSS3',
        frameworks: 'Next.js 15, React 19, Node.js, Express, Tailwind CSS, Prisma, GraphQL',
        developerTools: 'PostgreSQL, Redis, Supabase, Vercel, Docker, Git, Jest, Cypress',
        coreConcepts: 'Real-Time WebSockets, Serverless Functions, Optimistic UI Updates, RESTful APIs, RBAC',
      },
      experience: [
        {
          role: 'Full Stack Engineering Intern',
          company: 'Linear App',
          location: 'San Francisco, CA',
          period: 'Jun 2025 - Aug 2025',
          bullets: [
            'Engineered real-time notification engine using WebSockets and Redis Pub/Sub, handling 1.2M daily events with <15ms end-to-end latency.',
            'Optimized client-side cache reconciliation in React, reducing initial bundle load by 42% and eliminating layout shifts.',
            'Designed keyboard shortcut command palette utilized by 60,000+ daily power users.',
          ],
        },
      ],
      projects: [
        {
          title: 'Collaborative Markdown Whiteboard',
          technologies: 'Next.js, TypeScript, Yjs, WebSockets, Tailwind',
          link: 'https://github.com/marcusvance/collab-doc',
          description:
            'Constructed a conflict-free replicated data type (CRDT) document editor supporting 50+ concurrent typists with offline synchronization.',
        },
        {
          title: 'Campus Food Delivery Logistics API',
          technologies: 'Node.js, PostgreSQL, PostGIS, Stripe API',
          link: 'https://github.com/marcusvance/campus-eats',
          description:
            'Architected geospatial delivery matching engine serving 12,000 campus orders during semester launch.',
        },
      ],
      certifications: [
        'Harvard Innovation Labs Venture Incubator Fellow (2025)',
      ],
    },
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    isVerified: true,
  },
  {
    id: 'tmpl_quant_trading',
    title: 'Quantitative Research & Low-Latency Systems',
    authorName: 'Elena Rostova',
    authorCollege: 'UC Berkeley',
    authorEmail: 'elena.r@berkeley.edu',
    targetRole: 'Quant Developer',
    category: 'Quantitative Finance',
    atsScore: 98,
    upvotes: 302,
    usesCount: 895,
    downloadCount: 580,
    tags: ['C++20', 'Linux Kernel', 'Order Book Matching', 'Low Latency'],
    description:
      'Designed for hedge fund and proprietary trading algorithmic engineering positions. Rigorous formatting for mathematics and high-frequency systems.',
    previewSections: {
      headline: 'Elena Rostova | B.S. EECS & Applied Math @ UC Berkeley',
      skills: 'Modern C++ (17/20), Python (NumPy/Pandas), Multithreading, Lock-free queues, Linux',
      sampleBullet: 'Implemented lock-free ring buffer order matching engine in C++ achieving tick-to-trade latency under 850 nanoseconds.',
    },
    rawTemplateData: {
      title: 'Quantitative Developer Resume',
      targetRole: 'Quant Developer',
      personalInfo: {
        fullName: 'Elena Rostova',
        email: 'elena.r@berkeley.edu',
        phone: '(510) 555-0131',
        location: 'Berkeley, CA',
        linkedin: 'linkedin.com/in/elena-rostova-quant',
        github: 'github.com/elenarostova',
      },
      summary:
        'UC Berkeley EECS & Applied Mathematics double major with deep focus on ultra-low-latency systems programming, statistical modeling, and kernel-bypass networking. Incoming Quantitative Trading Intern.',
      education: [
        {
          institution: 'University of California, Berkeley',
          degree: 'B.S. in Electrical Engineering & Computer Sciences + Applied Mathematics',
          graduationYear: '2026',
          gpa: '3.96 / 4.0',
          coursework: 'Operating Systems (CS162), Efficient Algorithms (CS170), Stochastic Processes, Linear Algebra',
        },
      ],
      skills: {
        languages: 'C++20, C, Python, x86-64 Assembly, SQL',
        frameworks: 'NumPy, Pandas, Boost, Google Test, PyTorch',
        developerTools: 'Linux Kernel Tuning, perf, Valgrind, CMake, GDB, Git',
        coreConcepts: 'Lock-Free Data Structures, Cache Locality, SIMD Vectorization, Zero-Copy Networking',
      },
      experience: [
        {
          role: 'Quantitative Developer Intern',
          company: 'Citadel Securities',
          location: 'Chicago, IL',
          period: 'Jun 2025 - Aug 2025',
          bullets: [
            'Engineered a deterministic L3 order book parser in C++20 processing NASDAQ ITCH 5.0 feeds with sub-microsecond latency.',
            'Optimized hot trading loops with AVX-512 SIMD instructions, reducing clock cycles per message by 34%.',
            'Backtested statistical arbitrage strategies across 5 years of tick data using distributed Python clusters.',
          ],
        },
      ],
      projects: [
        {
          title: 'Lock-Free SPSC Ring Buffer Queue',
          technologies: 'C++20, Atomics, Memory Barriers',
          link: 'https://github.com/elenarostova/spsc-queue',
          description:
            'Developed single-producer single-consumer circular queue achieving 42 million operations per second with zero allocations.',
        },
      ],
      certifications: [
        'Putnam Mathematical Competition – Top 100 Nationwide (2024)',
      ],
    },
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    isVerified: true,
  },
  {
    id: 'tmpl_data_science_bi',
    title: 'Data Science & Predictive Analytics Fellowship',
    authorName: 'Aarav Patel',
    authorCollege: 'Carnegie Mellon University',
    authorEmail: 'a.patel@cmu.edu',
    targetRole: 'Data Scientist',
    category: 'Data Science & Analytics',
    atsScore: 96,
    upvotes: 270,
    usesCount: 780,
    downloadCount: 490,
    tags: ['Scikit-Learn', 'SQL Wizard', 'A/B Testing', 'Snowflake', 'Tableau'],
    description:
      'Engineered for Data Scientist, Business Intelligence, and Product Analytics internships. Highlights experimental design, causal inference, and automated dashboards.',
    previewSections: {
      headline: 'Aarav Patel | B.S. Statistics & Machine Learning @ CMU',
      skills: 'Python, SQL, R, Pandas, Scikit-Learn, Snowflake, Tableau, dbt, Spark',
      sampleBullet: 'Formulated Bayesian multi-arm bandit pricing model increasing checkout conversion rate by 6.2%.',
    },
    rawTemplateData: {
      title: 'Data Science & Analytics Resume',
      targetRole: 'Data Scientist',
      personalInfo: {
        fullName: 'Aarav Patel',
        email: 'a.patel@cmu.edu',
        phone: '(412) 555-0155',
        location: 'Pittsburgh, PA',
        linkedin: 'linkedin.com/in/aarav-patel-data',
        github: 'github.com/aaravpatel',
      },
      summary:
        'Carnegie Mellon Statistics & Machine Learning student experienced in experimental design, causal inference, and big-data feature engineering with Spark and Snowflake.',
      education: [
        {
          institution: 'Carnegie Mellon University',
          degree: 'Bachelor of Science in Statistics and Machine Learning',
          graduationYear: '2026',
          gpa: '3.89 / 4.0',
          coursework: 'Applied Machine Learning (10-601), Modern Regression (36-401), Probability Theory, Data Engineering',
        },
      ],
      skills: {
        languages: 'Python, SQL (PostgreSQL/Snowflake), R, Bash',
        frameworks: 'Pandas, NumPy, Scikit-Learn, Statsmodels, XGBoost, PySpark',
        developerTools: 'Tableau, dbt, Snowflake, Airflow, Docker, Git',
        coreConcepts: 'A/B Testing, Causal Inference, Time Series Forecasting, Hypothesis Testing, ETL Pipelines',
      },
      experience: [
        {
          role: 'Data Science Intern',
          company: 'Uber',
          location: 'San Francisco, CA',
          period: 'Jun 2025 - Aug 2025',
          bullets: [
            'Designed quasi-experimental synthetic control study evaluating driver incentive programs across 14 metropolitan markets.',
            'Built automated customer churn forecast pipeline with XGBoost, achieving 0.88 ROC-AUC and saving an estimated $420k in annual retargeting spend.',
            'Constructed dbt transformation models deployed on Snowflake, reducing dashboard query runtimes by 55%.',
          ],
        },
      ],
      projects: [
        {
          title: 'Dynamic Surge Pricing Predictor',
          technologies: 'Python, LightGBM, Streamlit, PostgreSQL',
          link: 'https://github.com/aaravpatel/surge-pricing',
          description:
            'Trained gradient boosted decision trees on 2.4M ride records predicting pricing elasticity with 93% accuracy.',
        },
      ],
      certifications: [
        'Snowflake SnowPro Core Certified (2025)',
      ],
    },
    createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
    isVerified: true,
  },
  {
    id: 'tmpl_cloud_devops',
    title: 'Cloud Infrastructure, SRE & DevOps Engineer',
    authorName: 'Zoe Washington',
    authorCollege: 'Georgia Tech',
    authorEmail: 'zwashington@gatech.edu',
    targetRole: 'DevOps / Cloud',
    category: 'Cloud Infrastructure',
    atsScore: 97,
    upvotes: 245,
    usesCount: 650,
    downloadCount: 410,
    tags: ['Terraform', 'Kubernetes', 'AWS', 'CI/CD Pipelines', 'Prometheus'],
    description:
      'Formatted for Site Reliability Engineer (SRE), Cloud Platform, and DevOps positions. Emphasizes infrastructure-as-code, high availability, and incident mitigation.',
    previewSections: {
      headline: 'Zoe Washington | B.S. Computer Engineering @ Georgia Tech',
      skills: 'Go, Python, Terraform, Kubernetes, Docker, AWS, GitHub Actions, Helm',
      sampleBullet: 'Automated zero-downtime canary deployment across 48 Kubernetes microservices with ArgoCD.',
    },
    rawTemplateData: {
      title: 'Cloud Infrastructure & SRE Resume',
      targetRole: 'DevOps / Cloud',
      personalInfo: {
        fullName: 'Zoe Washington',
        email: 'zwashington@gatech.edu',
        phone: '(404) 555-0177',
        location: 'Atlanta, GA',
        linkedin: 'linkedin.com/in/zoewashington-cloud',
        github: 'github.com/zoewashington',
      },
      summary:
        'Georgia Tech Computer Engineering student with specialization in cloud infrastructure automation, GitOps pipelines, and Kubernetes orchestration. Proven experience maintaining 99.99% service SLOs.',
      education: [
        {
          institution: 'Georgia Institute of Technology',
          degree: 'Bachelor of Science in Computer Engineering',
          graduationYear: '2026',
          gpa: '3.84 / 4.0',
          coursework: 'Computer Networking, Systems Architecture, Linux Kernel Internals, Cloud Computing',
        },
      ],
      skills: {
        languages: 'Go, Python, Bash, YAML, HCL (Terraform)',
        frameworks: 'Kubernetes, Helm, ArgoCD, Docker, Prometheus, Grafana',
        developerTools: 'AWS (EKS, VPC, IAM, Route53), Terraform, GitHub Actions, Linux',
        coreConcepts: 'Infrastructure as Code (IaC), GitOps, Zero-Downtime Deployments, Chaos Engineering, SLO/SLA',
      },
      experience: [
        {
          role: 'Site Reliability Engineering Intern',
          company: 'Cloudflare',
          location: 'Austin, TX',
          period: 'Jun 2025 - Aug 2025',
          bullets: [
            'Prototyped automated traffic rerouting daemon in Go utilizing eBPF, mitigating distributed denial-of-service spikes in under 4 seconds.',
            'Codified entire staging infrastructure across 3 AWS regions using Terraform modules, reducing new cluster spin-up time from 3 days to 14 minutes.',
            'Built Grafana alerting dashboard tracking p99 request latencies, reducing mean time to detect (MTTD) by 60%.',
          ],
        },
      ],
      projects: [
        {
          title: 'Automated GitOps Multi-Cluster Sync',
          technologies: 'Go, Kubernetes Client-Go, Helm, Docker',
          link: 'https://github.com/zoewashington/gitops-sync',
          description:
            'Created lightweight Kubernetes operator reconciling configuration drift across multiple geographic clusters.',
        },
      ],
      certifications: [
        'Certified Kubernetes Administrator (CKA) – Linux Foundation (2025)',
        'AWS Certified DevOps Engineer – Professional (2025)',
      ],
    },
    createdAt: new Date(Date.now() - 86400000 * 6).toISOString(),
    isVerified: true,
  },
];

// In-memory community database collection
const communityTemplatesMap = new Map();
INITIAL_COMMUNITY_TEMPLATES.forEach((tmpl) => {
  communityTemplatesMap.set(tmpl.id, tmpl);
});

export async function getAllTemplates(filters = {}) {
  const cacheKey = `templates_${JSON.stringify(filters)}`;
  const cached = globalCache.get(cacheKey);
  if (cached) return cached;

  let list = Array.from(communityTemplatesMap.values());

  if (filters.role && filters.role !== 'all') {
    list = list.filter((t) => t.targetRole.toLowerCase().includes(filters.role.toLowerCase()));
  }

  if (filters.query) {
    const q = filters.query.toLowerCase().trim();
    list = list.filter(
      (t) =>
        t.title.toLowerCase().includes(q) ||
        t.authorCollege.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.tags.some((tag) => tag.toLowerCase().includes(q))
    );
  }

  // Sort by upvotes by default
  list.sort((a, b) => b.upvotes - a.upvotes);

  globalCache.set(cacheKey, list, 15000); // 15s cache
  return list;
}

export async function getTemplateById(id) {
  return communityTemplatesMap.get(id) || null;
}

export async function createCommunityTemplate(student, templateData) {
  const id = 'tmpl_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);

  const cleanTitle = (templateData.title || 'Untitled Community Template').trim();
  const cleanRole = (templateData.targetRole || 'Software Engineer').trim();
  const cleanCategory = (templateData.category || 'General Engineering').trim();
  const cleanDescription = (templateData.description || '').trim();

  const authorName = student.name || 'Anonymous Student';
  const authorCollege = student.collegeName || 'Verified University';
  const authorEmail = student.email || 'student@college.edu';

  // Calculate high ATS benchmark score
  const atsScore = Math.min(99, Math.max(90, parseInt(templateData.atsScore || '96', 10)));

  const newTemplate = {
    id,
    title: cleanTitle,
    authorName,
    authorCollege,
    authorEmail,
    targetRole: cleanRole,
    category: cleanCategory,
    atsScore,
    upvotes: 1,
    usesCount: 1,
    downloadCount: 1,
    tags: Array.isArray(templateData.tags)
      ? templateData.tags
      : (templateData.tags || 'Student Shared, ATS Tested')
          .split(',')
          .map((t) => t.trim())
          .filter(Boolean),
    description: cleanDescription || `Contributed by ${authorName} (${authorCollege}). Tailored for ATS optimization.`,
    previewSections: {
      headline: `${authorName} | ${authorCollege}`,
      skills: templateData.skills || 'TypeScript, React, Python, SQL, Git',
      sampleBullet: templateData.sampleBullet || 'Architected scalable services with real-time synchronization, improving processing speed by 35%.',
    },
    rawTemplateData: templateData.rawTemplateData || {
      title: cleanTitle,
      targetRole: cleanRole,
      personalInfo: {
        fullName: authorName,
        email: authorEmail,
        phone: '(555) 019-2834',
        location: authorCollege,
        linkedin: `linkedin.com/in/${authorName.toLowerCase().replace(/\s+/g, '')}`,
        github: `github.com/${authorName.toLowerCase().replace(/\s+/g, '')}`,
      },
      summary: cleanDescription || `Motivated student at ${authorCollege} targeting ${cleanRole} positions.`,
      education: [
        {
          institution: authorCollege,
          degree: 'Bachelor of Science in Engineering',
          graduationYear: '2026',
          gpa: '3.85 / 4.0',
          coursework: 'Data Structures, Computer Systems, Software Engineering',
        },
      ],
      skills: {
        languages: templateData.skills || 'Python, TypeScript, SQL',
        frameworks: 'React, Node.js, Express',
        developerTools: 'Git, Docker, Linux',
        coreConcepts: 'Data Structures, Algorithms, System Design',
      },
      experience: [
        {
          role: `${cleanRole} Intern`,
          company: 'Tech Solutions Inc.',
          location: 'San Francisco, CA',
          period: 'Jun 2025 - Aug 2025',
          bullets: [
            templateData.sampleBullet || 'Implemented scalable system optimizations improving overall response latency by 30%.',
            'Collaborated with senior software architects on code quality, testing, and production deployment.',
          ],
        },
      ],
      projects: [
        {
          title: `${cleanRole} Showcase Application`,
          technologies: templateData.skills || 'TypeScript, React, Node.js',
          link: 'https://github.com/student/showcase',
          description: 'Designed and deployed an end-to-end web application with clean architecture and real-time syncing.',
        },
      ],
      certifications: [
        'Dean’s Honor List (2024 - 2025)',
      ],
    },
    createdAt: new Date().toISOString(),
    isVerified: true,
  };

  communityTemplatesMap.set(id, newTemplate);

  // Invalidate list caches
  globalCache.clear();

  // BROADCAST TO ALL REAL-TIME SUBSCRIBERS ACROSS THE NETWORK
  realtimeHub.broadcast('templates:created', {
    template: newTemplate,
    message: `${authorName} from ${authorCollege} just uploaded a new ${cleanRole} template!`,
    timestamp: new Date().toISOString(),
  });

  return newTemplate;
}

export async function upvoteTemplate(id) {
  const tmpl = communityTemplatesMap.get(id);
  if (!tmpl) return null;

  tmpl.upvotes = (tmpl.upvotes || 0) + 1;
  communityTemplatesMap.set(id, tmpl);

  globalCache.clear();

  // Broadcast upvote in real time
  realtimeHub.broadcast('templates:upvoted', {
    id: tmpl.id,
    upvotes: tmpl.upvotes,
    title: tmpl.title,
  });

  return tmpl;
}

export async function incrementUseCount(id) {
  const tmpl = communityTemplatesMap.get(id);
  if (!tmpl) return null;

  tmpl.usesCount = (tmpl.usesCount || 0) + 1;
  communityTemplatesMap.set(id, tmpl);
  return tmpl;
}

export async function recordDownload(id) {
  const tmpl = communityTemplatesMap.get(id);
  if (!tmpl) return null;

  tmpl.downloadCount = (tmpl.downloadCount || 0) + 1;
  communityTemplatesMap.set(id, tmpl);

  // Broadcast real-time download activity
  realtimeHub.broadcast('templates:downloaded', {
    id: tmpl.id,
    downloadCount: tmpl.downloadCount,
    title: tmpl.title,
    message: `Student just downloaded "${tmpl.title}"`,
    timestamp: new Date().toISOString(),
  });

  return tmpl;
}
