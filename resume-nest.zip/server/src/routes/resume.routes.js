import express from 'express';
import { authenticate } from '../middleware/authenticate.js';
import { authorizeStudent } from '../middleware/authorizeStudent.js';
import {
  getResumes,
  createResume,
  getResumeById,
  updateResume,
  deleteResume,
} from '../controllers/resume.controller.js';

const router = express.Router();

router.use(authenticate);
router.use(authorizeStudent);

router.get('/', getResumes);
router.post('/', createResume);
router.get('/:resumeId', getResumeById);
router.put('/:resumeId', updateResume);
router.delete('/:resumeId', deleteResume);

export default router;
