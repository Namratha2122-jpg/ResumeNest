import React from 'react';
import { CheckCircle2, AlertCircle, Key, ArrowRight, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function SkillGapCard({
  detectedSkills = [],
  missingSkills = [],
  missingKeywords = [],
  resumeId = null,
}) {
  return (
    <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-2">
        <div>
          <h3 className="text-base font-bold text-white">Skill Gap & Keyword Diagnostic</h3>
          <p className="text-xs text-slate-400">
            Skills identified in your resume vs high-demand industry capabilities required for screening.
          </p>
        </div>
        {resumeId && (
          <Link
            to={`/courses?resumeId=${resumeId}`}
            className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition-all w-fit"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Bridge Gaps with Free Courses</span>
            <ArrowRight className="w-3.5 h-3.5 ml-1" />
          </Link>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Detected Skills */}
        <div className="p-4 rounded-xl bg-slate-950/60 border border-emerald-500/20">
          <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs mb-3">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
            <span>Detected Skills in Resume ({detectedSkills.length})</span>
          </div>

          {detectedSkills.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {detectedSkills.map((skill, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 text-xs font-medium"
                >
                  {skill}
                </span>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic">No recognized technical skills detected.</p>
          )}
        </div>

        {/* Missing Skills (Skill Gaps) */}
        <div className="p-4 rounded-xl bg-slate-950/60 border border-rose-500/20">
          <div className="flex items-center space-x-2 text-rose-400 font-semibold text-xs mb-3">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>Missing High-Demand Skills ({missingSkills.length})</span>
          </div>

          {missingSkills.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {missingSkills.map((skill, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-md bg-rose-500/10 text-rose-300 border border-rose-500/20 text-xs font-medium"
                >
                  + {skill}
                </span>
              ))}
            </div>
          ) : (
            <p className="text-xs text-emerald-400 font-medium">No critical skill gaps found for this role!</p>
          )}
        </div>
      </div>

      {/* Missing Keywords Box */}
      {missingKeywords.length > 0 && (
        <div className="p-4 rounded-xl bg-slate-950/40 border border-amber-500/20">
          <div className="flex items-center space-x-2 text-amber-400 font-semibold text-xs mb-2">
            <Key className="w-4 h-4 flex-shrink-0" />
            <span>Recommended ATS Keywords to Incorporate:</span>
          </div>
          <p className="text-[11px] text-slate-400 mb-3">
            Recruiter algorithms scan for these exact phrases. Include them naturally in your project descriptions and experience bullets:
          </p>
          <div className="flex flex-wrap gap-2">
            {missingKeywords.map((kw, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/20 text-xs font-mono"
              >
                {kw}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
