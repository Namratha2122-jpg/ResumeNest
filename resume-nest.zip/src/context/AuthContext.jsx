import React, { createContext, useContext, useState, useEffect } from 'react';
import authService from '../services/auth.js';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  // Synchronously initialize from localStorage so there is NO loading flash on startup
  const [user, setUser] = useState(() => authService.getCurrentUser());
  const [userType, setUserType] = useState(() => authService.getCurrentUser()?.userType || null);
  const [loading, setLoading] = useState(() => {
    // Only show loading if a token actually exists in storage and needs verification
    return typeof window !== 'undefined' && !!localStorage.getItem('resume_nest_token');
  });
  const [error, setError] = useState(null);

  // Restore authenticated session on mount / refresh
  useEffect(() => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('resume_nest_token') : null;
    if (!token) {
      setLoading(false);
      return;
    }

    let isMounted = true;

    // Timeout safety fallback: never stay in loading state longer than 2.5 seconds
    const timeoutId = setTimeout(() => {
      if (isMounted) {
        setLoading(false);
      }
    }, 2500);

    async function restoreSession() {
      try {
        const session = await authService.verifySession();
        if (isMounted) {
          if (session && session.user && session.userType) {
            setUser(session.user);
            setUserType(session.userType);
          } else {
            setUser(null);
            setUserType(null);
          }
        }
      } catch (err) {
        console.error('Session restoration failed:', err);
        if (isMounted) {
          setUser(null);
          setUserType(null);
        }
      } finally {
        if (isMounted) {
          clearTimeout(timeoutId);
          setLoading(false);
        }
      }
    }

    restoreSession();

    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, []);

  const loginStudent = async (email, name) => {
    setLoading(true);
    setError(null);
    try {
      const result = await authService.loginStudent(email, name);
      if (result.success) {
        setUser(result.user);
        setUserType('student');
        return { success: true, user: result.user, userType: 'student' };
      } else {
        setUser(null);
        setUserType(null);
        return { success: false, status: result.status, error: result.error, domain: result.domain };
      }
    } catch (err) {
      setError(err.message || 'Student login failed');
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  };

  const loginAdmin = async (email, name) => {
    setLoading(true);
    setError(null);
    try {
      const result = await authService.loginAdmin(email, name);
      if (result.success) {
        setUser(result.user);
        setUserType('admin');
        return { success: true, user: result.user, userType: 'admin' };
      } else {
        setUser(null);
        setUserType(null);
        return { success: false, status: result.status, error: result.error };
      }
    } catch (err) {
      setError(err.message || 'Admin login failed');
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    const currentType = userType;
    authService.logout();
    setUser(null);
    setUserType(null);
    setLoading(false);
    return currentType;
  };

  const value = {
    user,
    userType,
    isAuthenticated: !!user && !!userType,
    loading,
    error,
    loginStudent,
    loginAdmin,
    logout,
    setUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export default useAuth;
