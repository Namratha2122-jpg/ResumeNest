import * as db from './db.service.js';
import { runResumeAnalysis, improveResumeSection } from './analysis.service.js';
import { matchCoursesToSkillGaps } from '../utils/courseMatcher.js';

export async function getProfile(userId, fallbackInfo = {}) {
  let profile = await db.getStudentProfile(userId);
  if (!profile) {
    profile = await db.saveStudentProfile(userId, {
      uid: userId,
      email: fallbackInfo.email || '',
      name: fallbackInfo.name || fallbackInfo.email?.split('@')[0] || 'Student',
      college: fallbackInfo.collegeName || 'University',
      degree: 'Bachelor of Science',
      major: 'Computer Science',
      graduationYear: '2026',
      targetRole: 'Software Engineer',
      resumeCount: 0,
    });
  }
  return profile;
}

export async function updateProfile(userId, data) {
  const { uid: _u, email: _e, ...safeUpdates } = data;
  return await db.saveStudentProfile(userId, safeUpdates);
}

export async function getResumes(userId) {
  return await db.getStudentResumes(userId);
}

export async function createResume(data, userId) {
  return await db.createStudentResume(data, userId);
}

export async function getResume(resumeId, userId) {
  return await db.getResumeById(resumeId, userId);
}

export async function updateResume(resumeId, data, userId) {
  return await db.updateStudentResume(resumeId, data, userId);
}

export async function deleteResume(resumeId, userId) {
  return await db.deleteStudentResume(resumeId, userId);
}

export async function analyzeResume(resumeId, userId, targetRole) {
  return await runResumeAnalysis(resumeId, userId, targetRole);
}

export async function getAnalysis(resumeId, userId) {
  return await db.getAnalysisResult(resumeId, userId);
}

export async function getRecommendations(resumeId, userId) {
  const resume = await db.getResumeById(resumeId, userId);
  let analysis = await db.getAnalysisResult(resumeId, userId);
  if (!analysis) {
    analysis = await runResumeAnalysis(resumeId, userId, resume.targetRole);
  }

  const activeCourses = await db.getActiveCourses();
  const missingSkills = analysis.missingSkills || [];
  const matched = matchCoursesToSkillGaps(missingSkills, activeCourses);

  return {
    resumeId,
    targetRole: analysis.targetRole,
    missingSkills,
    recommendedCourses: matched,
  };
}

export async function improveSection(userId, payload) {
  return await improveResumeSection(userId, payload);
}
