import { verifyToken } from '../config/firebaseAdmin.js';
import { getCollegeName } from '../services/collegeDomain.service.js';

/**
 * Authentication Middleware
 * Authoritatively verifies Firebase ID token from Authorization header.
 * NEVER trusts req.body.userId.
 */
export async function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'Please sign in to continue.',
      code: 'UNAUTHORIZED_NO_TOKEN',
    });
  }

  const idToken = authHeader.split('Bearer ')[1]?.trim();

  if (!idToken) {
    return res.status(401).json({
      error: 'Please sign in to continue.',
      code: 'UNAUTHORIZED_EMPTY_TOKEN',
    });
  }

  try {
    const verified = await verifyToken(idToken);

    // Extract domain from verified email (authoritative)
    const email = verified.email || '';
    const domain = email.split('@')[1]?.toLowerCase() || '';

    // Authoritative user context attached to request
    req.user = {
      uid: verified.uid,
      email: email,
      name: verified.name || email.split('@')[0],
      picture: verified.picture || '',
      domain: domain,
      collegeName: getCollegeName(domain),
    };

    next();
  } catch (error) {
    console.error('[AuthMiddleware] Token verification failed:', error.message);
    return res.status(401).json({
      error: 'Please sign in to continue.',
      code: 'UNAUTHORIZED_INVALID_TOKEN',
      details: error.message,
    });
  }
}
