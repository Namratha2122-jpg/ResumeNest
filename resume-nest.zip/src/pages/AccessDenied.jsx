import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';
import authService from '../services/auth.js';
import {
  ShieldAlert,
  GraduationCap,
  ArrowRight,
  Shield,
  Lock,
  RefreshCw,
} from 'lucide-react';

export default function AccessDenied() {
  const { user, loginStudent } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const customReason = location.state?.reason;
  const isAdminDenial = customReason?.toLowerCase().includes('administrator');
  const rejectedDomain = location.state?.domain || user?.domain || 'personal webmail';
  const rejectedEmail = user?.email || '';

  const handleSwitchToDemo = async (email, name) => {
    const res = await loginStudent(email, name);
    if (res.success) {
      navigate('/dashboard');
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <div className="rounded-3xl bg-slate-900 border border-rose-500/30 shadow-2xl p-6 sm:p-10 space-y-8 text-center">
        {/* Shield Icon */}
        <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center mx-auto shadow-lg">
          <ShieldAlert className="w-8 h-8" />
        </div>

        {/* Rejection Title & Message */}
        <div className="space-y-3">
          <span className="px-3 py-1 rounded-full text-[11px] font-mono font-bold uppercase tracking-wider bg-rose-500/15 text-rose-400 border border-rose-500/30">
            HTTP 403 Forbidden — Authorization Gatekeeper
          </span>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Access Denied
          </h2>

          <p className="text-sm sm:text-base font-semibold text-rose-200/90 max-w-lg mx-auto leading-relaxed">
            {customReason ||
              'Resume Nest is currently available only to students using an approved college email address.'}
          </p>

          {!isAdminDenial && rejectedEmail && (
            <div className="inline-block px-3 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-400">
              Rejected Address: <span className="text-rose-400 font-bold">{rejectedEmail}</span> (Domain: @{rejectedDomain})
            </div>
          )}
        </div>

        {/* Informative Explanation */}
        <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-left text-xs text-slate-400 space-y-2 leading-relaxed">
          <div className="flex items-center space-x-2 text-slate-200 font-semibold">
            <Lock className="w-4 h-4 text-indigo-400" />
            <span>Why is this access restricted?</span>
          </div>
          <p>
            {isAdminDenial
              ? 'Administrative routes (/admin/*) require an authenticated session explicitly listed in the server-side admins collection with active status and permissions. Students and unprovisioned users cannot access the administrator control center.'
              : 'Resume Nest is provisioned exclusively for university students. The backend validates every authenticated session against active academic domains in the approvedCollegeDomains collection.'}
          </p>
        </div>

        {/* Action Options */}
        <div className="space-y-4">
          {isAdminDenial ? (
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <Link
                to="/admin/login"
                className="inline-flex items-center space-x-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition-all"
              >
                <Shield className="w-4 h-4" />
                <span>Go to Admin Login</span>
              </Link>
              <Link to="/" className="text-xs text-slate-400 hover:text-white transition-colors">
                Return to Homepage
              </Link>
            </div>
          ) : (
            <>
              <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Available Verified Campus Accounts
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left">
                {[
                  { name: 'Alex Chen', email: 'alex.chen@stanford.edu', college: 'Stanford University' },
                  { name: 'Maya Patel', email: 'mayap@mit.edu', college: 'MIT' },
                  { name: 'Jordan Lee', email: 'jordan@berkeley.edu', college: 'UC Berkeley' },
                  { name: 'Sarah Miller', email: 'smiller@harvard.edu', college: 'Harvard University' },
                ].map((account, i) => (
                  <button
                    key={i}
                    onClick={() => handleSwitchToDemo(account.email, account.name)}
                    className="p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-emerald-500/40 transition-all flex items-center justify-between group"
                  >
                    <div>
                      <p className="text-xs font-semibold text-white group-hover:text-emerald-300">
                        🎓 {account.college}
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono">{account.email}</p>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400" />
                  </button>
                ))}
              </div>

              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                <Link
                  to="/login"
                  className="inline-flex items-center space-x-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition-all"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Sign In with Different College Email</span>
                </Link>

                <Link to="/" className="text-xs text-slate-400 hover:text-white transition-colors">
                  Return to Homepage
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
