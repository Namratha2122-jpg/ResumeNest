import * as analysisService from '../services/analysis.service.js';
import { validateSectionImprovementInput } from '../validators/analysis.validator.js';

/**
 * Analyze resume with Gemini 3.8 Flash
 * POST /api/analysis/:resumeId
 */
export async function analyzeResume(req, res, next) {
  try {
    const { resumeId } = req.params;
    const { targetRole } = req.body;
    const userId = req.user.uid;

    const analysis = await analysisService.runResumeAnalysis(resumeId, userId, targetRole);

    return res.json(analysis);
  } catch (error) {
    next(error);
  }
}

/**
 * Get existing analysis result
 * GET /api/analysis/:resumeId
 */
export async function getAnalysis(req, res, next) {
  try {
    const { resumeId } = req.params;
    const userId = req.user.uid;

    const analysis = await analysisService.getAnalysisResult(resumeId, userId);
    if (!analysis) {
      return res.status(404).json({ error: 'No analysis found for this resume yet.' });
    }

    return res.json(analysis);
  } catch (error) {
    next(error);
  }
}

/**
 * Improve specific resume section using Gemini
 * POST /api/analysis/improve
 */
export async function improveSection(req, res, next) {
  try {
    validateSectionImprovementInput(req.body);
    const { resumeId, section, content, targetRole, instruction } = req.body;
    const userId = req.user.uid;

    const improvement = await analysisService.improveResumeSection(userId, {
      resumeId,
      section,
      content,
      targetRole,
      instruction,
    });

    return res.json(improvement);
  } catch (error) {
    next(error);
  }
}
