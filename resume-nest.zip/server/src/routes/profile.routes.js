import express from 'express';
import { authenticate } from '../middleware/authenticate.js';
import { authorizeStudent } from '../middleware/authorizeStudent.js';
import { getProfile, updateProfile } from '../controllers/profile.controller.js';

const router = express.Router();

router.use(authenticate);
router.use(authorizeStudent);

router.get('/', getProfile);
router.put('/', updateProfile);

export default router;
