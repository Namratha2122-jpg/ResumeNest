import * as studentService from '../services/student.service.js';
import * as db from '../services/db.service.js';
import { validateResumeInput } from '../validators/resume.validator.js';
import { validateProfileInput } from '../validators/profile.validator.js';
import { validateSectionImprovementInput } from '../validators/analysis.validator.js';

// PROFILE
export async function getProfile(req, res, next) {
  try {
    const profile = await studentService.getProfile(req.user.uid, req.user);
    return res.json({ profile });
  } catch (error) {
    next(error);
  }
}

export async function updateProfile(req, res, next) {
  try {
    validateProfileInput(req.body);
    const updated = await studentService.updateProfile(req.user.uid, req.body);
    return res.json({ profile: updated, message: 'Profile updated successfully.' });
  } catch (error) {
    next(error);
  }
}

// RESUMES
export async function getResumes(req, res, next) {
  try {
    const resumes = await studentService.getResumes(req.user.uid);
    return res.json({ resumes });
  } catch (error) {
    next(error);
  }
}

export async function createResume(req, res, next) {
  try {
    validateResumeInput(req.body);
    const resume = await studentService.createResume(req.body, req.user.uid);
    return res.status(201).json({ resume });
  } catch (error) {
    next(error);
  }
}

export async function getResumeById(req, res, next) {
  try {
    const { resumeId } = req.params;
    const resume = await studentService.getResume(resumeId, req.user.uid);
    return res.json({ resume });
  } catch (error) {
    next(error);
  }
}

export async function updateResume(req, res, next) {
  try {
    const { resumeId } = req.params;
    validateResumeInput(req.body);
    const updated = await studentService.updateResume(resumeId, req.body, req.user.uid);
    return res.json({ resume: updated });
  } catch (error) {
    next(error);
  }
}

export async function deleteResume(req, res, next) {
  try {
    const { resumeId } = req.params;
    await studentService.deleteResume(resumeId, req.user.uid);
    return res.json({ success: true, message: 'Resume deleted successfully.' });
  } catch (error) {
    next(error);
  }
}

// ANALYSIS
export async function analyzeResume(req, res, next) {
  try {
    const { resumeId } = req.params;
    const { targetRole } = req.body;
    const analysis = await studentService.analyzeResume(resumeId, req.user.uid, targetRole);
    return res.json(analysis);
  } catch (error) {
    next(error);
  }
}

export async function getAnalysis(req, res, next) {
  try {
    const { resumeId } = req.params;
    const analysis = await studentService.getAnalysis(resumeId, req.user.uid);
    if (!analysis) {
      return res.status(404).json({ error: 'No analysis found for this resume yet.' });
    }
    return res.json(analysis);
  } catch (error) {
    next(error);
  }
}

export async function improveSection(req, res, next) {
  try {
    validateSectionImprovementInput(req.body);
    const improvement = await studentService.improveSection(req.user.uid, req.body);
    return res.json(improvement);
  } catch (error) {
    next(error);
  }
}

// COURSES
export async function getCourses(req, res, next) {
  try {
    const courses = await db.getActiveCourses();
    return res.json({ courses });
  } catch (error) {
    next(error);
  }
}

export async function getRecommendations(req, res, next) {
  try {
    const { resumeId } = req.params;
    const result = await studentService.getRecommendations(resumeId, req.user.uid);
    return res.json(result);
  } catch (error) {
    next(error);
  }
}
