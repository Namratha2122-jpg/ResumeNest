import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext.jsx';
import { ThemeProvider } from './context/ThemeContext.jsx';
import ThreeDBackground from './components/ThreeDBackground.jsx';
import Navbar from './components/Navbar.jsx';
import Footer from './components/Footer.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

// Public Pages
import Landing from './pages/Landing.jsx';
import StudentLogin from './pages/StudentLogin.jsx';
import AdminLogin from './pages/AdminLogin.jsx';
import AccessDenied from './pages/AccessDenied.jsx';
import HowItWorks from './pages/HowItWorks.jsx';
import Features from './pages/Features.jsx';
import Courses from './pages/Courses.jsx';
import Templates from './pages/Templates.jsx';
import NotFound from './pages/NotFound.jsx';

// Student Pages
import Dashboard from './pages/Dashboard.jsx';
import ResumeBuilder from './pages/ResumeBuilder.jsx';
import ResumeAnalysis from './pages/ResumeAnalysis.jsx';
import MyResumes from './pages/MyResumes.jsx';
import Profile from './pages/Profile.jsx';

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard.jsx';
import AdminStudents from './pages/admin/Students.jsx';
import AdminCourses from './pages/admin/Courses.jsx';
import AdminAnalytics from './pages/admin/Analytics.jsx';
import AdminSettings from './pages/admin/Settings.jsx';
import AdminProfile from './pages/admin/AdminProfile.jsx';

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <div className="app-bg relative min-h-screen flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
            <ThreeDBackground />
            <Navbar />
            <main className="flex-1 relative z-10">
            <Routes>
              {/* ========================================== */}
              {/* PUBLIC ROUTES                              */}
              {/* ========================================== */}
              <Route path="/" element={<Landing />} />
              <Route path="/login" element={<StudentLogin />} />
              <Route path="/admin/login" element={<AdminLogin />} />
              <Route path="/access-denied" element={<AccessDenied />} />
              <Route path="/how-it-works" element={<HowItWorks />} />
              <Route path="/features" element={<Features />} />
              <Route path="/courses" element={<Courses />} />
              <Route path="/templates" element={<Templates />} />

              {/* ========================================== */}
              {/* STUDENT PROTECTED ROUTES                   */}
              {/* ========================================== */}
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute requiredRole="student">
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/resume/new"
                element={
                  <ProtectedRoute requiredRole="student">
                    <ResumeBuilder />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/resume/:resumeId"
                element={
                  <ProtectedRoute requiredRole="student">
                    <ResumeBuilder />
                  </ProtectedRoute>
                }
              />
              {/* Backward compatibility alias for /builder */}
              <Route
                path="/builder"
                element={
                  <ProtectedRoute requiredRole="student">
                    <ResumeBuilder />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my-resumes"
                element={
                  <ProtectedRoute requiredRole="student">
                    <MyResumes />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/analyze/:resumeId"
                element={
                  <ProtectedRoute requiredRole="student">
                    <ResumeAnalysis />
                  </ProtectedRoute>
                }
              />
              {/* Backward compatibility alias for /analysis/:resumeId */}
              <Route
                path="/analysis/:resumeId"
                element={
                  <ProtectedRoute requiredRole="student">
                    <ResumeAnalysis />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/profile"
                element={
                  <ProtectedRoute requiredRole="student">
                    <Profile />
                  </ProtectedRoute>
                }
              />

              {/* ========================================== */}
              {/* ADMIN PROTECTED ROUTES                     */}
              {/* ========================================== */}
              <Route path="/admin" element={<Navigate to="/admin/dashboard" replace />} />
              <Route
                path="/admin/dashboard"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <AdminDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/students"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <AdminStudents />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/courses"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <AdminCourses />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/analytics"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <AdminAnalytics />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/settings"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <AdminSettings />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/profile"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <AdminProfile />
                  </ProtectedRoute>
                }
              />

              {/* ========================================== */}
              {/* 404 & FALLBACK                             */}
              {/* ========================================== */}
              <Route path="/404" element={<NotFound />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </BrowserRouter>
    </AuthProvider>
    </ThemeProvider>
  );
}
