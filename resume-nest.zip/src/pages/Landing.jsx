import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';
import ThreeDInteractiveHero from '../components/ThreeDInteractiveHero.jsx';
import ThreeDRealityCheck from '../components/ThreeDRealityCheck.jsx';
import Mascot3DBird from '../components/Mascot3DBird.jsx';
import {
  GraduationCap,
  ShieldCheck,
  Cpu,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  BarChart3,
  Bot,
  Zap,
} from 'lucide-react';

export default function Landing() {
  const { user } = useAuth();

  return (
    <div className="space-y-16 pb-20 animate-in fade-in duration-300">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-10 sm:pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          
          {/* 3D Mascot Nestor Introduction */}
          <div className="mb-6 flex justify-center">
            <Mascot3DBird
              className="w-40 h-40 sm:w-48 sm:h-48"
              message="I eat ATS parser traps for breakfast! 🦉✨"
            />
          </div>

          <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-indigo-500/15 border border-indigo-400/30 text-indigo-300 text-xs font-semibold mb-6 shadow-inner">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Campus Gatekeeper Verified & Server-Side Gemini 3.8</span>
          </div>

          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-white tracking-tight max-w-4xl mx-auto leading-[1.12]">
            Beat the Robot Recruiters.{' '}
            <span className="bg-gradient-to-r from-amber-300 via-rose-300 via-violet-300 to-cyan-300 bg-clip-text text-transparent">
              Bridge Your Skill Gaps for Free.
            </span>
          </h1>

          <p className="mt-6 text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Stop sending resumes into the electronic trash can. Resume Nest scans your campus projects with Gemini, calculates your genuine 10-factor ATS score, and links you to 100% free courses from Harvard, MIT, and Stanford.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to={user && user.isAuthorized ? '/dashboard' : '/login'}
              className="btn-3d-gradient w-full sm:w-auto inline-flex items-center justify-center space-x-2.5 px-8 py-4 rounded-2xl text-white font-black text-sm group"
            >
              <span>{user && user.isAuthorized ? 'Open Student Dashboard' : 'Sign In with College Email'}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
            </Link>

            <Link
              to="/courses"
              className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-7 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-bold text-sm border-2 border-slate-800 hover:border-indigo-500/40 transition-all card-3d"
            >
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>Explore 100% Free Courses</span>
            </Link>
          </div>

          {/* Key Trust Signals */}
          <div className="mt-12 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Only Approved .edu & .ac.in Domains</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Server-Side Gemini 3.8 Flash (No Key Leakage)</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>0% Fluff & 0% Buzzword Traps</span>
            </div>
          </div>
        </div>

        {/* 3D Decorative Ambient Glow */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-indigo-600/15 blur-[140px] rounded-full pointer-events-none -z-10 animate-pulse-glow" />
      </section>

      {/* Interactive 3D Bullet Transformer Demo */}
      <ThreeDInteractiveHero />

      {/* Funny & Relatable 3D Reality Check Section */}
      <ThreeDRealityCheck />

      {/* 4 Pillars of Architecture in 3D Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-indigo-400">
            Engineered For Serious Results
          </span>
          <h3 className="text-2xl sm:text-3xl font-black text-white">
            Why Resume Nest Outsmarts Generic Builders
          </h3>
          <p className="text-xs sm:text-sm text-slate-400">
            Built from scratch to solve real college placement hurdles with mathematical scoring and verified courses.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="card-3d p-6 rounded-3xl bg-slate-900 border-2 border-indigo-500/20 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/15 text-indigo-400 flex items-center justify-center border border-indigo-500/30 text-xl font-bold">
              🎓
            </div>
            <h4 className="text-base font-bold text-white">Campus Gatekeeper</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Exclusively available to accredited university students. Blocks spam and commercial resume mills with strict domain validation.
            </p>
          </div>

          <div className="card-3d p-6 rounded-3xl bg-slate-900 border-2 border-indigo-500/20 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/15 text-indigo-400 flex items-center justify-center border border-indigo-500/30 text-xl font-bold">
              📐
            </div>
            <h4 className="text-base font-bold text-white">10-Factor ATS Engine</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Immutable backend weights across Skills (15%), Experience (15%), Projects (15%), Keywords (10%), and Formatting (5%).
            </p>
          </div>

          <div className="card-3d p-6 rounded-3xl bg-slate-900 border-2 border-indigo-500/20 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/15 text-indigo-400 flex items-center justify-center border border-indigo-500/30 text-xl font-bold">
              🤖
            </div>
            <h4 className="text-base font-bold text-white">Server-Side Gemini 3.8</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Audits achievements with Google X-Y-Z formula. Runs entirely on Node.js to protect secrets and prevent client manipulation.
            </p>
          </div>

          <div className="card-3d p-6 rounded-3xl bg-slate-900 border-2 border-indigo-500/20 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/15 text-indigo-400 flex items-center justify-center border border-indigo-500/30 text-xl font-bold">
              🏆
            </div>
            <h4 className="text-base font-bold text-white">Free Course Bridge</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Detects your technical shortcomings and links directly to verified free courses from Harvard, MIT, and freeCodeCamp. Zero paywalls.
            </p>
          </div>
        </div>
      </section>

      {/* Relatable Student Wall of Praise */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-b from-slate-900/90 to-slate-950 border-2 border-slate-800 text-center relative overflow-hidden shadow-2xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-300 text-xs font-bold mb-4">
            <span>💬 Real Campus Reactions</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-black text-white">
            What Students Say When They Stop Getting Ghosted
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8 text-left">
            <div className="card-3d p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <p className="text-xs text-slate-300 italic leading-relaxed">
                "I sent 80 resumes with zero replies. Used Resume Nest to rewrite my bullets with real metrics, and got two internship screens that same week."
              </p>
              <div className="text-[11px] font-mono text-emerald-400">
                — CS Junior, Stanford University
              </div>
            </div>

            <div className="card-3d p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <p className="text-xs text-slate-300 italic leading-relaxed">
                "The 10-factor score pointed out that my project section had zero architecture keywords. Fixing that bumped my score from 41 to 89."
              </p>
              <div className="text-[11px] font-mono text-indigo-400">
                — ECE Senior, MIT
              </div>
            </div>

            <div className="card-3d p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <p className="text-xs text-slate-300 italic leading-relaxed">
                "The free course match showed me I was missing Docker and Redis. Took the Harvard/freeCodeCamp modules and put them on my resume!"
              </p>
              <div className="text-[11px] font-mono text-amber-300">
                — Software Engineering Sophomore, UC Berkeley
              </div>
            </div>
          </div>

          <div className="mt-10 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/login"
              className="btn-3d-indigo inline-flex items-center space-x-2 px-7 py-3 rounded-xl bg-indigo-600 text-white text-xs font-bold"
            >
              <span>Build My 10-Factor Resume Free</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
