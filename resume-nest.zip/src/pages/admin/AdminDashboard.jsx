import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api.js';
import LoadingState from '../../components/LoadingState.jsx';
import ErrorState from '../../components/ErrorState.jsx';
import {
  Shield,
  Users,
  FileText,
  BarChart3,
  BookOpen,
  ArrowRight,
  Settings,
  Sparkles,
  AlertCircle,
} from 'lucide-react';

export default function AdminDashboard() {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchMetrics = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.get('/admin/dashboard');
      setMetrics(data);
    } catch (err) {
      setError(err.message || 'Failed to load administrator dashboard.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, []);

  if (loading) {
    return <LoadingState message="Loading administrative metrics from database..." />;
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <ErrorState
          title="Admin Authorization Error"
          message={error}
          onRetry={fetchMetrics}
        />
      </div>
    );
  }

  const isEmpty = metrics?.isEmpty;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="rounded-3xl bg-slate-900 border border-indigo-500/20 p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-400/10 text-amber-300 border border-amber-400/20 flex items-center space-x-1">
              <Shield className="w-3.5 h-3.5" />
              <span>Administrative Control Center</span>
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Administrator Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
            Live operations monitoring, registered student records, approved college domains, and course catalog management.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <Link
            to="/admin/settings"
            className="flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
          >
            <Settings className="w-4 h-4 text-indigo-400" />
            <span>Manage Domains</span>
          </Link>

          <Link
            to="/admin/courses"
            className="flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition-all active:scale-95"
          >
            <BookOpen className="w-4 h-4" />
            <span>Manage Courses</span>
          </Link>
        </div>
      </div>

      {/* Metrics Cards — Derived strictly from DB */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Registered Students</span>
            <Users className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-white">{metrics?.totalStudents ?? 0}</span>
            <span className="text-xs text-slate-500">accounts</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Student Resumes</span>
            <FileText className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-white">{metrics?.totalResumes ?? 0}</span>
            <span className="text-xs text-slate-500">documents</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Total AI Analyses</span>
            <Sparkles className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-white">{metrics?.totalAnalyses ?? 0}</span>
            <span className="text-xs text-slate-500">diagnostics</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-medium">Active Free Courses</span>
            <BookOpen className="w-4 h-4 text-blue-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-white">{metrics?.totalActiveCourses ?? 0}</span>
            <span className="text-xs text-slate-500">of {metrics?.totalCourses ?? 0} total</span>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Management Sections */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">Administrative Actions</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Link
              to="/admin/students"
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all space-y-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-600/10 text-indigo-400 flex items-center justify-center">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-indigo-300">
                Student Directory
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Inspect registered student accounts, degrees, graduation years, and career targets without private data leakage.
              </p>
            </Link>

            <Link
              to="/admin/courses"
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all space-y-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-600/10 text-indigo-400 flex items-center justify-center">
                <BookOpen className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-indigo-300">
                Course Management
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Add, edit, activate, or deactivate verified free courses in the student recommendation engine.
              </p>
            </Link>

            <Link
              to="/admin/analytics"
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all space-y-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-600/10 text-indigo-400 flex items-center justify-center">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-indigo-300">
                AI ATS Analytics
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Analyze average student ATS readiness scores, common skill gaps, and in-demand target positions.
              </p>
            </Link>

            <Link
              to="/admin/settings"
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all space-y-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-600/10 text-indigo-400 flex items-center justify-center">
                <Settings className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-indigo-300">
                Approved College Domains
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Manage the institutional allowlist. Add university domains or toggle active status.
              </p>
            </Link>
          </div>
        </div>

        {/* Right Column: Database Status */}
        <div className="space-y-4">
          <h2 className="text-base font-bold text-white">Database Status</h2>

          {isEmpty ? (
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-dashed border-slate-800 text-center space-y-2">
              <AlertCircle className="w-8 h-8 text-slate-500 mx-auto" />
              <p className="text-xs text-slate-300 font-medium">No student data available yet.</p>
              <p className="text-[11px] text-slate-500">
                When students register and build resumes, verified metrics will appear here in real time.
              </p>
            </div>
          ) : (
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <span className="text-xs font-bold text-slate-300">Recently Updated Resumes</span>
              <div className="space-y-2">
                {metrics?.recentResumes?.map((r) => (
                  <div key={r.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                    <p className="font-semibold text-white truncate">{r.title}</p>
                    <p className="text-[10px] text-slate-400">{r.targetRole || 'Software Engineer'}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
