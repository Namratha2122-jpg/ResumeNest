import React from 'react';
import { getScoreColor } from '../utils/formatting.js';
import {
  UserCheck,
  FileText,
  GraduationCap,
  Wrench,
  Briefcase,
  FolderGit2,
  Award,
  Key,
  Layout,
  Target,
} from 'lucide-react';

const SECTION_CONFIG = {
  contact: { label: 'Contact Information', weight: '5%', icon: UserCheck, hint: 'No header/footer parser traps; valid email & links' },
  summary: { label: 'Professional Summary', weight: '10%', icon: FileText, hint: 'Target role alignment and student stage clarity' },
  education: { label: 'Education & Degree', weight: '10%', icon: GraduationCap, hint: 'University, major, GPA, grad year, coursework' },
  skills: { label: 'Technical & Domain Skills', weight: '15%', icon: Wrench, hint: 'Modern languages, frameworks, categorization' },
  experience: { label: 'Experience & Internships', weight: '15%', icon: Briefcase, hint: 'Quantified metrics, Google XYZ formula, action verbs' },
  projects: { label: 'Academic & Personal Projects', weight: '15%', icon: FolderGit2, hint: 'Applied technical projects, architecture, links' },
  certifications: { label: 'Certifications & Awards', weight: '5%', icon: Award, hint: 'Accredited training, hackathons, certifications' },
  keywords: { label: 'ATS Keyword Match', weight: '10%', icon: Key, hint: 'Screening algorithm terminology density' },
  formatting: { label: 'ATS Parseability', weight: '5%', icon: Layout, hint: 'Clean single-column standard markdown/text' },
  roleRelevance: { label: 'Target Role Alignment', weight: '10%', icon: Target, hint: 'Relevance to selected target engineering position' },
};

export default function ScoreBreakdown({ sectionScores = {} }) {
  return (
    <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 pb-4 border-b border-slate-800 gap-2">
        <div>
          <h3 className="text-base font-bold text-white">10-Factor ATS Score Breakdown</h3>
          <p className="text-xs text-slate-400">
            Validated backend section scores weighted to compute the authoritative readiness score.
          </p>
        </div>
        <span className="text-xs font-mono text-indigo-400 bg-indigo-500/10 px-3 py-1 rounded-full border border-indigo-500/20 w-fit">
          Weights total 100%
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {Object.entries(SECTION_CONFIG).map(([key, config]) => {
          const score = sectionScores[key] ?? 50;
          const Icon = config.icon;
          const colorClass = getScoreColor(score);

          return (
            <div
              key={key}
              className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700/80 transition-all"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 rounded-lg bg-indigo-600/10 text-indigo-400">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-200 block">{config.label}</span>
                    <span className="text-[10px] text-slate-500">Weight: {config.weight}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className={`text-base font-black ${colorClass}`}>{score}</span>
                  <span className="text-[10px] text-slate-500 font-semibold block">/ 100</span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden mb-2">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${
                    score >= 85 ? 'bg-emerald-500' : score >= 70 ? 'bg-blue-500' : score >= 55 ? 'bg-amber-500' : 'bg-rose-500'
                  }`}
                  style={{ width: `${Math.min(100, Math.max(5, score))}%` }}
                />
              </div>

              <p className="text-[11px] text-slate-400 line-clamp-1">{config.hint}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
