import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';
import { useRealtime } from '../hooks/useRealtime.jsx';
import api from '../services/api.js';
import LoadingState from '../components/LoadingState.jsx';
import {
  Sparkles,
  Search,
  UploadCloud,
  CheckCircle2,
  Heart,
  FileText,
  Share2,
  ExternalLink,
  Code2,
  Building,
  GraduationCap,
  Users,
  Flame,
  ArrowRight,
  X,
  Layers,
  Check,
  Download,
  Printer,
  FileDown,
  Eye,
  Radio,
} from 'lucide-react';

const ROLE_FILTERS = [
  { id: 'all', label: 'All Disciplines' },
  { id: 'software', label: 'Software Engineer (SWE)' },
  { id: 'ai', label: 'AI & Machine Learning' },
  { id: 'full stack', label: 'Full Stack & Startups' },
  { id: 'quant', label: 'Quant & High-Frequency' },
  { id: 'data', label: 'Data Science & Analytics' },
  { id: 'devops', label: 'Cloud & DevOps SRE' },
];

function downloadBlob(content, fileName, contentType) {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function generatePlainTextResume(resume) {
  const p = resume.personalInfo || {};
  let out = `${p.fullName || 'Student Name'}\n`;
  out += `${p.email || ''} | ${p.phone || ''} | ${p.location || ''}\n`;
  if (p.linkedin) out += `LinkedIn: ${p.linkedin}\n`;
  if (p.github) out += `GitHub: ${p.github}\n\n`;

  if (resume.summary) {
    out += `PROFESSIONAL SUMMARY\n${resume.summary}\n\n`;
  }

  if (resume.education?.length) {
    out += `EDUCATION\n`;
    resume.education.forEach((e) => {
      out += `${e.institution} — ${e.degree} (${e.graduationYear || '2026'})\n`;
      if (e.gpa) out += `GPA: ${e.gpa}\n`;
      if (e.coursework) out += `Relevant Coursework: ${e.coursework}\n`;
    });
    out += `\n`;
  }

  if (resume.skills) {
    out += `TECHNICAL SKILLS\n`;
    if (resume.skills.languages) out += `Languages: ${resume.skills.languages}\n`;
    if (resume.skills.frameworks) out += `Frameworks: ${resume.skills.frameworks}\n`;
    if (resume.skills.developerTools) out += `Tools & Cloud: ${resume.skills.developerTools}\n`;
    if (resume.skills.coreConcepts) out += `Core Concepts: ${resume.skills.coreConcepts}\n\n`;
  }

  if (resume.experience?.length) {
    out += `EXPERIENCE\n`;
    resume.experience.forEach((exp) => {
      out += `${exp.role} | ${exp.company} (${exp.period || ''})\n`;
      exp.bullets?.forEach((b) => {
        out += `• ${b}\n`;
      });
    });
    out += `\n`;
  }

  if (resume.projects?.length) {
    out += `PROJECTS\n`;
    resume.projects.forEach((proj) => {
      out += `${proj.title} | ${proj.technologies || ''}\n`;
      if (proj.link) out += `Link: ${proj.link}\n`;
      out += `${proj.description}\n`;
    });
    out += `\n`;
  }

  if (resume.certifications?.length) {
    out += `CERTIFICATIONS & HONORS\n`;
    resume.certifications.forEach((c) => {
      out += `• ${c}\n`;
    });
  }

  return out;
}

export default function Templates() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRole, setSelectedRole] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [copiedId, setCopiedId] = useState(null);
  const [recentlyAddedId, setRecentlyAddedId] = useState(null);

  // Preview & Download Modal State
  const [activePreviewTemplate, setActivePreviewTemplate] = useState(null);
  const [liveTickerMessage, setLiveTickerMessage] = useState(
    'Real-Time Hub Active: Synchronizing live downloads and peer templates'
  );

  // Upload Form State
  const [uploadForm, setUploadForm] = useState({
    title: '',
    targetRole: 'Software Engineer',
    category: 'Big Tech & Systems',
    description: '',
    skills: 'TypeScript, React, Node.js, PostgreSQL, Docker, AWS',
    sampleBullet: 'Engineered high-throughput caching layer in Redis reducing database query load by 45%.',
    tags: 'FAANG Ready, ATS 98, Taleo Tested',
    atsScore: '96',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadError, setUploadError] = useState('');

  // Handle Real-Time Database SSE Events
  const { isConnected, activeSubscribers } = useRealtime({
    'templates:created': (payload) => {
      if (payload && payload.template) {
        setTemplates((prev) => {
          if (prev.some((t) => t.id === payload.template.id)) return prev;
          return [payload.template, ...prev];
        });
        setRecentlyAddedId(payload.template.id);
        setLiveTickerMessage(`New Template: ${payload.template.title} by ${payload.template.authorName}`);
        setTimeout(() => setRecentlyAddedId(null), 8000);
      }
    },
    'templates:upvoted': (payload) => {
      if (payload && payload.id) {
        setTemplates((prev) =>
          prev.map((t) => (t.id === payload.id ? { ...t, upvotes: payload.upvotes } : t))
        );
        if (payload.title) {
          setLiveTickerMessage(`Peer upvoted: "${payload.title}" (${payload.upvotes} votes)`);
        }
      }
    },
    'templates:downloaded': (payload) => {
      if (payload && payload.id) {
        setTemplates((prev) =>
          prev.map((t) => (t.id === payload.id ? { ...t, downloadCount: payload.downloadCount } : t))
        );
        if (payload.title) {
          setLiveTickerMessage(`Live Download: "${payload.title}" downloaded by student`);
        }
      }
    },
    'stats:updated': (payload) => {
      if (payload && payload.message) {
        setLiveTickerMessage(payload.message);
      }
    },
  });

  // Fetch initial templates
  useEffect(() => {
    async function loadTemplates() {
      try {
        const res = await api.get('/templates');
        if (res.templates) {
          setTemplates(res.templates);
        }
      } catch (err) {
        console.error('Failed to load templates:', err);
      } finally {
        setLoading(false);
      }
    }
    loadTemplates();
  }, []);

  // Filter templates
  const filteredTemplates = useMemo(() => {
    return templates.filter((tmpl) => {
      const matchesRole =
        selectedRole === 'all' ||
        tmpl.targetRole.toLowerCase().includes(selectedRole.toLowerCase());

      const q = searchQuery.toLowerCase().trim();
      const matchesQuery =
        !q ||
        tmpl.title.toLowerCase().includes(q) ||
        tmpl.authorCollege.toLowerCase().includes(q) ||
        tmpl.category.toLowerCase().includes(q) ||
        tmpl.tags.some((tag) => tag.toLowerCase().includes(q));

      return matchesRole && matchesQuery;
    });
  }, [templates, selectedRole, searchQuery]);

  // Handle Upvote
  const handleUpvote = async (templateId, e) => {
    e.stopPropagation();
    setTemplates((prev) =>
      prev.map((t) => (t.id === templateId ? { ...t, upvotes: (t.upvotes || 0) + 1 } : t))
    );

    try {
      await api.post(`/templates/${templateId}/upvote`, {});
    } catch (err) {
      console.error('Upvote failed:', err);
    }
  };

  // Handle Download Action
  const handleDownload = async (tmpl, format = 'txt') => {
    // Record download on server
    try {
      await api.post(`/templates/${tmpl.id}/download`, {});
    } catch (e) {}

    const rawData = tmpl.rawTemplateData || {
      personalInfo: {
        fullName: tmpl.authorName,
        location: tmpl.authorCollege,
        email: tmpl.authorEmail,
      },
      summary: tmpl.description,
      skills: {
        languages: tmpl.previewSections?.skills,
      },
      experience: [
        {
          role: tmpl.targetRole,
          company: 'Industry Partner',
          bullets: [tmpl.previewSections?.sampleBullet || 'Engineered high-performance services.'],
        },
      ],
    };

    const cleanName = tmpl.title.replace(/[^a-zA-Z0-9]/g, '_');

    if (format === 'json') {
      downloadBlob(JSON.stringify(rawData, null, 2), `${cleanName}.json`, 'application/json');
    } else {
      const textContent = generatePlainTextResume(rawData);
      downloadBlob(textContent, `${cleanName}_ATS.txt`, 'text/plain');
    }
  };

  // Handle Use Template
  const handleUseTemplate = (tmpl) => {
    localStorage.setItem(
      'resume_nest_imported_template',
      JSON.stringify({
        title: tmpl.title,
        targetRole: tmpl.targetRole,
        skills: tmpl.previewSections?.skills || '',
        bullet: tmpl.previewSections?.sampleBullet || '',
        category: tmpl.category,
        author: tmpl.authorName,
        college: tmpl.authorCollege,
        raw: tmpl.rawTemplateData || null,
      })
    );

    api.post(`/templates/${tmpl.id}/use`, {}).catch(() => {});
    navigate('/builder');
  };

  // Handle Upload Form Submit
  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    setUploadError('');

    if (!user) {
      setUploadError('Please sign in with your college account to share templates with fellow students.');
      return;
    }

    if (!uploadForm.title.trim()) {
      setUploadError('Please provide a title for your resume template.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await api.post('/templates', uploadForm);
      if (res.template) {
        setIsUploadModalOpen(false);
        setUploadForm({
          title: '',
          targetRole: 'Software Engineer',
          category: 'Big Tech & Systems',
          description: '',
          skills: 'TypeScript, React, Node.js, PostgreSQL, Docker, AWS',
          sampleBullet: 'Engineered high-throughput caching layer in Redis reducing database query load by 45%.',
          tags: 'FAANG Ready, ATS 98, Taleo Tested',
          atsScore: '96',
        });
      }
    } catch (err) {
      setUploadError(err.message || 'Failed to publish template.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleShare = (templateId, e) => {
    e.stopPropagation();
    const url = `${window.location.origin}/templates#${templateId}`;
    navigator.clipboard.writeText(url);
    setCopiedId(templateId);
    setTimeout(() => setCopiedId(null), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Real-Time Live Activity Ticker Bar */}
      <div className="rounded-2xl bg-slate-900/90 border border-indigo-500/30 px-4 py-2.5 flex items-center justify-between shadow-lg text-xs font-mono">
        <div className="flex items-center space-x-2 text-slate-300 truncate">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400"></span>
          </span>
          <span className="text-cyan-400 font-bold uppercase tracking-wider text-[10px]">Live Campus Pulse:</span>
          <span className="text-slate-200 truncate">{liveTickerMessage}</span>
        </div>

        <div className="hidden sm:flex items-center space-x-2 text-slate-400 text-[11px] flex-shrink-0">
          <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
          <span>{isConnected ? 'Real-Time Sync Active' : 'Connecting...'}</span>
          <span>·</span>
          <span>{activeSubscribers} Active Peers</span>
        </div>
      </div>

      {/* Hero Header */}
      <div className="relative rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 p-6 sm:p-8 overflow-hidden shadow-2xl">
        <div className="max-w-2xl space-y-3">
          <div className="inline-flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-cyan-400 bg-cyan-400/10 px-3 py-1 rounded-full border border-cyan-400/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ready-Made ATS Templates & Student Uploads</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            Readymade Student{' '}
            <span className="bg-gradient-to-r from-cyan-300 via-indigo-300 to-amber-300 bg-clip-text text-transparent">
              Resume Templates
            </span>
          </h1>

          <p className="text-sm text-slate-300 leading-relaxed">
            Tested and verified single-column resume templates designed to pass Taleo, Workday, and Greenhouse recruitment algorithms. Download as ATS-compliant plain text, JSON, or launch directly into the builder.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setIsUploadModalOpen(true)}
              className="btn-3d-gradient inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl text-white font-bold text-xs"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Upload Your Template for Students</span>
            </button>

            <Link
              to="/builder"
              className="btn-3d-dark inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl text-slate-200 text-xs font-semibold"
            >
              <FileText className="w-4 h-4 text-indigo-400" />
              <span>Build From Scratch</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by keywords, tags (e.g. 'FAANG', 'Distributed Systems', 'PyTorch'), or university..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div className="flex items-center space-x-2 overflow-x-auto pb-1">
            {ROLE_FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setSelectedRole(f.id)}
                className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  selectedRole === f.id
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Templates Grid */}
      {loading ? (
        <LoadingState message="Connecting to real-time template catalog..." />
      ) : filteredTemplates.length === 0 ? (
        <div className="card-3d p-12 text-center rounded-3xl bg-slate-900/60 border border-slate-800 space-y-3">
          <Layers className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white">No Templates Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Try adjusting your search query or discipline filter.
          </p>
          <button
            type="button"
            onClick={() => setIsUploadModalOpen(true)}
            className="btn-3d-indigo inline-flex items-center space-x-2 px-4 py-2 rounded-xl text-white text-xs font-bold mt-2"
          >
            <UploadCloud className="w-3.5 h-3.5" />
            <span>Upload Template</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredTemplates.map((tmpl) => {
            const isRecent = tmpl.id === recentlyAddedId;
            return (
              <div
                key={tmpl.id}
                className={`card-3d rounded-3xl bg-slate-900/90 border transition-all duration-300 p-6 flex flex-col justify-between space-y-5 ${
                  isRecent
                    ? 'border-cyan-400 shadow-xl shadow-cyan-500/10 ring-2 ring-cyan-400/30'
                    : 'border-slate-800 hover:border-indigo-500/40'
                }`}
              >
                {/* Header info */}
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                          {tmpl.category}
                        </span>
                        {isRecent && (
                          <span className="text-[10px] font-mono font-black uppercase text-cyan-300 bg-cyan-400/20 px-2 py-0.5 rounded border border-cyan-400/40 animate-pulse">
                            Just Uploaded (Live)
                          </span>
                        )}
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                        {tmpl.title}
                      </h3>
                    </div>

                    <div className="flex flex-col items-end flex-shrink-0">
                      <div className="flex items-center space-x-1 text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-lg border border-emerald-500/20">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span className="text-xs font-black font-mono">{tmpl.atsScore}% ATS</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono mt-0.5 flex items-center space-x-1">
                        <Download className="w-3 h-3 text-cyan-400" />
                        <span>{tmpl.downloadCount || 0} downloads</span>
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                    {tmpl.description}
                  </p>

                  {/* Student author badge */}
                  <div className="flex items-center space-x-2 text-xs text-slate-400 pt-1 border-t border-slate-800/80">
                    <GraduationCap className="w-4 h-4 text-amber-400 flex-shrink-0" />
                    <span className="font-semibold text-slate-200">{tmpl.authorName}</span>
                    <span className="text-slate-600">·</span>
                    <span className="text-slate-400 truncate">{tmpl.authorCollege}</span>
                  </div>

                  {/* Sample Snippet Preview */}
                  {tmpl.previewSections && (
                    <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/70 space-y-1.5 text-[11px]">
                      <div className="flex items-center space-x-1.5 text-slate-400">
                        <Code2 className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="font-mono text-slate-300">Key Tech Stack:</span>
                      </div>
                      <p className="text-slate-400 font-mono text-[10.5px] truncate">
                        {tmpl.previewSections.skills}
                      </p>
                      <div className="text-slate-400 font-mono text-[10px] italic border-l-2 border-indigo-500/50 pl-2 mt-1">
                        "{tmpl.previewSections.sampleBullet}"
                      </div>
                    </div>
                  )}

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {tmpl.tags?.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800/80 text-slate-300 border border-slate-700/60"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center space-x-2">
                    <button
                      type="button"
                      onClick={(e) => handleUpvote(tmpl.id, e)}
                      className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-rose-400 hover:text-rose-300 transition-colors flex items-center space-x-1.5 text-xs font-semibold"
                      title="Upvote this template"
                    >
                      <Heart className="w-3.5 h-3.5 fill-rose-500/30 text-rose-400" />
                      <span>{tmpl.upvotes || 0}</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => handleShare(tmpl.id, e)}
                      className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
                      title="Copy template link"
                    >
                      {copiedId === tmpl.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Share2 className="w-3.5 h-3.5" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => setActivePreviewTemplate(tmpl)}
                      className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-indigo-400 hover:text-indigo-300 transition-colors flex items-center space-x-1 text-xs font-semibold"
                      title="Quick Preview"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Preview</span>
                    </button>
                  </div>

                  <div className="flex items-center space-x-2">
                    {/* Direct Download Button */}
                    <button
                      type="button"
                      onClick={() => handleDownload(tmpl, 'txt')}
                      className="px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center space-x-1.5 transition-colors"
                      title="Download ATS Plain Text format"
                    >
                      <Download className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Download</span>
                    </button>

                    {/* Use Template */}
                    <button
                      type="button"
                      onClick={() => handleUseTemplate(tmpl)}
                      className="btn-3d-gradient inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-white text-xs font-bold"
                    >
                      <span>Use in Builder</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Quick Preview & Full Download Modal */}
      {activePreviewTemplate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-4xl rounded-3xl bg-slate-900 border-2 border-indigo-500/40 p-6 sm:p-8 shadow-2xl space-y-6 my-8 max-h-[90vh] flex flex-col justify-between">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-400 bg-cyan-400/10 px-2.5 py-0.5 rounded-full border border-cyan-400/30">
                  {activePreviewTemplate.category}
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  {activePreviewTemplate.title}
                </h2>
                <p className="text-xs text-slate-400">
                  Contributed by {activePreviewTemplate.authorName} ({activePreviewTemplate.authorCollege})
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => handleDownload(activePreviewTemplate, 'txt')}
                  className="px-3.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center space-x-1.5"
                >
                  <Download className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Download .TXT</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDownload(activePreviewTemplate, 'json')}
                  className="px-3.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center space-x-1.5"
                >
                  <FileDown className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Download .JSON</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleUseTemplate(activePreviewTemplate)}
                  className="btn-3d-gradient px-4 py-2 rounded-xl text-white text-xs font-bold flex items-center space-x-1.5"
                >
                  <span>Use in Builder</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => setActivePreviewTemplate(null)}
                  className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Resume Sheet Preview */}
            <div className="flex-1 overflow-y-auto max-h-[60vh] bg-white text-slate-900 rounded-2xl p-6 sm:p-10 font-sans text-xs leading-relaxed space-y-4 shadow-inner">
              <div className="text-center border-b border-slate-800 pb-3">
                <h3 className="text-xl font-bold uppercase tracking-tight text-slate-900">
                  {activePreviewTemplate.rawTemplateData?.personalInfo?.fullName || activePreviewTemplate.authorName}
                </h3>
                <p className="text-slate-600 text-[11px] mt-1 font-mono">
                  {activePreviewTemplate.rawTemplateData?.personalInfo?.email || activePreviewTemplate.authorEmail} |{' '}
                  {activePreviewTemplate.rawTemplateData?.personalInfo?.phone || '(555) 019-2834'} |{' '}
                  {activePreviewTemplate.rawTemplateData?.personalInfo?.location || activePreviewTemplate.authorCollege}
                </p>
              </div>

              {/* Summary */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase text-[11px] border-b border-slate-300 pb-0.5 mb-1">
                  Professional Summary
                </h4>
                <p className="text-slate-700">
                  {activePreviewTemplate.rawTemplateData?.summary || activePreviewTemplate.description}
                </p>
              </div>

              {/* Skills */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase text-[11px] border-b border-slate-300 pb-0.5 mb-1">
                  Technical Skills
                </h4>
                <p className="text-slate-700 font-mono text-[11px]">
                  <strong>Languages:</strong> {activePreviewTemplate.rawTemplateData?.skills?.languages || activePreviewTemplate.previewSections?.skills}
                </p>
                {activePreviewTemplate.rawTemplateData?.skills?.frameworks && (
                  <p className="text-slate-700 font-mono text-[11px]">
                    <strong>Frameworks:</strong> {activePreviewTemplate.rawTemplateData.skills.frameworks}
                  </p>
                )}
                {activePreviewTemplate.rawTemplateData?.skills?.developerTools && (
                  <p className="text-slate-700 font-mono text-[11px]">
                    <strong>Tools & Cloud:</strong> {activePreviewTemplate.rawTemplateData.skills.developerTools}
                  </p>
                )}
              </div>

              {/* Experience */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase text-[11px] border-b border-slate-300 pb-0.5 mb-1">
                  Experience
                </h4>
                {activePreviewTemplate.rawTemplateData?.experience?.map((exp, idx) => (
                  <div key={idx} className="mb-2">
                    <div className="flex justify-between font-bold text-slate-900">
                      <span>{exp.role} — {exp.company}</span>
                      <span className="font-normal text-slate-600">{exp.period || 'Jun 2025 - Present'}</span>
                    </div>
                    <ul className="list-disc list-inside text-slate-700 space-y-0.5 mt-0.5">
                      {exp.bullets?.map((b, bIdx) => (
                        <li key={bIdx}>{b}</li>
                      ))}
                    </ul>
                  </div>
                )) || (
                  <p className="text-slate-700">{activePreviewTemplate.previewSections?.sampleBullet}</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Upload Template Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-xl rounded-3xl bg-slate-900 border-2 border-indigo-500/40 p-6 sm:p-8 shadow-2xl space-y-6 my-8">
            <button
              type="button"
              onClick={() => setIsUploadModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="space-y-1">
              <div className="inline-flex items-center space-x-2 text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-400 bg-cyan-400/10 px-2.5 py-0.5 rounded-full border border-cyan-400/30">
                <UploadCloud className="w-3 h-3" />
                <span>Peer-to-Peer Knowledge Sharing</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                Upload Your Resume Template
              </h2>
              <p className="text-xs text-slate-400">
                Help other students land interviews. Your template will sync across the real-time database to all active students.
              </p>
            </div>

            {uploadError && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-300">
                {uploadError}
              </div>
            )}

            <form onSubmit={handleUploadSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Template Title *
                </label>
                <input
                  type="text"
                  required
                  value={uploadForm.title}
                  onChange={(e) => setUploadForm({ ...uploadForm, title: e.target.value })}
                  placeholder="e.g. Meta Production Engineer 2026 Grad"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Target Role
                  </label>
                  <select
                    value={uploadForm.targetRole}
                    onChange={(e) => setUploadForm({ ...uploadForm, targetRole: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Software Engineer">Software Engineer (SWE)</option>
                    <option value="AI/ML Engineer">AI/ML Engineer</option>
                    <option value="Full Stack Engineer">Full Stack Engineer</option>
                    <option value="Quant Developer">Quant Developer</option>
                    <option value="Data Scientist">Data Scientist</option>
                    <option value="DevOps / Cloud">DevOps / Cloud Infrastructure</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Category Focus
                  </label>
                  <select
                    value={uploadForm.category}
                    onChange={(e) => setUploadForm({ ...uploadForm, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Big Tech & Systems">Big Tech & Systems</option>
                    <option value="High-Growth Startups">High-Growth Startups</option>
                    <option value="Artificial Intelligence">Artificial Intelligence</option>
                    <option value="Quantitative Finance">Quantitative Finance</option>
                    <option value="Research & Academia">Research & Academia</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Key Technical Skills
                </label>
                <input
                  type="text"
                  value={uploadForm.skills}
                  onChange={(e) => setUploadForm({ ...uploadForm, skills: e.target.value })}
                  placeholder="e.g. Go, C++, Python, PostgreSQL, Kubernetes"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Sample High-Impact Bullet Point
                </label>
                <textarea
                  rows={2}
                  value={uploadForm.sampleBullet}
                  onChange={(e) => setUploadForm({ ...uploadForm, sampleBullet: e.target.value })}
                  placeholder="Use action verb + quantifiable metric, e.g. 'Refactored backend microservices with Go reducing API latency by 35%.'"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Description & ATS Highlights
                </label>
                <textarea
                  rows={2}
                  value={uploadForm.description}
                  onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                  placeholder="Describe why this resume format works well for your target role and what company tests it has passed."
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Tags (Comma separated)
                </label>
                <input
                  type="text"
                  value={uploadForm.tags}
                  onChange={(e) => setUploadForm({ ...uploadForm, tags: e.target.value })}
                  placeholder="e.g. FAANG, YC Founder, Workday Tested, ATS 98"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn-3d-gradient px-6 py-2.5 rounded-xl text-white text-xs font-bold disabled:opacity-50 flex items-center space-x-2"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>{isSubmitting ? 'Publishing Live...' : 'Publish to Student Network'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
