import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.jsx';
import { LogIn, LogOut, User, ChevronDown, ShieldCheck } from 'lucide-react';

export default function AuthButton({ compact = false }) {
  const { user, logout } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    logout();
    setDropdownOpen(false);
    navigate('/');
  };

  if (!user || !user.isAuthorized) {
    return (
      <Link
        to="/login"
        className="inline-flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm shadow-indigo-600/30 transition-all active:scale-95"
      >
        <LogIn className="w-4 h-4" />
        <span>{!compact ? 'Campus Sign In' : 'Sign In'}</span>
      </Link>
    );
  }

  const initials = user.name
    ? user.name.slice(0, 2).toUpperCase()
    : (user.email ? user.email.slice(0, 2).toUpperCase() : 'ST');

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setDropdownOpen(!dropdownOpen)}
        className="flex items-center space-x-2 p-1.5 rounded-xl hover:bg-slate-800 transition-colors border border-transparent hover:border-slate-700"
      >
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center text-white text-xs font-bold shadow-sm">
          {initials}
        </div>
        {!compact && (
          <div className="text-left hidden lg:block pr-1">
            <p className="text-xs font-semibold text-slate-200 leading-tight truncate max-w-[120px]">{user.name || 'Student'}</p>
            <p className="text-[10px] text-emerald-400 font-mono truncate max-w-[120px]">{user.domain}</p>
          </div>
        )}
        <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
      </button>

      {dropdownOpen && (
        <div className="absolute right-0 mt-2 w-64 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl py-2 z-50 text-slate-200 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="px-4 py-2.5 border-b border-slate-800">
            <p className="text-xs font-bold text-white truncate">{user.name || 'Verified Student'}</p>
            <p className="text-[11px] text-slate-400 truncate">{user.email}</p>
            <div className="mt-2 flex items-center space-x-1.5 text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 font-medium w-fit">
              <ShieldCheck className="w-3 h-3" />
              <span>{user.collegeName || user.domain}</span>
            </div>
          </div>

          <div className="py-1">
            <Link
              to="/profile"
              onClick={() => setDropdownOpen(false)}
              className="flex items-center space-x-2 px-4 py-2 text-xs hover:bg-slate-800 hover:text-white transition-colors"
            >
              <User className="w-4 h-4 text-slate-400" />
              <span>Student Profile</span>
            </Link>
          </div>

          <div className="pt-1 border-t border-slate-800">
            <button
              onClick={handleLogout}
              className="w-full flex items-center space-x-2 px-4 py-2 text-xs text-rose-400 hover:bg-rose-500/10 transition-colors text-left"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
