/**
 * Client-side Form Validators
 */

export function isValidEmail(email) {
  if (!email || typeof email !== 'string') return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export function isValidUrl(url) {
  if (!url) return true; // Optional URLs can be empty
  try {
    const parsed = new URL(url.startsWith('http') ? url : `https://${url}`);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

export function validateResumeForm(formData) {
  const errors = {};

  if (!formData.title?.trim()) {
    errors.title = 'Resume title is required (e.g. "Software Engineer 2026")';
  }

  if (!formData.personalInfo?.fullName?.trim()) {
    errors.fullName = 'Full name is required';
  }

  if (!formData.personalInfo?.email?.trim()) {
    errors.email = 'Campus email address is required';
  } else if (!isValidEmail(formData.personalInfo.email)) {
    errors.email = 'Please provide a valid email format';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}
