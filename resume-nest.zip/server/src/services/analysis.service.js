import { getResumeById, saveAnalysisResult, getAnalysisResult } from './resume.service.js';
import { analyzeResumeWithGemini, improveSectionWithGemini } from './gemini.service.js';

/**
 * High-level Analysis Service
 * Coordinates resume fetching, ownership verification, Gemini processing,
 * ATS scoring, and result persistence.
 */
export async function runResumeAnalysis(resumeId, userId, requestedTargetRole) {
  // 1. Authoritative ownership check
  const resume = await getResumeById(resumeId, userId);

  const targetRole = requestedTargetRole || resume.targetRole || resume.personalInfo?.targetRole || 'Software Engineer';

  // 2. Call Gemini to perform structured diagnostic
  const analysisResult = await analyzeResumeWithGemini(resume, targetRole);

  // 3. Save result securely associated with student UID
  await saveAnalysisResult(resumeId, userId, analysisResult);

  return analysisResult;
}

/**
 * Section Improvement Service
 */
export async function improveResumeSection(userId, { resumeId, section, content, targetRole, instruction }) {
  if (resumeId) {
    // Verify ownership of the resume being edited
    await getResumeById(resumeId, userId);
  }

  return await improveSectionWithGemini({
    section,
    content,
    targetRole,
    instruction,
  });
}

export { getAnalysisResult };
