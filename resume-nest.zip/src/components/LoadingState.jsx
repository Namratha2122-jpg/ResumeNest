import React from 'react';
import { Loader2, Sparkles } from 'lucide-react';

export default function LoadingState({
  title = 'Processing...',
  message = 'Please wait while we interact with the server.',
  isAnalyzing = false,
}) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[300px] p-8 text-center bg-slate-900/50 rounded-2xl border border-slate-800/80">
      <div className="relative mb-5">
        <div className="w-16 h-16 rounded-2xl bg-indigo-600/10 border border-indigo-500/20 flex items-center justify-center">
          <Loader2 className="w-8 h-8 text-indigo-400 animate-spin" />
        </div>
        {isAnalyzing && (
          <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow-lg animate-bounce">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
        )}
      </div>

      <h3 className="text-base font-semibold text-white mb-1.5">{title}</h3>
      <p className="text-xs text-slate-400 max-w-sm leading-relaxed">{message}</p>

      {isAnalyzing && (
        <div className="mt-6 flex items-center space-x-2 text-[11px] text-indigo-300/80 bg-indigo-950/40 px-3 py-1.5 rounded-full border border-indigo-500/20">
          <span className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
          <span>Server-side Gemini 3.8 Flash evaluating 10 ATS dimensions</span>
        </div>
      )}
    </div>
  );
}
