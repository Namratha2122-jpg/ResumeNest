import { getAdminByUidOrEmail } from '../services/db.service.js';

/**
 * Admin Authorization Middleware
 * Verifies that the authenticated user is an active administrator in the admins collection.
 * Never trusts client roles or request body.
 */
export async function authorizeAdmin(req, res, next) {
  if (!req.user || !req.user.uid) {
    return res.status(401).json({
      error: 'Please sign in to continue.',
      code: 'UNAUTHORIZED',
    });
  }

  try {
    const admin = await getAdminByUidOrEmail(req.user.uid, req.user.email);

    if (!admin || admin.active !== true) {
      return res.status(403).json({
        error: 'You do not have administrator access.',
        code: 'FORBIDDEN_NOT_ADMIN',
      });
    }

    req.user.userType = 'admin';
    req.user.isAdmin = true;
    req.admin = admin;

    next();
  } catch (error) {
    console.error('[AuthorizeAdmin] Error checking admin status:', error);
    return res.status(500).json({
      error: 'Failed to verify administrative authorization.',
    });
  }
}

/**
 * Permission Check Middleware Generator
 * e.g. requirePermission('manage_courses'), requirePermission('view_students'), etc.
 */
export function requirePermission(permission) {
  return (req, res, next) => {
    if (!req.admin) {
      return res.status(403).json({
        error: 'You do not have administrator access.',
      });
    }

    const permissions = req.admin.permissions || [];
    if (!permissions.includes(permission)) {
      return res.status(403).json({
        error: `Administrator access denied. Missing permission: ${permission}`,
        code: 'FORBIDDEN_MISSING_PERMISSION',
      });
    }

    next();
  };
}
