import express from 'express';
import { authenticate } from '../middleware/authenticate.js';
import { authorizeStudent } from '../middleware/authorizeStudent.js';
import {
  analyzeResume,
  getAnalysis,
  improveSection,
} from '../controllers/analysis.controller.js';

const router = express.Router();

router.use(authenticate);
router.use(authorizeStudent);

router.post('/improve', improveSection);
router.post('/:resumeId', analyzeResume);
router.get('/:resumeId', getAnalysis);

export default router;
