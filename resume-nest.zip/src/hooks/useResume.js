import { useState, useCallback } from 'react';
import api from '../services/api.js';

export function useResume() {
  const [resumes, setResumes] = useState([]);
  const [currentResume, setCurrentResume] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [recommendedCourses, setRecommendedCourses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchResumes = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.get('/student/resumes').catch(() => api.get('/resumes'));
      setResumes(data.resumes || []);
      return data.resumes || [];
    } catch (err) {
      setError(err.message || 'Failed to fetch resumes');
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const getResume = useCallback(async (resumeId) => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.get(`/student/resumes/${resumeId}`).catch(() => api.get(`/resumes/${resumeId}`));
      setCurrentResume(data.resume);
      return data.resume;
    } catch (err) {
      setError(err.message || 'Failed to fetch resume');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const createResume = useCallback(async (resumeData) => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.post('/student/resumes', resumeData).catch(() => api.post('/resumes', resumeData));
      setResumes((prev) => [data.resume, ...prev]);
      setCurrentResume(data.resume);
      return data.resume;
    } catch (err) {
      setError(err.message || 'Failed to create resume');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const updateResume = useCallback(async (resumeId, resumeData) => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.put(`/student/resumes/${resumeId}`, resumeData).catch(() => api.put(`/resumes/${resumeId}`, resumeData));
      setCurrentResume(data.resume);
      setResumes((prev) => prev.map((r) => (r.id === resumeId ? data.resume : r)));
      return data.resume;
    } catch (err) {
      setError(err.message || 'Failed to update resume');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const deleteResume = useCallback(async (resumeId) => {
    setLoading(true);
    setError(null);
    try {
      await api.delete(`/student/resumes/${resumeId}`).catch(() => api.delete(`/resumes/${resumeId}`));
      setResumes((prev) => prev.filter((r) => r.id !== resumeId));
      if (currentResume?.id === resumeId) {
        setCurrentResume(null);
      }
    } catch (err) {
      setError(err.message || 'Failed to delete resume');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [currentResume]);

  const runAnalysis = useCallback(async (resumeId, targetRole) => {
    setLoading(true);
    setError(null);
    try {
      const result = await api.post(`/student/analysis/${resumeId}`, { targetRole })
        .catch(() => api.post(`/analysis/${resumeId}`, { targetRole }));
      setAnalysis(result);
      return result;
    } catch (err) {
      setError(err.message || 'AI analysis is temporarily unavailable. Please try again.');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchAnalysis = useCallback(async (resumeId) => {
    setLoading(true);
    try {
      const result = await api.get(`/student/analysis/${resumeId}`)
        .catch(() => api.get(`/analysis/${resumeId}`));
      setAnalysis(result);
      return result;
    } catch (err) {
      if (err.status !== 404) {
        setError(err.message);
      }
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const improveSection = useCallback(async ({ resumeId, section, content, targetRole, instruction }) => {
    try {
      const result = await api.post('/student/improve', {
        resumeId,
        section,
        content,
        targetRole,
        instruction,
      }).catch(() => api.post('/analysis/improve', {
        resumeId,
        section,
        content,
        targetRole,
        instruction,
      }));
      return result;
    } catch (err) {
      throw new Error(err.message || 'AI section improvement is temporarily unavailable. Please try again.');
    }
  }, []);

  const fetchRecommendedCourses = useCallback(async (resumeId) => {
    try {
      const data = await api.get(`/student/recommendations/${resumeId}`)
        .catch(() => api.get(`/courses/recommended/${resumeId}`));
      setRecommendedCourses(data.recommendedCourses || []);
      return data;
    } catch (err) {
      console.error('Failed to fetch recommended courses:', err);
      return { recommendedCourses: [] };
    }
  }, []);

  return {
    resumes,
    currentResume,
    analysis,
    recommendedCourses,
    loading,
    error,
    fetchResumes,
    getResume,
    createResume,
    updateResume,
    deleteResume,
    runAnalysis,
    fetchAnalysis,
    improveSection,
    fetchRecommendedCourses,
    setCurrentResume,
    setAnalysis,
  };
}

export default useResume;
