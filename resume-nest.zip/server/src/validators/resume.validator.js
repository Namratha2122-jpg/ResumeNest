/**
 * Resume Input Validator
 */
export function validateResumeInput(data) {
  if (!data || typeof data !== 'object') {
    const error = new Error('Please provide valid resume information.');
    error.status = 400;
    throw error;
  }

  const { title, personalInfo, education, experience, skills, projects } = data;

  if (title && typeof title !== 'string') {
    const error = new Error('Please provide valid resume information: title must be a string.');
    error.status = 400;
    throw error;
  }

  if (personalInfo && typeof personalInfo !== 'object') {
    const error = new Error('Please provide valid resume information: personalInfo must be an object.');
    error.status = 400;
    throw error;
  }

  if (education && !Array.isArray(education)) {
    const error = new Error('Please provide valid resume information: education must be an array.');
    error.status = 400;
    throw error;
  }

  if (experience && !Array.isArray(experience)) {
    const error = new Error('Please provide valid resume information: experience must be an array.');
    error.status = 400;
    throw error;
  }

  if (projects && !Array.isArray(projects)) {
    const error = new Error('Please provide valid resume information: projects must be an array.');
    error.status = 400;
    throw error;
  }

  return true;
}
