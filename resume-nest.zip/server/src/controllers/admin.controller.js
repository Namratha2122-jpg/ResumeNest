import * as adminService from '../services/admin.service.js';

// DASHBOARD
export async function getDashboard(req, res, next) {
  try {
    const data = await adminService.getDashboardMetrics();
    return res.json(data);
  } catch (error) {
    next(error);
  }
}

// STUDENTS
export async function getStudents(req, res, next) {
  try {
    const students = await adminService.getStudentsList();
    return res.json({ students });
  } catch (error) {
    next(error);
  }
}

// COURSES
export async function getCourses(req, res, next) {
  try {
    const courses = await adminService.getAllCourses();
    return res.json({ courses });
  } catch (error) {
    next(error);
  }
}

export async function createCourse(req, res, next) {
  try {
    const course = await adminService.createCourse(req.body);
    return res.status(201).json({ course, message: 'Course created successfully.' });
  } catch (error) {
    next(error);
  }
}

export async function updateCourse(req, res, next) {
  try {
    const { courseId } = req.params;
    const course = await adminService.updateCourse(courseId, req.body);
    return res.json({ course, message: 'Course updated successfully.' });
  } catch (error) {
    next(error);
  }
}

export async function deleteCourse(req, res, next) {
  try {
    const { courseId } = req.params;
    await adminService.deleteCourse(courseId);
    return res.json({ success: true, message: 'Course deleted successfully.' });
  } catch (error) {
    next(error);
  }
}

export async function toggleCourseActive(req, res, next) {
  try {
    const { courseId } = req.params;
    const { active } = req.body;
    const course = await adminService.toggleCourseActive(courseId, active);
    return res.json({ course, message: `Course ${active ? 'activated' : 'deactivated'} successfully.` });
  } catch (error) {
    next(error);
  }
}

// ANALYTICS
export async function getAnalytics(req, res, next) {
  try {
    const analytics = await adminService.getAnalytics();
    return res.json(analytics);
  } catch (error) {
    next(error);
  }
}

// SETTINGS (Approved College Domains)
export async function getSettings(req, res, next) {
  try {
    const settings = await adminService.getSettings();
    return res.json(settings);
  } catch (error) {
    next(error);
  }
}

export async function addDomain(req, res, next) {
  try {
    const domain = await adminService.addDomain(req.body);
    return res.status(201).json({ domain, message: 'Approved college domain added.' });
  } catch (error) {
    next(error);
  }
}

export async function updateDomain(req, res, next) {
  try {
    const { domainId } = req.params;
    const domain = await adminService.updateDomain(domainId, req.body);
    return res.json({ domain, message: 'Approved college domain updated.' });
  } catch (error) {
    next(error);
  }
}

export async function deleteDomain(req, res, next) {
  try {
    const { domainId } = req.params;
    await adminService.deleteDomain(domainId);
    return res.json({ success: true, message: 'Approved college domain removed.' });
  } catch (error) {
    next(error);
  }
}

// ADMIN PROFILE
export function getAdminProfile(req, res) {
  return res.json({
    admin: req.admin,
  });
}
